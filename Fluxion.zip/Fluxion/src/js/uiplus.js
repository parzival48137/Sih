/* Wires the v1.2 modules into the screens: Designer checks and summary,
   PDF report and bill of quantities, Optimise (recommender, frugality,
   sensitivity), Site data, and the Field check report. */
(function () {
  "use strict";
  const TS = window.TS, A = TS.app, C = TS.charts, $ = id => document.getElementById(id);
  const clone = o => JSON.parse(JSON.stringify(o));
  const f1 = v => (v == null || !isFinite(v) ? "–" : (+v).toFixed(1)).replace(/^-/, "−");
  const f2 = v => (v == null || !isFinite(v) ? "–" : (+v).toFixed(2)).replace(/^-/, "−");
  let lastChecks = [], lastOpt = null, lastSens = null;

  /* ------------------------------------------------- Designer inputs */
  function sync() {
    const d = A.S.design;
    d.snow = d.snow || {}; d.vents = d.vents || {};
    $("pitch").value = d.pitch || 0; $("snowDepth").value = d.snow.depth || 0; $("snowCap").value = d.snow.capacity || "";
    $("floorMode").value = d.floorMode || "ground";
    $("trArea").value = (d.trombe && d.trombe.area) || 0; $("trMat").value = (d.trombe && d.trombe.mat) || "stone"; $("trT").value = Math.round(((d.trombe && d.trombe.t) || 0.3) * 1000);
    $("shape").value = d.shape || "box"; $("tb").value = String(d.tb || 0); $("ohP").value = (d.overhang && d.overhang.P) || 0;
    $("mechAch").value = (d.mech && d.mech.ach) || 0; $("mechEff").value = Math.round(((d.mech && d.mech.eff) || 0.75) * 100); $("o2").value = d.o2 || 20.9;
    $("ventLo").value = d.vents.low || 0; $("ventHi").value = d.vents.high || 0; $("ventX").checked = !!d.vents.cross; $("unflued").checked = !!d.unflued;
  }
  function wire() {
    const D = () => A.S.design;
    const num = (id, fn) => $(id).addEventListener("input", e => { const v = parseFloat(e.target.value); fn(isFinite(v) ? v : 0); A.changed(); });
    num("pitch", v => (D().pitch = Math.max(0, Math.min(60, v))));
    num("snowDepth", v => (D().snow = Object.assign({}, D().snow, { depth: Math.max(0, v) })));
    num("snowCap", v => (D().snow = Object.assign({}, D().snow, { capacity: Math.max(0, v) })));
    $("floorMode").addEventListener("change", e => { D().floorMode = e.target.value; A.changed(); });
    $("shape").addEventListener("change", e => { D().shape = e.target.value; A.changed(); });
    $("tb").addEventListener("change", e => { D().tb = +e.target.value; A.changed(); });
    num("ohP", v => (D().overhang = v > 0 ? { P: v, g: 0.3 } : null));
    const mech = () => { const a = parseFloat($("mechAch").value) || 0, ef = (parseFloat($("mechEff").value) || 0) / 100; D().mech = a > 0 ? { ach: a, eff: Math.min(0.95, ef) } : null; };
    ["mechAch", "mechEff"].forEach(id => $(id).addEventListener("input", () => { mech(); A.changed(); }));
    num("o2", v => (D().o2 = Math.max(20.9, Math.min(30, v || 20.9))));
    const tr = () => { const a = parseFloat($("trArea").value) || 0; D().trombe = a > 0 ? { area: a, mat: $("trMat").value, t: (parseFloat($("trT").value) || 300) / 1000 } : null; A.changed(); };
    ["trArea", "trT"].forEach(id => $(id).addEventListener("input", tr)); $("trMat").addEventListener("change", tr);
    num("ventLo", v => (D().vents = Object.assign({}, D().vents, { low: Math.max(0, v) })));
    num("ventHi", v => (D().vents = Object.assign({}, D().vents, { high: Math.max(0, v) })));
    $("ventX").addEventListener("change", e => { D().vents = Object.assign({}, D().vents, { cross: e.target.checked }); A.changed(); });
    $("unflued").addEventListener("change", e => { D().unflued = e.target.checked; A.changed(); });
  }

  /* ------------------------------------------------- checks + summary */
  function afterRun(R) {
    if (!R || !R.co2) return;
    const site = A.buildSite();
    lastChecks = TS.checks.run(A.S.design, site, A.ops(), R, "kerosene");
    $("checksList").innerHTML = lastChecks.map((c, i) => `<div class="check ${c.level}"><span class="dot"></span><div><b>${c.title}</b><p>${c.detail}</p>` +
      (c.fix ? `<button type="button" class="ghost small" data-fix="${i}">${c.fix.label}</button>` : "") + "</div></div>").join("");
    $("checksList").querySelectorAll("[data-fix]").forEach(b => b.onclick = () => {
      const c = lastChecks[+b.dataset.fix]; A.S.design = c.fix.apply(clone(A.S.design)); A.syncInputs(); A.changed(); A.toast("Applied: " + c.fix.label);
    });
    lastSens = TS.optimise.sensitivity(A.S.design, site, A.ops(), "fuel");
    $("plainText").textContent = TS.optimise.explain({ opt: null, sens: lastSens, siteName: A.siteRec().name, month: A.MONTHS[A.S.site.month], unit: "L", checks: lastChecks });
  }

  async function report(ctx, name) {
    try { A.toast("Building the report…"); const doc = await TS.report.build(ctx); const where = await TS.report.save(doc, name); A.toast("Saved " + where); }
    catch (e) { A.toast("Report failed: " + e.message); console.error(e); }
  }
  $("dlReport").addEventListener("click", () => {
    const R = A.R, site = A.buildSite();
    report({ d: A.S.design, site, r: R, ops: A.ops(), checks: lastChecks, sens: lastSens, opt: lastOpt, unit: "L",
      explainText: $("plainText").textContent, siteName: A.siteRec().name, monthName: A.MONTHS[A.S.site.month], typeName: "Designer",
      tempChartSvg: TS.report.inlineChart($("nightChart")), flowChartSvg: TS.report.inlineChart($("flowChart")), pathNames: A.pathNames(),
      parityText: TS.bridgeLast ? `Last ANSYS run: indoor air minimum ${f1(TS.bridgeLast.res.outputs.T_AIR_MIN)} C (ANSYS${TS.bridgeLast.res.mock ? ", mock" : ""}) vs ${f1(TS.bridgeLast.app.T_AIR_MIN)} C (app, same case).` : "" },
      "fluxion_report.pdf");
  });
  $("dlBoq").addEventListener("click", () => A.download("fluxion_boq.csv", TS.report.boqCSV(TS.report.boq(A.S.design, A.R)), "text/csv"));

  /* ------------------------------------------------- Optimise tab */
  const fr = $("frugal");
  const frLabel = () => ($("frugalOut").textContent = `${Math.round(fr.value * 100)} % frugality`);
  fr.addEventListener("input", frLabel); frLabel();
  $("optRun").addEventListener("click", () => {
    $("optSummary").textContent = "Searching…"; $("optTable").innerHTML = "";
    setTimeout(() => {
      const site = A.buildSite(), t0 = performance.now();
      lastOpt = TS.optimise.optimise(A.S.design, site, A.ops(), +fr.value);
      const o = lastOpt, ms = performance.now() - t0;
      $("optSummary").innerHTML = (o.steps.length ? "Each row is what that change is worth on its own, measured by undoing it in the recommended design. " : "") + (o.steps.length
        ? `Fuel <b>${f2(o.start.fuel)} → ${f2(o.end.fuel)} L/day</b>, coldest unheated hour ${f1(o.start.nightMin)} → ${f1(o.end.nightMin)} °C, local-material burden ${f2(o.start.burden)} → ${f2(o.end.burden)} (0 = all local, no specialist upkeep). ${o.evals} designs tested in ${Math.round(ms)} ms.`
        : `Nothing in the options searched beats the current design at this setting (${o.evals} designs tested).`);
      $("optTable").innerHTML = o.steps.length ? `<tr><th class="l">Change</th><th class="l">From</th><th class="l">To</th><th>Fuel, L/day</th><th>Coldest night, K</th><th>Burden</th></tr>` +
        o.steps.map(s => `<tr><td>${s.label}</td><td class="l">${s.from}</td><td class="l">${s.to}</td><td>${s.dFuel > 0 ? "+" : ""}${f2(s.dFuel)}</td><td>${s.dNight > 0 ? "+" : ""}${f1(s.dNight)}</td><td>${s.dBurden > 0 ? "+" : ""}${f2(s.dBurden)}</td></tr>`).join("") : "";
      $("optApply").hidden = !o.steps.length;
    }, 30);
  });
  $("optApply").addEventListener("click", () => { if (!lastOpt) return; A.S.design = clone(lastOpt.design); A.syncInputs(); A.changed(); A.toast("Recommended design loaded in the Designer"); });
  let sensMetric = "fuel";
  $("sensMetric").querySelectorAll("button").forEach(b => b.addEventListener("click", () => {
    sensMetric = b.dataset.v; $("sensMetric").querySelectorAll("button").forEach(x => x.setAttribute("aria-selected", String(x === b))); renderSens();
  }));
  function renderSens() {
    const s = TS.optimise.sensitivity(A.S.design, A.buildSite(), A.ops(), sensMetric);
    if (sensMetric === "fuel") lastSens = s;
    const u = sensMetric === "fuel" ? " L/day" : " °C";
    $("sensLede").innerHTML = `Each input is moved across the range shown while everything else stays as designed. The bar is that input's share of the total swing in ${sensMetric === "fuel" ? "kerosene use" : "the coldest unheated night hour"}; current value ${f2(s.base)}${u}. Shares depend on the ranges, which are listed.`;
    C.bars($("sensChart"), { items: s.rows.map((r, i) => ({ label: r.label, value: r.share * 100, cls: i === 0 ? "" : i < 3 ? "mute" : "cool" })), unit: " %", digits: 0, labelW: 170 });
    $("sensTable").innerHTML = `<tr><th class="l">Input</th><th class="l">Range tested</th><th>Lowest</th><th>Highest</th><th>Share</th></tr>` +
      s.rows.map(r => `<tr><td>${r.label}</td><td class="l">${r.range}</td><td>${f2(r.lo)}</td><td>${f2(r.hi)}</td><td>${Math.round(r.share * 100)} %</td></tr>`).join("");
  }
  function renderOptimise() { renderSens(); }

  /* ------------------------------------------------- Site data tab */
  const MON = ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"];
  function renderSite() {
    const sel = $("sdSite"), cur = sel.value || A.S.site.id;
    sel.innerHTML = TS.SITES.map(s => `<option value="${s.id}">${s.name}${s.source ? " (fetched)" : ""}</option>`).join(""); sel.value = TS.SITES.some(s => s.id === cur) ? cur : TS.SITES[0].id;
    const s = TS.SITES.find(x => x.id === sel.value);
    $("sdDel").hidden = !s.source;
    const lapse = 6.5 * (s.cell.elev - s.alt) / 1000;
    $("sdInfo").innerHTML = `${s.name}: ${s.lat}° N, ${s.lon}° E, site ${s.alt} m. NASA grid cell centre ${s.cell.lat}, ${s.cell.lon} at ${s.cell.elev} m, so temperatures are moved by ${lapse >= 0 ? "+" : "−"}${Math.abs(lapse).toFixed(1)} K to the site. ` +
      (s.source ? `Fetched ${s.source.fetched}: ${s.source.power}; terrain ${s.source.dem}.` : "Built-in climatology cached from NASA POWER on 30 Sep 2026. No terrain fetched yet: fetch this location to add its horizon.");
    const x = MON.map((_, i) => i + 0.5), adj = a => a.map(v => v + lapse);
    const series = [{ name: "Mean", y: adj(s.T2M), cls: "pas", width: 2.4, points: true }];
    if (s.TMAX) { series.push({ name: "Daily maximum", y: adj(s.TMAX), cls: "c2", width: 1.6 }); series.push({ name: "Daily minimum", y: adj(s.TMIN), cls: "amb", width: 1.6 }); }
    C.line($("sdClim"), { x, xTicks: x, xFmt: v => MON[Math.floor(v)] || "", height: 220, unit: " °C", tipDigits: 1, yLabel: "Air temperature at the site, °C", series });
    $("sdClimLg").innerHTML = `<span class="lg" style="--c:#8C2131">Monthly mean</span>` + (s.TMAX ? `<span class="lg" style="--c:#D99A1E">Mean daily maximum</span><span class="lg" style="--c:#2F6FA3">Mean daily minimum</span>` : "");
    C.line($("sdSun"), { x, xTicks: x, xFmt: v => MON[Math.floor(v)] || "", height: 180, unit: "", tipDigits: 2, yLabel: "Solar on ground, kWh/m²·day and wind, m/s",
      series: [{ name: "Solar kWh/m²·day", y: s.GHI, cls: "c2", width: 2.2, points: true }, { name: "Wind m/s", y: s.WS, cls: "c7", width: 1.4 }] });
    polar(s);
  }
  function polar(s) {
    const svg = $("sdPolar"), h = s.horizon || [], n = h.length;
    let o = `<circle r="110" fill="none" stroke="var(--rule)"/><circle r="73" fill="none" stroke="var(--rule2)"/><circle r="37" fill="none" stroke="var(--rule2)"/>`;
    [["N", 0], ["E", 90], ["S", 180], ["W", 270]].forEach(([t, a]) => o += `<text x="${121 * Math.sin(a * Math.PI / 180)}" y="${-121 * Math.cos(a * Math.PI / 180) + 4}" text-anchor="middle" font-size="12" font-weight="700" fill="var(--ink2)">${t}</text>`);
    if (n) {
      const pts = h.map((e, i) => { const a = i * 360 / n * Math.PI / 180, r = 110 * (1 - Math.min(e, 45) / 45); return `${(r * Math.sin(a)).toFixed(1)},${(-r * Math.cos(a)).toFixed(1)}`; });
      o += `<polygon points="${pts.join(" ")}" fill="var(--sun-soft)" stroke="var(--sun)" stroke-width="2"/>`;
      // winter sun path for reference (December)
      let p = ""; for (let t = 0; t <= 24; t += 0.25) { const sp = TS.engine.sunPos(s.lat, s.lon, 349, t, 82.5); if (sp.alt <= 0) continue; const a = sp.az * Math.PI / 180, r = 110 * (1 - Math.min(sp.alt, 45) / 45); p += (p ? "L" : "M") + (r * Math.sin(a)).toFixed(1) + "," + (-r * Math.cos(a)).toFixed(1); }
      o += `<path d="${p}" fill="none" stroke="var(--heat)" stroke-width="2" stroke-dasharray="4 3"/>`;
      let q = ""; for (let t = 0; t <= 24; t += 0.25) { const sp = TS.engine.sunPos(s.lat, s.lon, 172, t, 82.5); if (sp.alt <= 0) continue; const a = sp.az * Math.PI / 180, r = 110 * (1 - Math.min(sp.alt, 45) / 45); q += (q ? "L" : "M") + (r * Math.sin(a)).toFixed(1) + "," + (-r * Math.cos(a)).toFixed(1); }
      o += `<path d="${q}" fill="none" stroke="var(--sun)" stroke-width="2"/>`;
      o += `<text x="0" y="128" text-anchor="middle" font-size="10" fill="var(--ink3)">skyline (fill); 21 Dec sun (dashed) and 21 Jun sun (solid)</text>`;
    } else o += `<text x="0" y="4" text-anchor="middle" font-size="12" fill="var(--ink3)">No terrain data for this site</text>`;
    svg.innerHTML = o;
    if (s.terrain) {
      const sIdx = Math.round(180 / (360 / s.terrain.profiles.length)) % s.terrain.profiles.length;
      const dist = s.terrain.dist.map(d => d / 1000);
      C.line($("sdProfile"), { x: dist, xTicks: dist, height: 220, unit: " m", tipDigits: 0, xLabel: "Distance from site, km", yLabel: "Ground elevation, m",
        series: [{ name: "Towards south", y: s.terrain.profiles[sIdx], cls: "c2", width: 2.2, points: true },
          { name: "Towards north", y: s.terrain.profiles[0], cls: "c1", width: 1.6, points: true }] });
    } else $("sdProfile").innerHTML = "";
  }
  $("sdSite").addEventListener("change", renderSite);
  $("sdUse").addEventListener("click", () => { const sel = $("site"); sel.value = $("sdSite").value; sel.dispatchEvent(new Event("change")); A.showTab("design"); });
  $("sdDel").addEventListener("click", () => { TS.sitedata.remove($("sdSite").value); renderSite(); A.syncInputs(); });
  $("sdFetch").addEventListener("click", async () => {
    const name = $("sdName").value.trim() || "New site", lat = parseFloat($("sdLat").value), lon = parseFloat($("sdLon").value);
    if (!(lat >= -60 && lat <= 60 && lon >= -180 && lon <= 180)) { $("sdStatus").textContent = "Enter a latitude and longitude."; return; }
    if (!navigator.onLine) { $("sdStatus").textContent = "This device is offline. Fetch on a connected machine and import the site pack."; return; }
    try {
      const rec = await TS.sitedata.buildPack(name, lat, lon, null, t => ($("sdStatus").textContent = t));
      TS.sitedata.install(rec); A.syncInputs(); $("sdSite").value = rec.id; renderSite();
      $("sdStatus").textContent = `Saved ${rec.name}: ${rec.alt} m, horizon up to ${Math.max(...rec.horizon).toFixed(0)}°. It is now in every site list and works offline.`;
    } catch (e) { $("sdStatus").textContent = "Could not fetch: " + e.message + ". If this is a browser, the data service may block cross-site requests; the Windows and Android apps fetch directly."; }
  });
  $("sdExport").addEventListener("click", () => A.download("fluxion_sites.json", TS.sitedata.exportPack(), "application/json"));
  $("sdImport").addEventListener("change", async e => {
    const f = e.target.files[0]; if (!f) return;
    try { const n = TS.sitedata.importPack(await f.text()); A.syncInputs(); renderSite(); $("sdStatus").textContent = `Imported ${n} site(s).`; }
    catch (x) { $("sdStatus").textContent = "Could not import: " + x.message; }
  });

  /* ------------------------------------------------- Field check report */
  const fb = document.createElement("div"); fb.className = "actions";
  fb.innerHTML = `<button type="button" id="fReport">Download report (PDF)</button>`;
  document.querySelector("#view-field .answers").appendChild(fb);
  $("fReport").addEventListener("click", async () => {
    const Lf = TS.fieldLast; if (!Lf) return;
    const m = Lf.m, ans = TS.fieldUI.answers(), fuelKey = ans.fuel;
    const r = TS.airflow.simulate(m.d, m.site, m.ops, fuelKey), checks = TS.checks.run(m.d, m.site, m.ops, r, fuelKey);
    const sens = TS.optimise.sensitivity(m.d, m.site, m.ops, "fuel"), moist = TS.moisture.analyse(r, m.d, fuelKey, m.ops);
    const names = { roof: "Roof", floor: "Floor", glazing: "Windows", vent: "Air leakage and ventilation", trombe: "Trombe wall" };
    r.solar.facades.forEach(f => (names["wall_" + f.key] = `${f.label} wall`));
    const text = $("fAns1").textContent + " " + $("fAns2").textContent + " " + $("fAns3").textContent;
    try {
      A.toast("Building the report…");
      const doc = await TS.report.build({ d: m.d, site: m.site, r, ops: m.ops, checks, sens, moist, unit: m.F.unit, explainText: text, siteName: m.rec.name,
        monthName: TS.field.MONTHS[m.site.month], typeName: m.T.name, heaterName: ans.stove ? m.F.name + " heater" : "None", classification: m.P.name,
        safeFloor: m.P.safeFloor, pathNames: names, log: TS.logistics.summary(m.d, r.summary.fuel_L, m.F.unit), apdl: TS.apdl.generate(m.d, r) });
      A.toast("Saved " + await TS.report.save(doc, "fluxion_quickcheck.pdf"));
    } catch (e) { A.toast("Report failed: " + e.message); console.error(e); }
  });

  wire(); sync();
  TS.uiplus = { sync, afterRun, renderOptimise, renderSite, lastChecks: () => lastChecks };
  if (A.R && A.S.ui.tab === "design") afterRun(A.R);
})();
