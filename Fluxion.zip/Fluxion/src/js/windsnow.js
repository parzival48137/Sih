/* WIND & SNOW
   Wind, IS 875 (Part 3):2015 (screening, low-rise, closed shelter):
     Vz = Vb k1 k2 k3 k4,  pz = 0.6 Vz^2,  pd = Kd Ka Kc pz (0.9 x 1.0 x 0.9),
     roof uplift  F = (Cpe - Cpi) A pd with Cpe = -0.8, Cpi = +0.2,
     windward wall p = (0.7 + 0.2) pd. k2 = 1.0 (terrain category 2, up to 10 m).
     Vb is chosen from the IS 875-3 wind-zone map (33-55 m/s); k1 = 0.82 for
     temporary structures (about 1-year life) or 1.0 for 50-year.
   Snow, IS 875 (Part 4): s = mu s0, mu = 0.8 to 30 deg, 0 at 60 deg.
   Anchorage = uplift - 0.9 x roof self-weight (if positive). */
(function () {
  "use strict";
  const TS = window.TS, A = TS.app, C = TS.charts, $ = id => document.getElementById(id);
  const KEY = "thermashelter.wind.v1";
  let Wd = { vb: 39, k1: 0.82, k3: 1.0 };
  try { Object.assign(Wd, JSON.parse(localStorage.getItem(KEY)) || {}); } catch (e) {}
  const f1 = v => (v == null || !isFinite(v) ? "–" : (+v).toFixed(1)).replace(/^-/, "−");
  const f2 = v => (v == null || !isFinite(v) ? "–" : (+v).toFixed(2)).replace(/^-/, "−");

  const sec = document.createElement("section");
  sec.className = "view"; sec.id = "view-wind"; sec.dataset.view = "wind"; sec.hidden = true;
  sec.innerHTML = `<div class="page">
    <div class="cardgrid" id="wsCards"></div>
    <section class="block"><h2>Inputs</h2>
      <div class="row4">
        <label>Wind zone (IS 875-3 map)<select id="wsVb">${[33, 39, 44, 47, 50, 55].map(v => `<option value="${v}">${v} m/s</option>`).join("")}</select></label>
        <label>Design life<select id="wsK1"><option value="0.82">Temporary, about 1 year (k1 0.82)</option><option value="1">50 years (k1 1.0)</option></select></label>
        <label><span>Topography k3</span><input id="wsK3" type="number" min="1" max="1.36" step="0.01"></label>
        <label><span>Design snow depth <small>m</small></span><input id="wsSnow" type="number" min="0" step="0.1"></label>
      </div>
      <div class="row4">
        <label><span>Snow density <small>kg/m³</small></span><input id="wsRho" type="number" min="50" step="10"></label>
        <label><span>Roof rated for <small>kN/m²</small></span><input id="wsCap" type="number" min="0" step="0.1" placeholder="unknown"></label>
        <label><span>Roof pitch <small>°</small></span><input id="wsPitch" type="number" min="0" max="60" step="1"></label>
        <label>Floor<select id="wsFloor"><option value="ground">On the ground</option><option value="raised">Raised on skids</option></select></label>
      </div>
    </section>
    <section class="block"><h2>Monthly wind at the site</h2><div class="chartbox" id="wsWind"></div></section>
  </div>`;
  document.querySelector("main").appendChild(sec);

  function compute() {
    const d = A.S.design, R = A.R, sn = d.snow || {};
    const Vz = Wd.vb * Wd.k1 * 1.0 * Wd.k3 * 1.0, pz = 0.6 * Vz * Vz, pd = 0.81 * pz;
    const roofA = d.L * d.W / Math.cos((d.pitch || 0) * Math.PI / 180);
    const uplift = 1.0 * roofA * pd / 1000;                                   // kN
    const roofMass = d.roof.reduce((s, l) => s + TS.engine.layerProps(l, TS.MATERIALS).rho * l.t, 0) * roofA;
    const anchor = Math.max(0, uplift - 0.9 * roofMass * 9.81 / 1000);
    const wall = 0.9 * pd / 1000;                                               // kN/m2
    const s0 = (sn.depth || 0) * (sn.density || 300) * 9.81 / 1000, mu = TS.checks.snowMu(d.pitch || 0), s = mu * s0;
    const pNeed = sn.capacity > 0 && s0 > 0 ? TS.checks.pitchFor(sn.capacity / s0) : null;
    const maat = TS.checks.annualMeanAir(A.buildSite());
    return { Vz, pz, pd, uplift, anchor, wall, roofMass, s0, mu, s, pNeed, maat, cap: sn.capacity };
  }
  function render() {
    const d = A.S.design, sn = d.snow || {}, c = compute();
    $("wsVb").value = Wd.vb; $("wsK1").value = String(Wd.k1); $("wsK3").value = Wd.k3;
    $("wsSnow").value = sn.depth || 0; $("wsRho").value = sn.density || 300; $("wsCap").value = sn.capacity || ""; $("wsPitch").value = d.pitch || 0; $("wsFloor").value = d.floorMode || "ground";
    const card = (k, v, u, cls, sub) => `<div class="kcard ${cls || ""}"><span>${k}</span><b>${v}<small>${u}</small></b>${sub ? `<em>${sub}</em>` : ""}</div>`;
    const snowCls = c.s0 === 0 ? "" : c.cap > 0 ? (c.s > c.cap ? "bad" : "ok") : "warn";
    const groundCls = c.maat == null ? "" : c.maat <= -2 && d.floorMode !== "raised" ? "bad" : c.maat <= 0 && d.floorMode !== "raised" ? "warn" : "ok";
    $("wsCards").innerHTML =
      card("Design wind pressure", Math.round(c.pz), " Pa", "", `Vz ${f1(c.Vz)} m/s`) +
      card("Roof uplift", f1(c.uplift), " kN", c.anchor > 0 ? "warn" : "ok", c.anchor > 0 ? `anchor ${f1(c.anchor)} kN` : "held by roof weight") +
      card("Windward wall", f2(c.wall), " kN/m²", "", "Cpe 0.7, Cpi −0.2") +
      card("Roof snow", f2(c.s), " kN/m²", snowCls, c.s0 ? `μ ${f2(c.mu)} on ${d.pitch || 0}°` : "enter snow depth") +
      card("Pitch to shed snow", c.pNeed != null ? c.pNeed : "–", "°", c.pNeed != null && (d.pitch || 0) < c.pNeed ? "bad" : "", c.cap ? `rating ${c.cap} kN/m²` : "enter roof rating") +
      card("Ground", c.maat == null ? "–" : f1(c.maat), " °C", groundCls, groundCls === "bad" ? "permafrost likely: raise floor" : groundCls === "warn" ? "may stay frozen" : "mean annual air");
    const rec = A.siteRec(), MON = ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"], x = MON.map((_, i) => i + 0.5);
    C.line($("wsWind"), { x, xTicks: x, xFmt: v => MON[Math.floor(v)] || "", height: 200, unit: " m/s", tipDigits: 1, yLabel: "Mean wind at 10 m, m/s",
      series: [{ name: "Wind", y: rec.WS, cls: "c1", width: 2.4, points: true }] });
  }
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(Wd)); } catch (e) {} };
  $("wsVb").addEventListener("change", e => { Wd.vb = +e.target.value; save(); render(); });
  $("wsK1").addEventListener("change", e => { Wd.k1 = +e.target.value; save(); render(); });
  $("wsK3").addEventListener("change", e => { Wd.k3 = Math.max(1, Math.min(1.36, +e.target.value || 1)); save(); render(); });
  const snowSet = (k, v) => { A.S.design.snow = Object.assign({}, A.S.design.snow, { [k]: v }); A.syncInputs(); A.changed(); setTimeout(render, 150); };
  $("wsSnow").addEventListener("change", e => snowSet("depth", Math.max(0, +e.target.value || 0)));
  $("wsRho").addEventListener("change", e => snowSet("density", Math.max(50, +e.target.value || 300)));
  $("wsCap").addEventListener("change", e => snowSet("capacity", Math.max(0, +e.target.value || 0)));
  $("wsPitch").addEventListener("change", e => { A.S.design.pitch = Math.max(0, Math.min(60, +e.target.value || 0)); A.syncInputs(); A.changed(); setTimeout(render, 150); });
  $("wsFloor").addEventListener("change", e => { A.S.design.floorMode = e.target.value; A.syncInputs(); A.changed(); setTimeout(render, 150); });
  const _show = TS.app.showTab;
  TS.app.showTab = t => { _show(t); if (t === "wind") render(); };
  TS.windsnow = { compute, render };
})();
