/* Field check screen: five questions, four answers. */
(function () {
  "use strict";
  const TS = window.TS, F = TS.field, C = TS.charts;
  const $ = id => document.getElementById(id);
  const KEY = "thermashelter.field.v1";
  const f1 = v => (v == null || !isFinite(v) ? "–" : (+v).toFixed(1)).replace(/^-/, "−");
  const f0 = v => (v == null || !isFinite(v) ? "–" : String(Math.round(v)));
  const pct = v => Math.round(v * 100) + " %";

  let A = { profile: "relief", site: "leh", month: 0, type: "tent_basic", people: 5, fuel: "kerosene", stove: true, stock: 40, stormDT: 8 };
  try { const o = JSON.parse(localStorage.getItem(KEY)); if (o) A = Object.assign(A, o); } catch (e) {}
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(A)); } catch (e) {} };

  const ICONS = {
    tent: '<path d="M6 40 L32 10 L58 40 Z M32 10 V40 M26 40 L32 26 L38 40" />',
    tent2: '<path d="M6 40 L32 10 L58 40 Z M12 40 L32 17 L52 40" /><path d="M6 44 H58" />',
    cabin: '<path d="M8 40 V18 H56 V40 Z M8 18 L32 12 L56 18 M38 26 h10 v8 h-10z" />',
    hut: '<path d="M10 40 V22 L32 10 L54 22 V40 Z M28 40 V30 h8 v10" />',
    hall: '<path d="M4 40 V16 H60 V40 Z M4 16 L32 6 L60 16 M12 22 h8 v8 h-8z M28 22 h8 v8 h-8z M44 22 h8 v8 h-8z" />',
    house: '<path d="M8 40 V16 H56 V40 Z M8 16 H56 M14 22 h14 v10 h-14z" />',
  };

  function renderForm() {
    const P = F.PROFILES[A.profile];
    if (!P.types.includes(A.type)) A.type = P.types[0];
    if (!P.fuels.includes(A.fuel)) A.fuel = P.fuels[0];
    $("fSite").innerHTML = TS.SITES.map(s => `<option value="${s.id}">${s.name}</option>`).join(""); $("fSite").value = A.site;
    $("fMonth").innerHTML = F.MONTHS.map((m, i) => `<option value="${i}">${m}</option>`).join(""); $("fMonth").value = A.month;
    $("fTypes").innerHTML = P.types.map(k => { const t = F.TYPES[k];
      return `<button type="button" class="typecard" data-k="${k}" aria-pressed="${k === A.type}"><svg viewBox="0 0 64 48" aria-hidden="true">${ICONS[t.icon] || ICONS.cabin}</svg><span>${t.name}</span><small>${(t.L * t.W).toFixed(0)} m² floor</small></button>`; }).join("");
    $("fTypes").querySelectorAll(".typecard").forEach(b => b.onclick = () => { A.type = b.dataset.k; save(); renderForm(); run(); });
    $("fPeople").value = A.people;
    $("fFuel").innerHTML = P.fuels.map(k => `<option value="${k}">${F.FUELS[k].name}</option>`).join(""); $("fFuel").value = A.fuel;
    $("fStove").checked = A.stove; $("fStock").value = A.stock; $("fStockUnit").textContent = F.FUELS[A.fuel].unit;
    $("fStorm").value = A.stormDT;
    $("fProfileNote").textContent = `${P.name}: for ${P.users}. Comfort target ${P.target} °C (${P.targetNote}); safe floor ${P.safeFloor} °C (${P.safeNote}).`;
    document.querySelectorAll("#profileSeg button").forEach(b => b.setAttribute("aria-selected", String(b.dataset.v === A.profile)));
    document.documentElement.dataset.profile = A.profile;
  }
  function wire() {
    const on = (id, ev, fn) => $(id).addEventListener(ev, e => { fn(e.target); save(); run(); });
    on("fSite", "change", t => (A.site = t.value));
    on("fMonth", "change", t => (A.month = +t.value));
    on("fPeople", "input", t => (A.people = Math.max(1, Math.round(+t.value || 1))));
    on("fFuel", "change", t => { A.fuel = t.value; $("fStockUnit").textContent = F.FUELS[A.fuel].unit; });
    on("fStove", "change", t => (A.stove = t.checked));
    on("fStock", "input", t => (A.stock = Math.max(0, +t.value || 0)));
    on("fStorm", "input", t => (A.stormDT = Math.max(0, +t.value || 0)));
    document.querySelectorAll("#profileSeg button").forEach(b => b.addEventListener("click", () => { A.profile = b.dataset.v; save(); renderForm(); run(); }));
  }

  let runId = 0, last = null;
  function run() {
    const id = ++runId;
    const m = F.derive(A);
    const r = TS.engine.simulate(m.d, m.site, m.ops);
    const cap = F.capacity(m, A.people), P = m.P, Fu = m.F;
    const nmPas = F.nightMin(r, "passive"), nmHeat = F.nightMin(r, "heated");
    last = { m, r };
    TS.fieldLast = last;

    // Answer 1: tonight
    const holds = (A.stove ? nmHeat : nmPas) >= P.safeFloor - 0.05;
    let s = A.stove
      ? `With the ${Fu.name.toLowerCase()} heater this shelter ${holds ? "<b class=\"ok\">stays above</b>" : "<b class=\"no\">falls below</b>"} the ${P.safeFloor} °C safe floor tonight: coldest about <b>${f1(nmHeat)} °C</b>. Without heating it would fall to <b class="h">${f1(nmPas)} °C</b>.`
      : `Without heating this shelter ${holds ? "<b class=\"ok\">stays above</b>" : "<b class=\"no\">falls below</b>"} the ${P.safeFloor} °C safe floor: coldest about <b class="h">${f1(nmPas)} °C</b> tonight, when it is <b class="c">${f1(Math.min(...r.amb))} °C</b> outside.`;
    if (A.stove && r.summary.unmetHours > 0) { const sn = F.stovesNeeded(m);
      s += ` One heater (${f1(sn.one)} kW) cannot keep up for ${f0(r.summary.unmetHours)} hours: the coldest hour needs ${f1(sn.peak)} kW, so plan <b>${sn.n} heaters</b> or improve the shelter first.`; }
    $("fAns1").innerHTML = s;
    $("fConf").innerHTML = `<span class="spin"></span> Checking ${120} variations of what cannot be seen from outside…`;

    // Answer 2: capacity
    const over = A.people > cap.nSpace;
    $("fAns2").innerHTML = `<b>${cap.nSpace} people</b> fit this ${f0(cap.Af)} m² shelter at ${P.space} m² each (${P.spaceNote}).` +
      (over ? ` <b class="no">You entered ${A.people}: that is over the limit.</b>` : "") +
      ` For ${A.people} people, keeping CO₂ under 1000 ppm needs ${f1(cap.achNeed)} air changes an hour; this shelter leaks about ${f1(cap.achHave)}` +
      (cap.achNeed > cap.achHave ? `, so open a vent: at ${f0(cap.co2Now)} ppm otherwise.${A.stove ? ` That extra air costs about ${f1(cap.extraFuel)} ${Fu.unit} of fuel a day.` : ""}` : ", which is enough.");

    // Answer 3: fuel
    const daily = r.summary.fuel_L;
    $("fAns3").innerHTML = !A.stove ? "No heater selected." : daily < 0.05 ? `The heater is hardly needed: under 0.05 ${Fu.unit} a day.` :
      `About <b>${f1(daily)} ${Fu.unit} of ${Fu.name.toLowerCase()} a day</b> to hold ${P.target} °C. ${A.stock} ${Fu.unit} lasts <b>${f1(A.stock / daily)} days</b>; ` +
      `a month needs ${f1(daily * 30 / Fu.pack)} ${Fu.packName}s for this shelter.`;

    // Answer 4: actions
    const acts = F.actions(m);
    $("fAns4").innerHTML = acts.length ? "<ol class=\"acts\">" + acts.map(a => `<li><b>${a.name}</b>: ${a.how}. ` +
      (A.stove && a.fuelSaved > 0.01 ? `Saves ${f1(a.fuelSaved)} ${Fu.unit} a day` : "") + (a.warmer > 0.2 ? `${A.stove && a.fuelSaved > 0.01 ? "; " : ""}nights ${f1(a.warmer)} °C warmer without heating` : "") + ".</li>").join("") + "</ol>"
      : "Nothing simple left to improve on this shelter type.";

    // Stress test
    const st = F.stressTest(m, A.stormDT);
    const stPas = Math.min(...st.passive.op.slice(48)), stHeat = Math.min(...st.heated.op.slice(48));
    const stFuel = st.heated.phi.slice(48).reduce((a, b) => a + b, 0) / 1000 / (Fu.kwh * Fu.eta);
    $("fStormText").innerHTML = `Two normal days, then three days with no sun, ${A.stormDT} K colder and double wind. ` +
      (A.stove ? `With the heater the coldest is <b>${f1(stHeat)} °C</b>${st.summary.unmetHours > 0 ? `, and it cannot keep up for ${f0(st.heated.unmet.slice(48).filter(Boolean).length)} hours` : ""}; the three storm days burn <b>${f1(stFuel)} ${Fu.unit}</b>. ` : "") +
      `Without heating it reaches <b class="h">${f1(stPas)} °C</b>.`;
    const x = st.amb.map((_, i) => i + 0.5), ticks = [0, 24, 48, 72, 96, 120];
    C.line($("fStormChart"), { x, xTicks: ticks, xEndPad: 0.5, height: 240, unit: " °C", tipDigits: 1, yLabel: "°C",
      xFmt: (v, tip) => `Day ${Math.floor(v / 24) + 1}${tip ? " " + String(Math.floor(v) % 24).padStart(2, "0") + ":00" : ""}`,
      vbands: [{ x0: 48, x1: 120, cls: "nightband" }],
      hbands: [{ y0: P.safeFloor - 0.15, y1: P.safeFloor + 0.15, cls: "floorline", label: `Safe floor ${P.safeFloor} °C`, fit: true }],
      series: [{ name: "Outside air", y: st.amb, cls: "amb", width: 2 }, { name: "Inside, no heating", y: st.passive.op, cls: "pas", width: 2.6 }]
        .concat(A.stove ? [{ name: "Inside, with heater", y: st.heated.op, cls: "heat", width: 1.6, dash: "5 4" }] : []) });

    // Sources
    $("fSources").innerHTML = m.sources.map(([k, v, src]) => `<tr><td>${k}</td><td class="v2">${v}</td><td class="n">${src}</td></tr>`).join("");

    // Uncertainty (async)
    F.monteCarlo(m, 120, (S) => {
      if (id !== runId) return;
      const p = A.stove ? S.pHeated : S.pPassive, se = A.stove ? S.seHeated : S.sePassive;
      const cls = p >= 0.9 ? "ok" : p >= 0.6 ? "warn" : "no";
      $("fConf").innerHTML = `<div class="confbar"><span style="width:${(p * 100).toFixed(0)}%" class="${cls}"></span></div>` +
        `Stays above ${P.safeFloor} °C in <b class="${cls}">${pct(p)}</b> of ${S.n} variations (±${Math.round(se * 100)} points). ` +
        `Varied: air leakage, material conductivity and ground temperature, which cannot be seen from outside. ` +
        (A.stove ? `Fuel use ranges up to ${f1(S.fuelP95)} ${Fu.unit} a day (95th percentile); plan stock on that. ` : "") +
        (S.weather ? "Day-to-day weather spread is included." : "Day-to-day weather spread is not included yet: it needs NASA daily statistics for this site. The storm test below covers the cold-spell case.");
      last.mc = S;
    }, 1000 + A.month * 7 + A.people);
  }

  function render() { renderForm(); run(); }
  window.addEventListener("resize", () => { if (!$("view-field").hidden && last) run(); });
  wire();
  TS.fieldUI = { render, get last() { return last; }, answers: () => A };
})();
