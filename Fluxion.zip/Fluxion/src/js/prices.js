/* Material prices by region (INR), used for the cost when the user has not typed
   a rate of their own (a typed rate always wins).
   price = base market price (treated as Delhi level) x (station cost index / Delhi cost index)

   Base prices: Indian online market listings, searched 4 Oct 2026; one value per
   material, converted to the app's units (m2 for sheets thinner than 5 mm, m3 otherwise):
     steel   colour-coated roofing sheet 0.5 mm, Rs 385/m2 (arsengineeringcontractors.in)
     puf     PUF sandwich panel 50 mm, Rs 1,200/m2 (IndiaMART "PUF Sandwich Panel") -> 24,000/m3 (incl. skins)
     xps     XPS board 50 mm, Rs 550/m2 (IndiaMART, Aajjo) -> 11,000/m3
     eps     EPS board 50 mm, Rs 350/m2 (Justdial "EPS foam") -> 7,000/m3
     rockwool slab 50 mm, 48 kg/m3, Rs 195/m2 (IndiaMART Rs 190, Allied Insulation Rs 203) -> 3,900/m3
     aerogel blanket 10 mm, Rs 1,345/m2 (MG Materials list price) -> 134,500/m3
     plywood commercial 12 mm, Rs 50/sq ft (ContractorBhai: non-branded Rs 40-65) -> 538/m2 -> 44,800/m3
     brick   red clay brick Rs 8 each (InfraLens 2026: Rs 7-9) x 500 bricks per m3 -> 4,000/m3 (bricks only)
     concrete ready-mix M25 Rs 5,700/m3 (InfraLens 2026: Rs 5,158-6,211)
   Other materials have no sourced price yet: the app asks for a rate.

   Cost index: CPWD Building Cost Index, compiled at nsrcivil.in/cpwd-building-cost-index-states
   (CPWD circulars). Delhi = 103.37 on DPAR 2023, 01.04.2025 (nsrcivil.in, CPWD Delhi BCI table).
   Stations given on an older base are converted with Delhi's index on that base and date:
   DPAR 2012 01.04.2017 Delhi = 111; DPAR 2020 01.04.2021 Delhi = 105.
   Srinagar: "Add cost index @ 23.36% over DSR 2023" (BSF tender, Srinagar, via bidassist.com).
   No published index found: Ladakh, Tawang, Bomdila, Rajasthan -> Delhi prices, flagged. */
(function (g) {
  "use strict";
  const TS = g.TS = g.TS || {};
  const BASE = {
    "steel|m2": 385, "puf|m3": 24000, "xps|m3": 11000, "eps|m3": 7000, "rockwool|m3": 3900,
    "aerogel|m3": 134500, "plywood|m3": 44800, "brick|m3": 4000, "concrete|m3": 5700,
  };
  const DELHI = 103.37;
  const u12 = v => +(v * DELHI / 111).toFixed(1), u20 = v => +(v * DELHI / 105).toFixed(1);
  // region id -> { ci on DPAR 2023 scale, station used, note }
  const CI = {
    delhi: { ci: DELHI, st: "Delhi" },
    srinagar: { ci: 123.36, st: "Srinagar (tender, DSR 2023 + 23.36 %)" },
    gulmarg: { ci: 123.36, st: "Srinagar index (none published for Gulmarg)" },
    sonamarg: { ci: 123.36, st: "Srinagar index (none published for Sonamarg)" },
    gurez: { ci: 123.36, st: "Srinagar index (none published for Gurez)" },
    pahalgam: { ci: 123.36, st: "Srinagar index (none published for Pahalgam)" },
    shimla: { ci: 134, st: "Shimla" }, manali: { ci: 133, st: "Kullu / Katrain" },
    keylong: { ci: 151, st: "Keylong / Lahaul Spiti" }, kaza: { ci: 172, st: "Kaza" }, kalpa: { ci: 153, st: "Reckong Peo" },
    badrinath: { ci: u12(188), st: "Badrinath, Mana (2017, converted)" }, joshimath: { ci: u12(170), st: "Sunil (Joshimath) (2017, converted)" },
    harsil: { ci: u12(151), st: "Matli, Uttarkashi (nearest listed; 2017, converted)" }, munsiyari: { ci: u12(156), st: "Munsyari (2017, converted)" },
    dharchula: { ci: u12(154), st: "Gauthi / Dharchula (2017, converted)" },
    gangtok: { ci: 141, st: "Gangtok" }, lachung: { ci: 162, st: "Yumthang and Kupup (nearest listed)" }, lachen: { ci: 152, st: "Chungthang (nearest listed)" },
    mechuka: { ci: u20(168), st: "Aalo (nearest listed; 2021, converted)" },
    chennai: { ci: 113, st: "Chennai" }, ooty: { ci: 136, st: "Ooty" },
  };
  function factor(regionId) {
    const c = CI[regionId];
    return c ? { f: c.ci / DELHI, station: c.st, sourced: true } : { f: 1, station: "Delhi prices (no published cost index for this place)", sourced: false };
  }
  // effective price for a bill-of-quantities key in a region, or null when not sourced
  function price(key, regionId) { const b = BASE[key]; return b == null ? null : Math.round(b * factor(regionId).f); }
  TS.prices = { BASE, CI, DELHI, factor, price };
  if (typeof module !== "undefined") module.exports = TS;
})(typeof window !== "undefined" ? window : globalThis);
