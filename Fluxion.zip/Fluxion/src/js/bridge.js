/* Client for the team's ANSYS bridge (ansys_bridge.py on the ANSYS PC,
   http://127.0.0.1:8765). The bridge writes the Workbench journal, runs
   RunWB2.exe in batch and returns the parameter outputs. Inputs and ranges
   below mirror ansys_bridge.py; keep them in step if the Workbench parameter
   set changes. */
(function () {
  "use strict";
  const TS = window.TS, $ = id => document.getElementById(id);
  const KEY = "thermashelter.bridge.v1";
  const RANGES = { L: [2, 20], W: [2, 15], H: [2, 6], T_INS: [0.02, 0.5], K_INS: [0.005, 5], RHO_INS: [5, 3000], CP_INS: [100, 5000], WIN_W: [0.2, 10], WIN_H: [0.2, 4], Q_INT: [0, 5000], ACH: [0, 10], FLOOR: [0, 1] };
  const SILL = 0.9, CONTRACT = "1.4";   // 1.1: + occupant heat, air leakage, raised floor, day-2 outputs; 1.2: + arch model (MODEL "arch"); 1.3: arch sun on the floor, average air + hottest point; 1.4: box model average air too (keep in step with ansys_bridge.py)
  // inputs of the stored real base-case run that the bridge's practice (mock) mode returns
  const BASE = { L: 5, W: 4, H: 2.8, T_INS: 0.1, K_INS: 0.025, RHO_INS: 40, CP_INS: 1500, WIN_W: 1.5, WIN_H: 1.2, Q_INT: 0, ACH: 0, FLOOR: 0 };
  /* Boundary conditions of the Workbench model (ansys_case_v1.0.json): walls and
     window h = 15 W/m2K to T(t) = -5.9 + 5.4 cos(2 pi (t - 54000 s)/86400);
     floor h = 2 to 0 C ground; roof combined h = 18.5 to the blended sky/ambient
     function -10.84 + 4.38 cos(...). The app's same-case run is ansyscase.js. */
  const ANSYS_AMBIENT = t => -5.9 + 5.4 * Math.cos(2 * Math.PI * (t - 54000) / 86400);
  let url = "http://127.0.0.1:8765";
  try { url = JSON.parse(localStorage.getItem(KEY)) || url; } catch (e) {}

  /* the whole wall build-up (e.g. steel / PUF / plywood) as the one shell layer of the
     Workbench model: same total thickness, same R (k = T / R), same heat capacity */
  function composite(layers) {
    const ps = layers.map(l => TS.engine.layerProps(l, TS.MATERIALS)).filter(p => p.t > 0);
    const T = ps.reduce((s, p) => s + p.t, 0), R = ps.reduce((s, p) => s + TS.engine.layerR(p), 0);
    const m = ps.reduce((s, p) => s + p.rho * p.t, 0), C = ps.reduce((s, p) => s + p.rho * p.c * p.t, 0);
    return { t: +T.toFixed(4), k: +(T / R).toFixed(5), rho: +(m / T).toFixed(2), c: +(C / m).toFixed(1) };
  }
  function inputsFrom(d) {
    const arch = d.shape === "vault", p = composite(arch ? d.roof : d.wall);
    const A = (d.win && d.win.front) || 0;
    // occupants at night (all present) + equipment; air change of the design; raised or on the ground
    const q = (d.people || 0) * (d.wPerson || 0) + (d.equipW || 0);
    const ach = d.achH && d.achH.length ? d.achH.reduce((s, v) => s + v, 0) / d.achH.length : d.ach || 0;
    const common = { T_INS: p.t, K_INS: p.k, RHO_INS: p.rho, CP_INS: p.c,
      Q_INT: Math.round(Math.min(5000, q)), ACH: +Math.min(10, ach).toFixed(2), FLOOR: d.floorMode === "raised" ? 1 : 0 };
    if (arch) {
      /* arch model (Shelter_Arch.wbpj): curved shell = the design's roof build-up, axis north-south,
         one window in the south end wall on a 0.9 m sill, fitted under the arch */
      const ri = d.W / 2 - p.t, wh = Math.max(0.2, Math.min(1.2, ri - 0.1 - SILL));
      const maxW = Math.max(0.2, 2 * Math.sqrt(Math.max(0, ri * ri - (SILL + wh) ** 2)) - 0.12);
      return Object.assign({ MODEL: "arch", L: d.L, W: d.W }, common,
        { WIN_W: +(A > 0 ? Math.min(A / wh, maxW) : 0.2).toFixed(3), WIN_H: +wh.toFixed(3) });
    }
    const wh = Math.min(1.2, d.H - p.t - 0.05 - SILL);
    // the Workbench model has one south window on a 0.9 m sill: fit the app's window area into it
    const maxW = Math.max(0.2, d.L - 2 * p.t - 0.15);
    return Object.assign({ L: d.L, W: d.W, H: d.H }, common,
      { WIN_W: A > 0 && wh > 0.2 ? +Math.min(A / wh, maxW).toFixed(3) : 0.2, WIN_H: +Math.max(0.2, wh).toFixed(3) });
  }
  // window area the ANSYS model gets vs the design's own (for the note on the ANSYS step)
  const winNote = (d, i) => { const A = (d.win && d.win.front) || 0, got = i.WIN_W * i.WIN_H;
    return A > got + 0.05 ? ` The design has ${A.toFixed(1)} m² of south glass; your ANSYS model takes one window, so it gets the largest that fits: ${got.toFixed(1)} m².` : ""; };
  function validate(i) {
    const e = [];
    if (i.MODEL === "arch") {
      const R = Object.assign({}, RANGES, { L: [2, 30], W: [2, 12], WIN_W: [0.2, 6], WIN_H: [0.2, 3] }), ri = i.W / 2 - i.T_INS;
      for (const k in R) if (k !== "H" && !(i[k] >= R[k][0] && i[k] <= R[k][1])) e.push(`${k} = ${i[k]} is outside ${R[k][0]}–${R[k][1]}`);
      if (ri < 1 || i.L - 2 * i.T_INS < 1) e.push("insulation too thick for this arch");
      if (SILL + i.WIN_H > ri - 0.05 || i.WIN_W / 2 > Math.sqrt(Math.max(0, ri * ri - (SILL + i.WIN_H) ** 2)) - 0.05) e.push("window does not fit in the south end wall");
      return e;
    }
    for (const k in RANGES) if (!(i[k] >= RANGES[k][0] && i[k] <= RANGES[k][1])) e.push(`${k} = ${i[k]} is outside ${RANGES[k][0]}–${RANGES[k][1]}`);
    if (i.L - 2 * i.T_INS < 1 || i.W - 2 * i.T_INS < 1 || i.H - 2 * i.T_INS < 1.5) e.push("insulation too thick for this size");
    if (i.WIN_W > i.L - 2 * i.T_INS - 0.1) e.push("window too wide for the south wall");
    if (SILL + i.WIN_H > i.H - i.T_INS - 0.05) e.push("window too tall for the wall");
    return e;
  }
  /* the app's model of the same ANSYS case: one uniform shell, sealed air body,
     no occupants, ANSYS ambient function, 0 C ground */
  /* the app's run of exactly the ANSYS case (ansyscase.js): same shell, glass, air,
     ambient functions, solar tables, -6 C start, min / max over 48 h */
  function appEquivalent(i) {
    const C = i.MODEL === "arch" ? TS.archCase : TS.ansysCase;   // arch: Shelter_Arch case (archcase.js)
    const r = C.solve(i), d2 = C.solve(i, { days: 2, lastDay: true });
    return { T_AIR_MIN: r.T_AIR_MIN, T_AIR_MAX: r.T_AIR_MAX, Rx: r.Rx || null, T_AIR_MIN_DAY2: d2.T_AIR_MIN, T_AIR_MAX_DAY2: d2.T_AIR_MAX };
  }

  async function call(path, opts) {
    const r = await fetch(url + path, Object.assign({ headers: { "Content-Type": "application/json" } }, opts || {}));
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.error ? j.error + (j.details ? ": " + j.details.join("; ") : "") : "HTTP " + r.status);
    return j;
  }
  let connected = false, poll = 0;
  async function health() {
    const el = $("brStatus");
    try { const h = await call("/health");
      if ((h.contract_version || "1.0") !== CONTRACT) { el.innerHTML = `<b class="warnline">Bridge speaks contract v${h.contract_version}; this app speaks v${CONTRACT}.</b> Update both kit files together before running.`; $("brRun").disabled = true; return h; }
      const ready = h.mock || (h.ansys_found && h.project_found);
      el.innerHTML = h.mock ? `<b class="warnline">● Connected in practice mode</b>: no ANSYS on this PC, results are the stored real base-case run.`
        : ready ? `<b class="okline">● ANSYS connected</b>: ANSYS 18.2 and your project were found${h.busy ? "; a run is in progress" : ""}.`
        : `<b class="warnline">● Connected, but ${h.ansys_found ? "" : "ANSYS (RunWB2.exe) "}${!h.ansys_found && !h.project_found ? "and " : ""}${h.project_found ? "" : "the project file "}not found.</b> Check the paths at the top of ansys_bridge.py.`;
      $("brRun").disabled = !ready; connected = true; $("brStart").hidden = true; setPill(h.mock ? "practice" : ready ? "on" : "warn");
      if (poll) { clearInterval(poll); poll = 0; }
      return h;
    } catch (e) {
      connected = false; $("brStart").hidden = false; setPill("off");
      el.innerHTML = `<b class="badline">● Not connected.</b> Press <i>Start ANSYS connection</i>${window.__TAURI__ ? "" : " (or run <code>ansys_bridge\\start_bridge.bat</code>)"}.`;
      $("brRun").disabled = true;
    }
  }
  /* small status pill in the top bar, visible on every step */
  function setPill(s) {
    let p = $("ansysPill");
    if (!p) { p = document.createElement("button"); p.id = "ansysPill"; p.type = "button"; p.className = "ansyspill"; p.addEventListener("click", () => TS.app.showTab("ansys")); document.querySelector(".bar.fx").insertBefore(p, $("fxSeason")); }
    p.dataset.s = s; p.textContent = { on: "ANSYS ● connected", practice: "ANSYS ● practice mode", warn: "ANSYS ● check setup", off: "ANSYS ○ not connected" }[s];
  }
  // after "Start ANSYS connection", keep checking until the bridge answers (about a minute)
  $("brStart").addEventListener("click", () => {
    $("brStatus").innerHTML = "Starting the ANSYS connection… allow the Windows prompt.";
    let n = 0; if (poll) clearInterval(poll);
    poll = setInterval(() => { if (++n > 30) { clearInterval(poll); poll = 0; } health(); }, 2000);
  });
  /* run history, kept on this PC */
  const HKEY = "thermashelter.ansysruns.v1";
  let history = []; try { history = JSON.parse(localStorage.getItem(HKEY)) || []; } catch (e) {}
  function record(res, i, app, label) {
    const o = res.outputs || {};
    history.unshift({ t: new Date().toISOString().slice(0, 16).replace("T", " "), label: label || "", mock: !!res.mock, i, aMin: o.T_AIR_MIN, aMax: o.T_AIR_MAX, pMin: app.T_AIR_MIN, pMax: app.T_AIR_MAX, s: res.elapsed_s });
    history = history.slice(0, 30); try { localStorage.setItem(HKEY, JSON.stringify(history)); } catch (e) {}
    renderHistory();
  }
  function renderHistory() {
    const f = v => (v == null || !isFinite(v) ? "–" : (+v).toFixed(1).replace(/^-/, "−"));
    $("brHistory").innerHTML = history.length ? `<tr><th class="l">Run</th><th class="l">Design sent</th><th>ANSYS coldest</th><th>App coldest</th><th>ANSYS warmest</th><th>App warmest</th></tr>` +
      history.map(h => `<tr><td class="l">${h.t}${h.mock ? " (practice)" : ""}</td><td class="l">${h.label || `${h.i.L} × ${h.i.W} × ${h.i.H} m, ${Math.round(h.i.T_INS * 1000)} mm`}</td><td>${f(h.aMin)} °C</td><td>${f(h.pMin)} °C</td><td>${f(h.aMax)} °C</td><td>${f(h.pMax)} °C</td></tr>`).join("") : "";
  }
  /* start a job and wait for it (kit v1.0 endpoints) */
  async function runJob(i, onProgress) {
    const h = await call("/health");
    if ((h.contract_version || "1.0") !== CONTRACT) throw new Error(`bridge contract v${h.contract_version}, app v${CONTRACT}`);
    const { job_id } = await call("/run", { method: "POST", body: JSON.stringify(i) });
    for (;;) {
      await new Promise(r => setTimeout(r, 3000));
      const s = await call("/status/" + job_id);
      if (onProgress) onProgress(s);
      if (s.state === "error") throw new Error(s.error || "ANSYS run failed");
      if (s.state === "done") return call("/result/" + job_id);
    }
  }
  async function runAnsys() {
    const d = TS.app.S.design, i = inputsFrom(d), errs = validate(i), sentAs = TS.app.designName ? TS.app.designName(d) : "";   // name taken now: the user may switch designs while ANSYS runs
    if (errs.length) { $("brJob").textContent = "Not sent: " + errs.join("; "); return; }
    $("brRun").disabled = true;
    // the table on screen is the previous run until this one finishes
    if (TS.bridgeLast) { const w = $("brStale"); if (w) { w.hidden = false; w.textContent = "ANSYS is running the design above. The table below is still the previous run and will be replaced when this one finishes."; }
      $("brResult").style.opacity = $("brNote").style.opacity = 0.45; }
    try { const t0 = Date.now(), res = await runJob(i, s => ($("brJob").textContent = `ANSYS ${s.state}, ${Math.round((Date.now() - t0) / 1000)} s`));
      show(res, res.mock ? BASE : i, sentAs); }   // practice mode returns the stored base case: compare like with like
    catch (e) { $("brJob").textContent = "ANSYS run failed: " + e.message;
      if ($("brStale") && TS.bridgeLast) $("brStale").textContent = "The last run failed. The table below is from an earlier run, not the design above."; }
    finally { $("brRun").disabled = false; }
  }
  function show(res, i, sentAs) {
    const o = res.outputs || {}, app = appEquivalent(i);
    const f = v => (v == null || !isFinite(v) ? "–" : (+v).toFixed(1).replace(/^-/, "−"));
    const kw = v => (v == null || !isFinite(v) ? "–" : (Math.abs(v) >= 1000 ? (v / 1000).toFixed(2) + " kW" : Math.round(v) + " W").replace(/^-/, "−"));
    const pct = (a, b) => (b == null || !isFinite(b) || Math.abs(b) < 1 ? "–" : ((a - b) / Math.abs(b) * 100).toFixed(1).replace(/^-/, "−") + " %");
    $("brResult").innerHTML = (res.mock ? `<tr><td colspan="4" class="l"><b class="warnline">Practice mode:</b> ANSYS answers with the stored real run of the 5 × 4 × 2.8 m, 100 mm PUF base case, so the app column solves that same case.</td></tr>` : "") +
      `<tr><th class="l">Quantity</th><th>App, same case</th><th>ANSYS${res.mock ? " (stored run)" : ""}</th><th>App − ANSYS</th></tr>` +
      [["Coldest indoor air, day 2, °C", app.T_AIR_MIN_DAY2, o.T_AIR_MIN_DAY2], ["Warmest indoor air, day 2, °C", app.T_AIR_MAX_DAY2, o.T_AIR_MAX_DAY2],
       ["Coldest indoor air, whole 48 h (includes the −6 °C start), °C", app.T_AIR_MIN, o.T_AIR_MIN], ["Warmest indoor air, whole 48 h, °C", app.T_AIR_MAX, o.T_AIR_MAX]]
        .map(([k, a, b]) => `<tr><td>${k}</td><td>${f(a)}</td><td>${f(b)}</td><td class="err">${b == null ? "–" : f(a - b) + " K"}</td></tr>`).join("") +
      // arch model: rows above are the volume-average air (the app's air is fully mixed); hottest point for reference
      (o.T_AIR_PEAK != null ? `<tr><td>Hottest point in the air (warm layer under the roof), °C</td><td>–</td><td>${f(o.T_AIR_PEAK)}</td><td class="err">ANSYS only</td></tr>` : "") +
      (!app.Rx ? "" : `<tr><th class="l" colspan="4">Heat exchanged at the outer surfaces, lowest value (includes absorbed sunlight going back out; not room heat loss)</th></tr>` +
      ["Wall", "Roof", "Floor", "Window"].map(s => `<tr><td>${s}</td><td>${kw(app.Rx[s].min)}</td><td>${kw(o["Rx_" + s + "_min"])}</td><td class="err">${pct(app.Rx[s].min, o["Rx_" + s + "_min"])}</td></tr>`).join(""));
    $("brNote").innerHTML = `Inputs sent: ${Object.entries(i).map(([k, v]) => `${k} ${v}`).join(", ")}. Solved in ${res.elapsed_s != null ? Math.round(res.elapsed_s) + " s" : "–"}, contract v${res.contract_version || "1.0"}. ` +
      (i.MODEL === "arch" ? "Arch model (Shelter_Arch, built by script for this run): half-cylinder shell in 6 strips of 30°, each with its own sun and outside air, axis north–south, window in the south end wall. " : "") +
      "The app column solves exactly the ANSYS case: the wall build-up as one shell of the same thickness, R and heat capacity, glass block, well-mixed air with the occupant heat and air leakage, raised or ground floor, the same ambient functions and solar tables, −6 °C start. Day 2 leaves out the warm-up from the cold start. Nothing is adjusted to match. " +
      (res.window ? `Set in Mechanical for this design: ${res.window}.` : "This bridge did not report its settings; restart it so runs use contract 1.1.");
    const label = res.mock ? "Stored base case 5 × 4 × 2.8 m (practice)" : sentAs != null ? sentAs : TS.app.designName ? TS.app.designName(TS.app.S.design) : "";
    TS.bridgeLast = { res, i, app, label };
    record(res, i, app, label);
    if ($("brStale")) $("brStale").hidden = true;
    $("brResult").style.opacity = $("brNote").style.opacity = "";
  }
  function render() {
    $("brUrl").value = url;
    const i = inputsFrom(TS.app.S.design), errs = validate(i);
    $("brInputs").textContent = `${TS.app.designName ? TS.app.designName(TS.app.S.design) + ": " : ""}${i.MODEL === "arch" ? `arch model, length ${i.L} m, span ${i.W} m, shell` : `length ${i.L} m, breadth ${i.W} m, height ${i.H} m, wall`} build-up ${Math.round(i.T_INS * 1000)} mm (equivalent k ${i.K_INS} W/m·K), south window ${i.WIN_W} × ${i.WIN_H} m, occupants and equipment ${i.Q_INT} W, air change ${i.ACH} per hour, floor ${i.FLOOR ? "raised" : "on the ground"}` +
      (errs.length ? `. Cannot run: ${errs.join("; ")}` : ".") + winNote(TS.app.S.design, i);
    // results on screen belong to another design: say so instead of showing them as this design's
    const last = TS.bridgeLast, stale = last && !last.res.mock && JSON.stringify(last.i) !== JSON.stringify(i);
    let w = $("brStale");
    if (!w) { w = document.createElement("p"); w.id = "brStale"; w.className = "warnline"; $("brResult").parentNode.insertBefore(w, $("brResult")); }
    w.hidden = !stale;
    if (stale) w.textContent = `These results are for the previous design (${last.label || "sent earlier"}), not for the one above. Press "Run ANSYS on this design" to check this one.`;
    $("brResult").style.opacity = $("brNote").style.opacity = stale ? 0.45 : "";
    renderHistory(); health();
  }
  $("brUrl").addEventListener("change", e => { url = e.target.value.replace(/\/$/, ""); try { localStorage.setItem(KEY, JSON.stringify(url)); } catch (x) {} health(); });
  $("brCheck").addEventListener("click", health);
  /* Windows app only: start start_bridge.bat from the folder the user gives
     (scoped shell permission "start-ansys-bridge" in capabilities/default.json) */
  if (window.__TAURI__ && window.__TAURI__.shell) {
    const btn = document.createElement("button"); btn.type = "button"; btn.className = "ghost"; btn.textContent = "Start bridge on this PC";
    $("brCheck").after(btn);
    btn.addEventListener("click", async () => {
      const dir = prompt("Folder that contains start_bridge.bat", localStorage.getItem("thermashelter.bridgeDir") || "D:\\SIH26\\ANSYS_Integration_Kit\\bridge");
      if (!dir) return; try { localStorage.setItem("thermashelter.bridgeDir", dir); } catch (e) {}
      try { await window.__TAURI__.shell.Command.create("start-ansys-bridge", ["/C", "start", "Fluxion ANSYS bridge", "/D", dir, "start_bridge.bat"]).spawn(); setTimeout(health, 4000); }
      catch (e) { $("brStatus").textContent = "Could not start the bridge: " + e; }
    });
  }
  $("brRun").addEventListener("click", runAnsys);
  TS.bridgeUI = { render, show, inputsFrom, validate, appEquivalent, ANSYS_AMBIENT, runJob, CONTRACT, health, record, history: () => history, call };
  health(); setInterval(() => { if (!connected && !poll) health(); }, 30000);
})();
