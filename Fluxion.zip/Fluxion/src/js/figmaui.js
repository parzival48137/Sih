/* Shell in the team's Figma Make visual language: live KPI ticker, UTC clock,
   season chips, site pill, compact cards. Every ticker value is read from the
   engine result of the current design; nothing on it is decorative. */
(function () {
  "use strict";
  const TS = window.TS, A = TS.app, $ = id => document.getElementById(id);
  const f1 = v => (v == null || !isFinite(v) ? "–" : (+v).toFixed(1)).replace(/^-/, "−");
  const f2 = v => (v == null || !isFinite(v) ? "–" : (+v).toFixed(2)).replace(/^-/, "−");

  /* keep only the lines that carry a result; everything else is hidden */
  ["wxText", "msLoopStatus", "sdStatus", "brStatus", "brJob", "dpStatus", "liveStatus", "wxstatus", "plainText", "optSummary", "fStormText", "liveNow", "flowLede", "solarLede"]
    .forEach(id => { const e = $(id); if (e) e.classList.add("keep"); });
  document.querySelectorAll("#msVerify, #msGeo").forEach(e => e.classList.add("keep"));
  document.body.classList.add("compact");
  // design checks: title visible, detail on tap
  document.addEventListener("click", e => { const c = e.target.closest(".check"); if (c && !e.target.closest("button")) c.classList.toggle("open"); });

  /* clock */
  // local time of this PC (IST in India), not UTC
  const tz = (() => { try { const p = new Intl.DateTimeFormat("en-IN", { timeZoneName: "short" }).formatToParts(new Date()).find(x => x.type === "timeZoneName"); return p ? p.value : ""; } catch (e) { return ""; } })();
  const tick = () => { const n = new Date();
    $("fxClock").innerHTML = `<b>${n.toLocaleTimeString("en-GB", { hour12: false })}</b><span>${n.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" }).toUpperCase()}${tz ? " · " + (tz === "GMT+5:30" ? "IST" : tz) : ""}</span>`; };
  tick(); setInterval(tick, 1000);

  /* season chips -> month */
  document.querySelectorAll("#fxSeason button").forEach(b => b.addEventListener("click", () => {
    const sel = $("month"); sel.value = b.dataset.m; sel.dispatchEvent(new Event("change"));
  }));
  $("fxSite").addEventListener("click", () => A.showTab("site"));
  /* route tab clicks through TS.app.showTab so every stage's renderer runs */
  document.querySelectorAll(".fxtabs button").forEach(b => b.addEventListener("click", () => TS.app.showTab(b.dataset.tab)));

  /* ticker */
  let lastR = null;
  function ticker() {
    const R = A.R; if (!R) return;
    const rec = A.siteRec(), site = A.buildSite(), m = A.S.site.month;
    document.querySelectorAll("#fxSeason button").forEach(b => b.setAttribute("aria-selected", String(+b.dataset.m === [0, 3, 6, 9].reduce((p, c) => (m >= c ? c : p), 0))));
    $("fxSite").innerHTML = `<i></i>${rec.name}<span>${Math.round(site.alt)} m</span>`;
    if (R === lastR) return; lastR = R;
    const d = A.S.design, s = R.summary, prof = document.documentElement.dataset.profile || "defence";
    const P = TS.field.PROFILES[prof], heatMean = R.heated.op.reduce((a, v) => a + v, 0) / R.N;
    const st0 = A.status();
    // GO / CAUTION / NO-GO pill in the header, next to the place and the ANSYS status
    let sp = $("statusPill");
    if (!sp) { sp = document.createElement("button"); sp.type = "button"; sp.id = "statusPill"; sp.className = "statuspill"; sp.addEventListener("click", () => A.showTab("design")); $("fxSite").after(sp); }
    sp.dataset.s = st0.level; sp.textContent = st0.label; sp.title = st0.reasons.concat(st0.warns).join("; ") || "Every check passes";
    const st = st0, cond = st.condensation ? "RISK" : "SAFE", condCls = st.condensation ? "bad" : "ok", stCls = { go: "ok", caution: "warn", nogo: "bad" }[st.level], why = st.reasons.concat(st.warns);
    const al = TS.stages && TS.stages.lastAlert, wx = al ? (al.al.level === "SEVERE" ? ["SEVERE COLD WAVE", "bad"] : al.al.level === "WATCH" ? ["COLD WAVE WATCH", "warn"] : ["STABLE", "ok"]) : ["NOT SYNCED", ""];
    const peak = Math.max(...R.heated.phi) / 1000, units = d.units || 1;
    const item = (k, v, cls, tip) => `<span class="ti"${tip ? ` title="${tip.replace(/"/g, "&quot;")}"` : ""}><em>${k}</em><b class="${cls || ""}">${v}</b></span>`;
    $("fxTicker").innerHTML = `<div class="track">` +
      item("Status", st.label + (why.length ? ": " + why[0] + (why.length > 1 ? ` (+${why.length - 1} more)` : "") : ""), stCls, why.join("; ")) +
      item("Design", A.designName(d)) +
      item("Place", `${rec.name}, ${A.MONTHS[m]}`) +
      item("Coldest inside, no heating", f1(s.passive.nightMin) + " °C", s.passive.nightMin < 0 ? "cold" : "") +
      item("Average inside, with heater", f1(heatMean) + " °C", "ok") +
      item("Kerosene", f2(s.fuel_L * units) + " L/day" + (units > 1 ? ` (${units} shelters)` : ""), "amber") +
      item("Biggest heater load", f2(peak) + " kW", "hot") +
      item("Damp on walls", cond === "RISK" ? "risk" : "none", condCls) +
      item("Fresh air (CO₂)", Math.round(R.co2 ? R.co2.max : s.co2_ppm) + " ppm", (R.co2 ? R.co2.max : 0) > 1000 ? "warn" : "ok") +
      (al ? item("Forecast", wx[0], wx[1]) : "") + `</div>`;
  }
  setInterval(ticker, 700); ticker();
  TS.figmaui = { ticker };
})();
