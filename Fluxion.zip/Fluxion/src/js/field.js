/* Field check: the front door for people who know the place, the shelter and
   the headcount, but not U-values or albedo. Everything else is derived from
   those answers, each derived value carries its source, and the answer is
   given with the spread caused by what the user could not know.
   Same engine as the Designer; nothing in engine.js changes for this mode. */
(function (g) {
  "use strict";
  const TS = g.TS;
  const L = (mat, t) => ({ mat, t });

  /* ------------------------------------------------------------ profiles */
  const PROFILES = {
    defence: {
      name: "Defence", users: "army and MES engineers",
      target: 14, targetNote: "lower edge of the 17 ± 3 °C band",
      safeFloor: 14, safeNote: "lower edge of the 17 ± 3 °C band",
      space: 3.5, spaceNote: "Sphere minimum covered area",
      fuels: ["kerosene"], logistics: "jerrycans (20 L)",
      types: ["arctic", "frp6", "frp10", "prefab_puf", "smartcamp", "pod", "arch_solar", "arch_nissen", "solarO2", "ladakhi", "dome_tent", "igloo", "bothy"],
    },
    relief: {
      name: "Disaster relief", users: "District officers, NDMA/SDMA, NDRF, NGOs",
      target: 18, targetNote: "WHO Housing and Health Guidelines (2018)",
      safeFloor: 11, safeNote: "acceptable lower limit used by Thapa et al. for Nepal earthquake shelters",
      space: 4.5, spaceNote: "Sphere, cold climates: 4.5–5.5 m² per person",
      fuels: ["kerosene", "lpg", "wood"], logistics: "jerrycans (20 L) or 14.2 kg cylinders",
      types: ["tent_basic", "tent_winter", "prefab_eps", "bamboo", "hall", "hut", "dome_tent", "igloo", "bothy"],
    },
  };

  /* Fuel energy: kerosene IPCC 2006 NCV; LPG 46 MJ/kg; air-dry wood ~15 MJ/kg.
     Efficiencies and burn rates other than kerosene are assumptions to be
     confirmed; all are editable in the Designer. */
  const FUELS = {
    kerosene: { name: "Kerosene", unit: "L", kwh: 9.58, eta: 0.60, burn: 0.7, pack: 20, packName: "jerrycan", note: "60 % heater efficiency (team decision), 0.7 L/h maximum burn" },
    lpg:      { name: "LPG",      unit: "kg", kwh: 12.8, eta: 0.60, burn: 0.30, pack: 14.2, packName: "cylinder", note: "assumed 60 % efficiency, 0.3 kg/h maximum" },
    wood:     { name: "Firewood", unit: "kg", kwh: 4.2,  eta: 0.30, burn: 2.0, pack: 40, packName: "bundle of 40 kg", note: "assumed 30 % for a basic flued heater, 2 kg/h maximum" },
  };

  /* Shelter types. ach = median air changes/h; achF = spread factor (the
     unknown the user cannot measure); uF = spread of conductivities. */
  const TYPES = {
    tent_basic: { name: "Family tent, double fly", kind: "tent", icon: "tent",
      L: 4, W: 4, H: 2.0, orient: 180, absorptance: 0.5, glazing: "single", shutter: false, berm: false,
      wall: [L("canvas", 0.001), L("airgap", 0.05), L("canvas", 0.001)],
      roof: [L("canvas", 0.001), L("airgap", 0.05), L("canvas", 0.001)],
      floor: [L("pesheet", 0.0005)],
      win: { front: 0, right: 0, back: 0, left: 0 }, store: { type: "none", mass: 0 }, ach: 3.0, achF: 2.0, uF: 0.2,
      note: "UNHCR/IFRC family tent size (16 m²). Fabric leaks air; the value is uncertain, so it is varied." },
    tent_winter: { name: "Winterised tent, liner and floor mat", kind: "tent", icon: "tent2",
      L: 4, W: 4, H: 2.0, orient: 180, absorptance: 0.5, glazing: "single", shutter: false, berm: false,
      wall: [L("canvas", 0.001), L("airgap", 0.05), L("canvas", 0.001), L("felt", 0.01)],
      roof: [L("canvas", 0.001), L("airgap", 0.05), L("canvas", 0.001), L("felt", 0.01)],
      floor: [L("pesheet", 0.0005), L("eps", 0.02)],
      win: { front: 0, right: 0, back: 0, left: 0 }, store: { type: "none", mass: 0 }, ach: 2.0, achF: 2.0, uF: 0.2,
      note: "Same tent with a 10 mm felt liner and a 20 mm foam floor mat." },
    prefab_eps: { name: "Prefab cabin, 50 mm EPS panels", kind: "light", icon: "cabin",
      L: 6, W: 3.5, H: 2.6, orient: 180, absorptance: 0.5, glazing: "single", shutter: false, berm: false,
      wall: [L("steel", 0.0004), L("eps", 0.05), L("steel", 0.0004)],
      roof: [L("steel", 0.0004), L("eps", 0.05), L("steel", 0.0004)],
      floor: [L("steel", 0.0004), L("eps", 0.05), L("plywood", 0.018)],
      win: { front: 1.2, right: 0, back: 0, left: 0 }, store: { type: "none", mass: 0 }, ach: 1.0, achF: 1.6, uF: 0.15,
      note: "Colour-steel sandwich cabin of the kind used after the Wenchuan earthquake." },
    bamboo: { name: "Bamboo or timber transitional shelter", kind: "light", icon: "hut",
      L: 5, W: 3, H: 2.4, orient: 180, absorptance: 0.6, glazing: "single", shutter: false, berm: false,
      wall: [L("bamboo", 0.012), L("mudplast", 0.01)],
      roof: [L("steel", 0.0005), L("bamboo", 0.012)],
      floor: [L("rammed", 0.05)],
      win: { front: 0.8, right: 0, back: 0, left: 0 }, store: { type: "none", mass: 0 }, ach: 2.5, achF: 2.0, uF: 0.2,
      note: "Light local-material shelter of the kind used after the Lushan earthquake." },
    hall: { name: "School or community hall (brick)", kind: "heavy", icon: "hall",
      L: 10, W: 6, H: 3.2, orient: 180, absorptance: 0.6, glazing: "single", shutter: false, berm: false,
      wall: [L("cplaster", 0.015), L("brick", 0.23), L("cplaster", 0.015)],
      roof: [L("concrete", 0.12), L("cplaster", 0.012)],
      floor: [L("concrete", 0.10)],
      win: { front: 6, right: 0, back: 3, left: 0 }, store: { type: "none", mass: 0 }, ach: 1.0, achF: 1.6, uF: 0.15,
      note: "Uninsulated brick building used as a relief centre." },
    /* Army habitat types reported for eastern Ladakh (2020): arctic tents for
       2-4, fibreglass huts for 4-6 and 8-10, fast-erectable modular shelters
       and smart camps. Constructions below are typical assumptions; replace
       them with the actual specifications when available. */
    arctic: { name: "Arctic tent, 2-4 men", kind: "tent", icon: "tent2", mil: true,
      L: 3.5, W: 3.0, H: 2.0, orient: 180, absorptance: 0.6, glazing: "single", shutter: false, berm: false,
      wall: [L("canvas", 0.001), L("airgap", 0.05), L("canvas", 0.001), L("felt", 0.02)],
      roof: [L("canvas", 0.001), L("airgap", 0.05), L("canvas", 0.001), L("felt", 0.02)],
      floor: [L("pesheet", 0.0005), L("eps", 0.03)],
      win: { front: 0, right: 0, back: 0, left: 0 }, store: { type: "none", mass: 0 }, ach: 1.5, achF: 2.0, uF: 0.2,
      note: "Double-wall arctic tent with insulating liner (assumed construction)." },
    frp6: { name: "Fibreglass hut, 4-6 men", kind: "light", icon: "cabin", mil: true,
      L: 5.0, W: 3.0, H: 2.5, orient: 180, absorptance: 0.5, glazing: "double", shutter: false, berm: false,
      wall: [L("grp", 0.004), L("puf", 0.06), L("grp", 0.004)], roof: [L("grp", 0.004), L("puf", 0.06), L("grp", 0.004)],
      floor: [L("grp", 0.004), L("puf", 0.05), L("plywood", 0.018)],
      win: { front: 0.8, right: 0, back: 0, left: 0 }, store: { type: "none", mass: 0 }, ach: 0.8, achF: 1.6, uF: 0.15,
      note: "GRP-skinned PUF sandwich hut (assumed 60 mm core)." },
    frp10: { name: "Fibreglass hut, 8-10 men", kind: "light", icon: "cabin", mil: true,
      L: 7.0, W: 4.0, H: 2.6, orient: 180, absorptance: 0.5, glazing: "double", shutter: false, berm: false,
      wall: [L("grp", 0.004), L("puf", 0.06), L("grp", 0.004)], roof: [L("grp", 0.004), L("puf", 0.06), L("grp", 0.004)],
      floor: [L("grp", 0.004), L("puf", 0.05), L("plywood", 0.018)],
      win: { front: 1.2, right: 0, back: 0, left: 0 }, store: { type: "none", mass: 0 }, ach: 0.8, achF: 1.6, uF: 0.15,
      note: "GRP-skinned PUF sandwich hut (assumed 60 mm core)." },
    smartcamp: { name: "Smart camp block", kind: "light", icon: "hall", mil: true,
      L: 10.0, W: 6.0, H: 3.0, orient: 180, absorptance: 0.5, glazing: "lowe", shutter: true, berm: false,
      wall: [L("steel", 0.0005), L("puf", 0.10), L("steel", 0.0005)], roof: [L("steel", 0.0005), L("puf", 0.12), L("steel", 0.0005)],
      floor: [L("steel", 0.0005), L("puf", 0.08), L("plywood", 0.018)],
      win: { front: 4, right: 0, back: 0, left: 0 }, store: { type: "none", mass: 0 }, ach: 0.6, achF: 1.6, uF: 0.1,
      note: "Integrated habitat block with heating, power and water (assumed 100 mm PUF)." },
    /* Mountaineering, emergency and advanced high-altitude types */
    dome_tent: { name: "Geodesic dome tent, 4-season", kind: "tent", icon: "tent", shape: "dome",
      L: 2.6, W: 2.6, H: 1.3, orient: 180, absorptance: 0.6, glazing: "single", shutter: false, berm: false,
      wall: [L("canvas", 0.001), L("airgap", 0.04), L("canvas", 0.001)], roof: [L("canvas", 0.001), L("airgap", 0.04), L("canvas", 0.001)],
      floor: [L("pesheet", 0.0005), L("eps", 0.01)], win: { front: 0, right: 0, back: 0, left: 0 }, store: { type: "none", mass: 0 }, ach: 2.0, achF: 2.0, uF: 0.2,
      note: "Low, aerodynamic double-wall dome (modelled as a hemisphere)." },
    igloo: { name: "Snow cave / igloo", kind: "snow", icon: "tent2", shape: "dome",
      L: 3.0, W: 3.0, H: 1.5, orient: 180, absorptance: 0.3, glazing: "single", shutter: false, berm: false,
      wall: [L("snow", 0.4)], roof: [L("snow", 0.4)], floor: [L("snow", 0.3), L("pesheet", 0.0005), L("felt", 0.02)],
      win: { front: 0, right: 0, back: 0, left: 0 }, store: { type: "none", mass: 0 }, ach: 0.6, achF: 2.0, uF: 0.25,
      note: "Packed-snow dome with a vent hole; needs about 1.2 m of stable snow. Inner surfaces must stay below 0 °C." },
    bothy: { name: "Bothy bag (emergency, 2-4)", kind: "tent", icon: "tent",
      L: 1.8, W: 1.2, H: 1.0, orient: 180, absorptance: 0.6, glazing: "single", shutter: false, berm: false,
      wall: [L("canvas", 0.0005)], roof: [L("canvas", 0.0005)], floor: [L("pesheet", 0.0005)],
      win: { front: 0, right: 0, back: 0, left: 0 }, store: { type: "none", mass: 0 }, ach: 3.0, achF: 2.0, uF: 0.2,
      note: "Single-skin windproof group cover; body heat is the only heat source." },
    hut: { name: "Alpine hut (stone, timber lining)", kind: "heavy", icon: "house",
      L: 8, W: 5, H: 2.8, orient: 180, absorptance: 0.6, glazing: "double", shutter: true, berm: false,
      wall: [L("stone", 0.4), L("airgap", 0.03), L("timber", 0.025)], roof: [L("steel", 0.0005), L("rockwool", 0.15), L("timber", 0.025)],
      floor: [L("concrete", 0.15), L("xps", 0.05), L("timber", 0.025)], win: { front: 3, right: 0, back: 0, left: 0 }, store: { type: "none", mass: 0 }, ach: 0.8, achF: 1.6, uF: 0.15,
      note: "Permanent mountain hut, stone walls with an inner timber lining." },
    pod: { name: "Modular pod (rounded, relocatable)", kind: "light", icon: "cabin", shape: "vault", mil: true,
      L: 6, W: 3, H: 1.5, orient: 180, absorptance: 0.5, glazing: "triple", shutter: false, berm: false, floorMode: "raised",
      wall: [L("alu", 0.001), L("pir", 0.10), L("plywood", 0.012)], roof: [L("alu", 0.001), L("pir", 0.10), L("plywood", 0.012)],
      floor: [L("alu", 0.001), L("pir", 0.10), L("plywood", 0.018)], win: { front: 1.2, right: 0, back: 0, left: 0 }, store: { type: "none", mass: 0 }, ach: 0.5, achF: 1.6, uF: 0.1,
      note: "Lightweight half-cylinder pod on skids, no foundation work (assumed 100 mm PIR)." },
    arch_solar: { name: "Insulated arch shelter with solar panels", kind: "light", icon: "hall", shape: "vault", mil: true,
      L: 9, W: 6, H: 3, orient: 180, absorptance: 0.5, glazing: "double", shutter: true, berm: false, floorMode: "raised",
      wall: [L("steel", 0.0005), L("puf", 0.08), L("plywood", 0.012)], roof: [L("steel", 0.0005), L("puf", 0.08), L("plywood", 0.012)],
      floor: [L("steel", 0.0005), L("puf", 0.06), L("plywood", 0.018)], win: { front: 1.5, right: 0, back: 0, left: 0 }, store: { type: "none", mass: 0 }, ach: 0.5, achF: 1.6, uF: 0.12,
      pv: true, color: 0xf2c200,
      note: "Army-type arch (half-cylinder) shelter: painted steel skin, PUF core, plywood lining, solar panels on the arch for power (typical build-up, assumed 80 mm PUF)." },
    arch_nissen: { name: "Corrugated-iron arch hut (Nissen / Quonset type)", kind: "light", icon: "hall", shape: "vault", mil: true,
      L: 10, W: 5, H: 2.5, orient: 180, absorptance: 0.6, glazing: "single", shutter: false, berm: false,
      wall: [L("steel", 0.0006), L("airgap", 0.05), L("plywood", 0.009)], roof: [L("steel", 0.0006), L("airgap", 0.05), L("plywood", 0.009)],
      floor: [L("concrete", 0.10)], win: { front: 1.0, right: 0, back: 0, left: 0 }, store: { type: "none", mass: 0 }, ach: 1.0, achF: 1.6, uF: 0.2,
      corrugated: true, color: 0xb59a5a,
      note: "Corrugated galvanised-steel arch on a concrete slab with a thin plywood lining and no insulation (typical older build-up)." },
    solarO2: { name: "Solar-oxygenated PUF/PCM shelter", kind: "light", icon: "hall", mil: true,
      L: 6, W: 4, H: 2.7, orient: 180, absorptance: 0.6, glazing: "lowe", shutter: true, berm: false,
      wall: [L("steel", 0.0005), L("puf", 0.10), L("steel", 0.0005)], roof: [L("steel", 0.0005), L("puf", 0.12), L("steel", 0.0005)],
      floor: [L("steel", 0.0005), L("puf", 0.08), L("plywood", 0.018)], win: { front: 3.5, right: 0, back: 0, left: 0 },
      store: { type: "pcm", mass: 400, Tm: 18 }, mech: { ach: 0.5, eff: 0.75 }, o2: 23.0, ach: 0.4, achF: 1.6, uF: 0.1,
      note: "PUF panels, PCM store, heat-recovery ventilation and oxygen enrichment to 23 %." },
    prefab_puf: Object.assign({ kind: "light", icon: "cabin", achF: 1.6, uF: 0.1, ach: 0.5,
      note: "Prefab PUF sandwich box, as in the Designer." }, TS.PRESETS.prefab, { name: "Prefab PUF sandwich box" }),
    ladakhi: Object.assign({ kind: "heavy", icon: "house", achF: 1.6, uF: 0.15, ach: 0.5,
      note: "Insulated mud-brick passive solar room, as in the Designer." }, TS.PRESETS.passive, { name: "Ladakhi passive solar room" }),
  };

  const clone = o => JSON.parse(JSON.stringify(o));

  /* -------------------------------------------- answers -> full model */
  function derive(ans) {
    const P = PROFILES[ans.profile], T = TYPES[ans.type], F = FUELS[ans.fuel];
    const rec = TS.SITES.find(s => s.id === ans.site) || TS.SITES[0];
    const lapse = 6.5 * (rec.cell.elev - rec.alt) / 1000;
    const annual = rec.T2M.reduce((s, v) => s + v, 0) / 12 + lapse;
    const monthMean = rec.T2M[ans.month] + lapse;
    const snow = monthMean < 0;
    const site = TS.engine.siteFrom(rec, ans.month, { albedo: snow ? 0.6 : 0.2, Tground: annual });
    let d = clone(T);
    Object.assign(d, { people: ans.people, wPerson: 75, equipW: 0 });
    const AR = TS.logistics && ans.archetype && TS.logistics.ARCHETYPES[ans.archetype];
    if (AR && AR.apply) d = AR.apply(d);
    const ops = { setpoint: P.target, eta: F.eta, burnMax: ans.stove ? F.burn : 0.0001, kwhPerL: F.kwh, band: [P.target, P.target + 6], withSolarFraction: false };
    const sources = [
      ["Outdoor temperature", `${f1(site.Tmin)} to ${f1(site.Tmax)} °C`, `NASA POWER ${MONTHS[ans.month]} mean, moved to ${rec.alt} m`],
      ["Sun on the ground", `${f1(site.H)} kWh/m² a day`, "NASA POWER monthly mean"],
      ["Ground under the floor", `${f1(annual)} °C`, "site's annual mean air temperature (standard estimate for ground below frost depth)"],
      ["Ground cover", snow ? "snow (albedo 0.6)" : "bare ground (albedo 0.2)", snow ? "monthly mean below 0 °C" : "monthly mean above 0 °C"],
      ["Air leakage", `${T.ach} air changes per hour (varied ×÷${T.achF})`, "typical for this shelter type; not measurable by eye, so it is varied"],
      ["Heat per person", "75 W", "resting adult"],
      ...(AR && AR.note ? [["Disaster type", AR.name, AR.note + (AR.forbid && TS.logistics.heavyLayers(d).length && ans.archetype === "quake" ? " This shelter has heavy layers: " + TS.logistics.heavyLayers(d).join(", ") + "." : "")]] : []),
      ["Heater", ans.stove ? `${F.name}, up to ${f1(F.burn * F.kwh * F.eta)} kW` : "none", F.note],
    ];
    return { P, T, F, rec, site, d, ops, sources };
  }

  /* -------------------------------------------- deterministic answers */
  function nightMin(r, which) {
    const a = r[which].op, idx = r.night.map((n, i) => (n ? i : -1)).filter(i => i >= 0);
    return idx.length ? Math.min(...idx.map(i => a[i])) : Math.min(...a);
  }
  /* Capacity is set by floor space (Sphere). Air is then checked: the air
     changes needed to keep CO2 at or under 1000 ppm for that many people, and
     what opening a vent that far costs in fuel. */
  function capacity(m, people) {
    const { d, site, P } = m;
    const GM = TS.engine.geom(d), Af = GM.Af, V = GM.V;
    const rho = TS.engine.airDensity(site.alt, site.Tmean);
    const G = 0.0052 * (1.2 / rho);                       // L/s CO2 per person
    const nSpace = Math.max(1, Math.floor(Af / P.space));
    const n = people || nSpace;
    const achNeed = n * G / ((1000 - 420) * 1e-6) * 3.6 / V; // air changes/h for 1000 ppm
    const co2Now = 420 + 1e6 * n * G / (d.ach * V / 3.6);
    let extraFuel = 0;
    if (achNeed > d.ach) {
      const a = TS.engine.simulate(d, site, m.ops), b = TS.engine.simulate(Object.assign({}, d, { ach: achNeed }), site, m.ops);
      extraFuel = b.summary.fuel_L - a.summary.fuel_L;
    }
    return { Af, nSpace, n, achNeed, achHave: d.ach, co2Now, extraFuel };
  }
  /* Stoves needed: peak heat demand with no stove limit / one stove's output */
  function stovesNeeded(m) {
    const r = TS.engine.simulate(m.d, m.site, Object.assign({}, m.ops, { burnMax: 1000 }));
    const peak = Math.max(...r.heated.phi) / 1000, one = m.F.burn * m.F.kwh * m.F.eta;
    return { peak, one, n: Math.max(1, Math.ceil(peak / one - 1e-9)) };
  }

  /* Blizzard stress test: two normal design days, then three days with no
     sun, temperature lowered by dT, wind doubled. A scenario, not a statistic. */
  function stressTest(m, dT) {
    const base = TS.engine.simulate(m.d, m.site, m.ops);
    const hourly = [];
    for (let d = 0; d < 5; d++) for (let h = 0; h < 24; h++) {
      const storm = d >= 2;
      hourly.push({ T: base.amb[h] - (storm ? dT : 0) - (storm ? (base.amb[h] - Math.min(...base.amb)) * 0.5 : 0),
        GHI: storm ? 0 : base.ghi[h], ws: m.site.wind * (storm ? 2 : 1) });
    }
    const s = Object.assign({}, m.site, { hourly });
    return TS.engine.simulate(m.d, s, m.ops);
  }

  /* -------------------------------------------- uncertainty (Monte Carlo) */
  function rng(seed) { let x = seed >>> 0 || 1; return () => ((x ^= x << 13, x ^= x >>> 17, x ^= x << 5) >>> 0) / 4294967296; }
  function normal(r) { const u = Math.max(r(), 1e-12), v = r(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); }
  /* Latin hypercube in 3 dimensions: air leakage, conductivity scale, ground temperature */
  function samples(n, seed) {
    const r = rng(seed), out = [];
    const strata = () => { const a = Array.from({ length: n }, (_, i) => (i + r()) / n); for (let i = n - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
    const a = strata(), b = strata(), c = strata();
    const probit = p => { // inverse normal CDF (Acklam)
      const q = Math.min(Math.max(p, 1e-9), 1 - 1e-9), A = [-39.69683028665376, 220.9460984245205, -275.9285104469687, 138.357751867269, -30.66479806614716, 2.506628277459239],
        B = [-54.47609879822406, 161.5858368580409, -155.6989798598866, 66.80131188771972, -13.28068155288572], Cc = [-0.007784894002430293, -0.3223964580411365, -2.400758277161838, -2.549732539343734, 4.374664141464968, 2.938163982698783],
        D = [0.007784695709041462, 0.3224671290700398, 2.445134137142996, 3.754408661907416];
      if (q < 0.02425) { const t = Math.sqrt(-2 * Math.log(q)); return (((((Cc[0] * t + Cc[1]) * t + Cc[2]) * t + Cc[3]) * t + Cc[4]) * t + Cc[5]) / ((((D[0] * t + D[1]) * t + D[2]) * t + D[3]) * t + 1); }
      if (q > 1 - 0.02425) { const t = Math.sqrt(-2 * Math.log(1 - q)); return -(((((Cc[0] * t + Cc[1]) * t + Cc[2]) * t + Cc[3]) * t + Cc[4]) * t + Cc[5]) / ((((D[0] * t + D[1]) * t + D[2]) * t + D[3]) * t + 1); }
      const t = q - 0.5, s2 = t * t; return (((((A[0] * s2 + A[1]) * s2 + A[2]) * s2 + A[3]) * s2 + A[4]) * s2 + A[5]) * t / (((((B[0] * s2 + B[1]) * s2 + B[2]) * s2 + B[3]) * s2 + B[4]) * s2 + 1);
    };
    for (let i = 0; i < n; i++) out.push({ z1: probit(a[i]), z2: probit(b[i]), z3: probit(c[i]) });
    return out;
  }
  function perturb(m, z, stats) {
    const d = clone(m.d), site = Object.assign({}, m.site), T = m.T;
    d.ach = T.ach * Math.pow(T.achF, z.z1 / 1.645);           // 90 % of draws within ×÷achF
    const k = Math.max(0.6, 1 + T.uF * z.z2 / 1.645);
    for (const el of ["wall", "roof", "floor"]) d[el] = d[el].map(l => {
      const p = TS.engine.layerProps(l, TS.MATERIALS);
      return p.k == null ? l : Object.assign({}, l, { k: p.k * k });
    });
    site.Tground = m.site.Tground + 2 * z.z3;                  // ±2 K, 1 sigma
    if (stats) { site.Tmin += stats.sigmaT * z.z3; site.Tmax += stats.sigmaT * z.z3; }
    return { d, site };
  }
  function percentile(a, p) { const s = a.slice().sort((x, y) => x - y); const i = (s.length - 1) * p; const lo = Math.floor(i); return s[lo] + (s[Math.ceil(i)] - s[lo]) * (i - lo); }
  /* Runs n samples in chunks so the screen stays responsive. */
  function monteCarlo(m, n, onDone, seed) {
    const zs = samples(n, seed || 2026), stats = TS.SITE_STATS && TS.SITE_STATS[m.rec.id] && TS.SITE_STATS[m.rec.id][m.site.month];
    const out = []; let i = 0;
    const tick = () => {
      const end = Math.min(n, i + 15);
      for (; i < end; i++) {
        const p = perturb(m, zs[i], stats);
        const r = TS.engine.simulate(p.d, p.site, m.ops);
        out.push({ pas: nightMin(r, "passive"), heat: nightMin(r, "heated"), fuel: r.summary.fuel_L, unmet: r.summary.unmetHours });
      }
      if (i < n) setTimeout(tick, 0); else onDone(summarise(out, m), out);
    };
    tick();
  }
  function summarise(out, m) {
    const n = out.length, floor = m.P.safeFloor;
    const p = (k) => out.filter(o => o[k] >= floor - 0.05).length / n;
    const se = q => Math.sqrt(q * (1 - q) / n);
    const fuel = out.map(o => o.fuel);
    return { n, pPassive: p("pas"), pHeated: p("heat"), sePassive: se(p("pas")), seHeated: se(p("heat")),
      fuelP50: percentile(fuel, 0.5), fuelP95: percentile(fuel, 0.95),
      pasP5: percentile(out.map(o => o.pas), 0.05), pasP50: percentile(out.map(o => o.pas), 0.5),
      weather: !!(TS.SITE_STATS && TS.SITE_STATS[m.rec.id]) };
  }

  /* -------------------------------------------- what to do first */
  function actions(m) {
    const base = TS.engine.simulate(m.d, m.site, m.ops);
    const cands = [];
    const add = (name, how, fn) => { const d = clone(m.d); if (fn(d) !== false) cands.push({ name, how, d }); };
    const insideIns = (d, mat, t) => { for (const el of ["wall", "roof"]) d[el].push({ mat, t }); };
    if (!m.d.wall.some(l => l.mat === "felt")) add("Add an insulating liner", "10 mm felt or blankets on walls and roof, inside", d => insideIns(d, "felt", 0.01));
    if (!m.d.floor.some(l => TS.MATERIALS[l.mat].cls === "ins")) add("Insulate the floor", "20 mm foam mat or straw under the bedding", d => { d.floor.push({ mat: "eps", t: 0.02 }); });
    add("Seal gaps and doors", "close flaps, tape seams, add a door curtain: about 40 % less leakage", d => { d.ach = Math.max(0.3, d.ach * 0.6); });
    const glass = Object.values(m.d.win).reduce((s, v) => s + v, 0);
    if (glass > 0 && !m.d.shutter) add("Cover windows at night", "blanket or board over the glass after sunset", d => { d.shutter = true; });
    if (m.T.kind !== "tent" && !m.d.wall.some(l => TS.MATERIALS[l.mat].cls === "ins" && l.t >= 0.05))
      add("Insulate the walls", "50 mm EPS boards fixed inside", d => insideIns(d, "eps", 0.05));
    return cands.map(c => {
      const r = TS.engine.simulate(c.d, m.site, m.ops);
      return { name: c.name, how: c.how, fuelSaved: base.summary.fuel_L - r.summary.fuel_L, warmer: nightMin(r, "passive") - nightMin(base, "passive"),
        heatedWarmer: nightMin(r, "heated") - nightMin(base, "heated") };
    }).filter(a => a.fuelSaved > 0.01 || a.warmer > 0.2 || a.heatedWarmer > 0.2)
      // when the stove cannot keep up, what matters is a warmer night, not fuel
      .sort(base.summary.unmetHours > 0 ? (a, b) => b.heatedWarmer - a.heatedWarmer : (a, b) => b.fuelSaved - a.fuelSaved || b.warmer - a.warmer).slice(0, 3);
  }

  const MONTHS = ["January","February","March","April","May","June","July","August","September","October","November","December"];
  function f1(v) { return (v == null || !isFinite(v) ? "–" : (+v).toFixed(1)).replace(/^-/, "−"); }

  TS.field = { PROFILES, FUELS, TYPES, derive, capacity, stovesNeeded, stressTest, monteCarlo, summarise, actions, nightMin, samples, perturb, MONTHS };
  if (typeof module !== "undefined") module.exports = TS;
})(typeof window !== "undefined" ? window : globalThis);
