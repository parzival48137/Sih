/* The ANSYS arch case (Shelter_Arch.wbpj, built by ansys_bridge/arch_model.py) solved by the app, so
   "App - ANSYS" compares like with like for arch shelters. Half-cylinder shell of span W (outer radius
   W/2), length L, thickness T_INS in 6 strips of 30 deg (east-low .. west-low), flat end walls inside the
   shell (south one with the window), floor slab, well-mixed air (k_eff 10). Per strip: absorbed sun from
   the box model's tables split into direct / diffuse / snow-reflected light at the strip's tilt, and outside
   air mixing the box wall and roof conditions by sky view. Exposed 0.1 m edges adiabatic, as in ANSYS.
   Window sun lands on the floor; results are the well-mixed (average) air. Same numerics as ansyscase.js. CASE data from `python ansys_bridge/arch_model.py --js`. */
(function (g) {
  "use strict";
  const TS = g.TS = g.TS || {};
  const CASE = {
    strips: [
      [0, 0, 0, 0, 0, 0, 0, 0, 353.09, 536.51, 527.09, 436.22, 299.42, 150.59, 100.84, 75.38, 44.5, 9.72, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 276.42, 470.75, 516.81, 487.46, 406.39, 283.13, 132.41, 43.64, 23.72, 5.78, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 129.25, 294.37, 394.1, 442.38, 443.11, 397.52, 309.65, 187.7, 66.28, 6.84, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 7.53, 68.99, 191.83, 313.06, 399.74, 443.96, 441.71, 391.83, 290.23, 122.11, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 6.14, 23.91, 44.71, 136.97, 287.89, 410.0, 489.51, 516.72, 467.4, 264.3, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 10.68, 45.46, 76.1, 101.42, 154.3, 304.73, 440.22, 528.9, 534.47, 338.9, 0, 0, 0, 0, 0, 0],
    ],
    air: [{ h: 15.8956, a: -7.3711, b: 5.0962 }, { h: 17.4467, a: -9.5618, b: 4.6439 }, { h: 18.3423, a: -10.6579, b: 4.4176 },
      { h: 18.3423, a: -10.6579, b: 4.4176 }, { h: 17.4467, a: -9.5618, b: 4.6439 }, { h: 15.8956, a: -7.3711, b: 5.0962 }],
    south: [0, 0, 0, 0, 0, 0, 0, 0, 217.0, 452.5, 599.5, 690.0, 735.3, 734.4, 687.5, 595.1, 446.1, 205.8, 0, 0, 0, 0, 0, 0],
    north: [0, 0, 0, 0, 0, 0, 0, 0, 13.3, 57.9, 97.2, 128.0, 144.2, 143.9, 127.2, 96.1, 56.5, 12.0, 0, 0, 0, 0, 0, 0],
    t0: -6, duration: 172800, air_: { k: 10, rho: 0.87, cp: 1005 }, glass: { k: 0.53, rho: 200, cp: 840 },
    hWall: 15, hFloor: 2, tGround: 0, sill: 0.9, tauWin: 0.8, absOpaque: 0.6,
  };
  const wave = t => Math.cos(2 * Math.PI * (t - 54000) / 86400);
  const ambWall = t => -5.9 + 5.4 * wave(t);
  const at = (tab, t) => { const h = (t / 3600) % 24, i = Math.floor(h), f = h - i; return tab[i] * (1 - f) + tab[(i + 1) % 24] * f; };

  function solve(i, opts) {
    const o = opts || {}, NN = o.nodes || 8, T = i.T_INS, Ro = i.W / 2, Ri = Ro - T, Lin = i.L - 2 * T;
    const Awin = i.WIN_W * i.WIN_H, V = Math.PI / 2 * Ri * Ri * Lin, dA = Math.PI / 6, half = Math.PI / 2 * Ri * Ri;
    const shell = { k: i.K_INS, rc: i.RHO_INS * i.CP_INS }, gl = { k: CASE.glass.k, rc: CASE.glass.rho * CASE.glass.cp };
    const F = CASE.strips.map((q, k) => ({ id: "Arch", Ao: Ro * dA * i.L, Ai: Ri * dA * Lin, m: shell, h: CASE.air[k].h,
      amb: t => CASE.air[k].a + CASE.air[k].b * wave(t), q }));
    F.push({ id: "End", Ao: half - Awin, Ai: half - Awin, m: shell, h: CASE.hWall, amb: ambWall, q: CASE.south });
    F.push({ id: "End", Ao: half, Ai: half, m: shell, h: CASE.hWall, amb: ambWall, q: CASE.north });
    F.push({ id: "Window", Ao: Awin, Ai: Awin, m: gl, h: CASE.hWall, amb: ambWall, q: null });
    F.push(i.FLOOR >= 0.5 ? { id: "Floor", Ao: 2 * Ro * i.L, Ai: 2 * Ri * Lin, m: shell, h: CASE.hWall, amb: ambWall, q: null }
      : { id: "Floor", Ao: 2 * Ro * i.L, Ai: 2 * Ri * Lin, m: shell, h: CASE.hFloor, amb: () => CASE.tGround, q: null });
    const Ain = F.reduce((s, f) => s + f.Ai, 0), hIn = CASE.air_.k / (V / Ain);
    const dx = T / NN, NP = NN + 1;
    F.forEach(f => {
      f.A = (f.Ao + f.Ai) / 2; f.T = new Float64Array(NP).fill(CASE.t0);
      f.C = new Float64Array(NP).fill(f.m.rc * f.A * dx); f.C[0] /= 2; f.C[NN] /= 2;
      f.G = f.m.k * f.A / dx; f.Gout = f.h * f.Ao; f.Gin = hIn * f.Ai;
    });
    const Cair = CASE.air_.rho * CASE.air_.cp * V;
    let Ta = CASE.t0, dt = 60;
    F.forEach(f => { dt = Math.min(dt, 0.45 * f.C[1] / (2 * f.G), 0.45 * f.C[0] / (f.G + f.Gout), 0.45 * f.C[NN] / (f.G + f.Gin)); });
    dt = Math.min(dt, 0.45 * Cair / F.reduce((s, f) => s + f.Gin, 0));
    const dur = o.days ? o.days * 86400 : CASE.duration, from = o.lastDay ? dur - 86400 : 3600;
    const steps = Math.ceil(dur / dt); dt = dur / steps;
    const Gleak = CASE.air_.rho * CASE.air_.cp * V * (i.ACH || 0) / 3600;
    let tMin = Infinity, tMax = -Infinity; const hourly = [];
    for (let s = 0; s <= steps; s++) {
      const t = s * dt;
      if (t >= from - 1e-6) { if (Ta < tMin) tMin = Ta; if (Ta > tMax) tMax = Ta; }
      if (s % Math.round(3600 / dt) === 0) hourly.push(Ta);
      if (s === steps) break;
      // window sun lands on the floor (its inner surface), occupants and equipment heat the air
      const qSun = CASE.tauWin * (at(CASE.south, t) / CASE.absOpaque) * Awin;
      let qAir = (i.Q_INT || 0) - Gleak * (Ta - ambWall(t));
      const dT = F.map(f => {
        const n = f.T, d = new Float64Array(NP);
        for (let j = 0; j < NP; j++) {
          let q = j === 0 ? f.Gout * (f.amb(t) - n[0]) + (f.q ? at(f.q, t) * f.Ao : 0) : f.G * (n[j - 1] - n[j]);
          if (j === NN) { const qi = f.Gin * (Ta - n[j]); q += qi + (f.id === "Floor" ? qSun : 0); qAir -= qi; } else q += f.G * (n[j + 1] - n[j]);
          d[j] = q * dt / f.C[j];
        }
        return d;
      });
      F.forEach((f, k) => { for (let j = 0; j < NP; j++) f.T[j] += dT[k][j]; });
      Ta += qAir * dt / Cair;
    }
    return { T_AIR_MIN: tMin, T_AIR_MAX: tMax, hourly, dt, hIn, V };
  }
  TS.archCase = { CASE, solve };
  if (typeof module !== "undefined") module.exports = TS;
})(typeof window !== "undefined" ? window : globalThis);
