/* 3D twin of the shelter (Three.js r149, vendor/three.min.js, MIT).
   The model is built from the design itself: every layer of walls, roof and
   floor (outside to inside) is a solid of its own, textured by its material,
   with window, door, flue, plinth or skids, and arch / dome shapes.
   Views:
   - Materials: true layer build-up; "explode" pulls the layers apart and
     labels each one with material and thickness.
   - Thermal:   each surface coloured by its computed inner-surface
                temperature at the chosen hour (one value per surface: the
                engine is a one-zone model; corners and thermal bridges are
                what ANSYS adds).
   - Airflow:   particles from the low vent / leakage to the high vent, speed
                and count scaled to the computed air changes (schematic, not CFD).
   Environment (setEnv): the site's sun from the engine's sun-path model, sky by
   hour, snow cover and snowfall, wind streaks, terrain backdrop, rocks. */
(function () {
  "use strict";
  const TS = window.TS;

  function tempColor(t, lo, hi) {   // blue (cold) -> white -> red (warm)
    const x = Math.max(0, Math.min(1, (t - lo) / Math.max(hi - lo, 1e-6)));
    const c = new THREE.Color();
    if (x < 0.5) c.setRGB(0.18 + 1.5 * x * 0.8, 0.40 + x * 1.1, 0.85 + x * 0.3); else c.setRGB(0.98, 0.98 - (x - 0.5) * 1.5, 0.98 - (x - 0.5) * 1.7);
    return c;
  }

  /* ------------------------------------------------ procedural material textures */
  const TEX = {};
  function canvasTex(key, draw) {
    if (TEX[key]) return TEX[key];
    const c = document.createElement("canvas"); c.width = c.height = 256; const g = c.getContext("2d"); draw(g, 256);
    const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.anisotropy = 4; TEX[key] = t; return t;
  }
  const noise = (g, n, a, col) => { for (let i = 0; i < n; i++) { g.fillStyle = col(Math.random()); g.globalAlpha = a; g.fillRect(Math.random() * 256, Math.random() * 256, 2, 2); } g.globalAlpha = 1; };
  const LOOK = {   // material -> base colour + texture painter; [colour, painter, texture metres per repeat]
    steel: [0xb9c1c8, g => { g.fillStyle = "#b9c1c8"; g.fillRect(0, 0, 256, 256); for (let x = 0; x < 256; x += 16) { g.fillStyle = "rgba(0,0,0,.18)"; g.fillRect(x, 0, 3, 256); g.fillStyle = "rgba(255,255,255,.25)"; g.fillRect(x + 4, 0, 2, 256); } }, 1.2],
    alu: [0xd3d8dc, g => { g.fillStyle = "#d3d8dc"; g.fillRect(0, 0, 256, 256); noise(g, 900, 0.15, () => "#ffffff"); }, 1],
    grp: [0xe8e4d6, g => { g.fillStyle = "#e8e4d6"; g.fillRect(0, 0, 256, 256); noise(g, 1500, 0.12, r => (r > 0.5 ? "#bdb7a3" : "#ffffff")); }, 1],
    puf: [0xf0c94f, g => { g.fillStyle = "#f0c94f"; g.fillRect(0, 0, 256, 256); noise(g, 3000, 0.35, r => (r > 0.5 ? "#d9a92a" : "#ffe08a")); }, 0.5],
    pir: [0xe6c063, g => { g.fillStyle = "#e6c063"; g.fillRect(0, 0, 256, 256); noise(g, 3000, 0.3, r => (r > 0.5 ? "#c99b2f" : "#f6dc8f")); }, 0.5],
    xps: [0x8fb8e8, g => { g.fillStyle = "#8fb8e8"; g.fillRect(0, 0, 256, 256); noise(g, 2500, 0.25, r => (r > 0.5 ? "#6f9ad0" : "#c3dcf6")); }, 0.5],
    eps: [0xf4f4f0, g => { g.fillStyle = "#f4f4f0"; g.fillRect(0, 0, 256, 256); for (let i = 0; i < 700; i++) { g.strokeStyle = "rgba(160,160,150,.35)"; g.beginPath(); g.arc(Math.random() * 256, Math.random() * 256, 3 + Math.random() * 4, 0, 6.3); g.stroke(); } }, 0.5],
    rockwool: [0xc9b46a, g => { g.fillStyle = "#c9b46a"; g.fillRect(0, 0, 256, 256); for (let i = 0; i < 900; i++) { g.strokeStyle = `rgba(${Math.random() > 0.5 ? "120,100,40" : "235,220,150"},.35)`; g.beginPath(); const x = Math.random() * 256, y = Math.random() * 256; g.moveTo(x, y); g.lineTo(x + 18 * Math.random(), y + 3 * Math.random()); g.stroke(); } }, 0.5],
    aerogel: [0xdfe4ea, g => { g.fillStyle = "#dfe4ea"; g.fillRect(0, 0, 256, 256); noise(g, 2000, 0.2, () => "#9aa6b4"); }, 0.5],
    vip: [0xc9ccd2, g => { g.fillStyle = "#c9ccd2"; g.fillRect(0, 0, 256, 256); noise(g, 600, 0.2, () => "#ffffff"); }, 1],
    felt: [0x8a7f73, g => { g.fillStyle = "#8a7f73"; g.fillRect(0, 0, 256, 256); noise(g, 3000, 0.3, () => "#5f564c"); }, 0.5],
    straw: [0xd8bf6a, g => { g.fillStyle = "#d8bf6a"; g.fillRect(0, 0, 256, 256); for (let i = 0; i < 600; i++) { g.strokeStyle = "rgba(140,110,40,.5)"; g.beginPath(); const x = Math.random() * 256, y = Math.random() * 256; g.moveTo(x, y); g.lineTo(x + 30, y + 8 * (Math.random() - 0.5)); g.stroke(); } }, 0.5],
    plywood: [0xd2a86c, g => { g.fillStyle = "#d2a86c"; g.fillRect(0, 0, 256, 256); for (let y = 0; y < 256; y += 3) { g.strokeStyle = `rgba(140,90,40,${0.1 + Math.random() * 0.2})`; g.beginPath(); g.moveTo(0, y + Math.sin(y) * 2); g.bezierCurveTo(80, y + 6, 170, y - 6, 256, y); g.stroke(); } }, 1.2],
    timber: [0xb07a45, g => { g.fillStyle = "#b07a45"; g.fillRect(0, 0, 256, 256); for (let y = 0; y < 256; y += 32) { g.fillStyle = "rgba(60,30,10,.35)"; g.fillRect(0, y, 256, 2); } for (let y = 0; y < 256; y += 4) { g.strokeStyle = `rgba(90,50,20,${Math.random() * 0.25})`; g.beginPath(); g.moveTo(0, y); g.lineTo(256, y + 2); g.stroke(); } }, 1.2],
    bamboo: [0xc8b06a, g => { g.fillStyle = "#c8b06a"; g.fillRect(0, 0, 256, 256); for (let x = 0; x < 256; x += 12) { g.fillStyle = "rgba(100,80,30,.3)"; g.fillRect(x, 0, 2, 256); } }, 0.6],
    gypsum: [0xf2f0eb, null, 1], cplaster: [0xd9d5cc, g => { g.fillStyle = "#d9d5cc"; g.fillRect(0, 0, 256, 256); noise(g, 2500, 0.15, () => "#a39f97"); }, 1],
    mudplast: [0xb99a72, g => { g.fillStyle = "#b99a72"; g.fillRect(0, 0, 256, 256); noise(g, 3000, 0.2, () => "#8d7353"); }, 1],
    canvas: [0x8c8a5e, g => { g.fillStyle = "#8c8a5e"; g.fillRect(0, 0, 256, 256); for (let i = 0; i < 256; i += 4) { g.fillStyle = "rgba(0,0,0,.06)"; g.fillRect(i, 0, 1, 256); g.fillRect(0, i, 256, 1); } }, 0.6],
    pesheet: [0x3f6e9e, null, 1],
    brick: [0xa4553a, g => { g.fillStyle = "#cfc6b8"; g.fillRect(0, 0, 256, 256); for (let r = 0; r < 8; r++) for (let c = -1; c < 4; c++) { g.fillStyle = `hsl(${12 + Math.random() * 8},45%,${36 + Math.random() * 10}%)`; g.fillRect(c * 64 + (r % 2) * 32 + 2, r * 32 + 2, 60, 28); } }, 0.9],
    mudbrick: [0xb08b5e, g => { g.fillStyle = "#9c7a52"; g.fillRect(0, 0, 256, 256); for (let r = 0; r < 6; r++) for (let c = -1; c < 3; c++) { g.fillStyle = `hsl(32,${30 + Math.random() * 10}%,${48 + Math.random() * 8}%)`; g.fillRect(c * 96 + (r % 2) * 48 + 3, r * 43 + 3, 90, 37); } }, 1.2],
    stone: [0x8f8a82, g => { g.fillStyle = "#6f6a63"; g.fillRect(0, 0, 256, 256); for (let i = 0; i < 40; i++) { g.fillStyle = `hsl(30,6%,${45 + Math.random() * 20}%)`; g.beginPath(); g.ellipse(Math.random() * 256, Math.random() * 256, 18 + Math.random() * 22, 12 + Math.random() * 14, Math.random() * 3, 0, 6.3); g.fill(); } }, 1.2],
    rammed: [0xb48e63, g => { g.fillStyle = "#b48e63"; g.fillRect(0, 0, 256, 256); for (let y = 0; y < 256; y += 20) { g.fillStyle = `rgba(${Math.random() > 0.5 ? "120,80,40" : "220,180,130"},.25)`; g.fillRect(0, y, 256, 10); } }, 1],
    concrete: [0xa9adb0, g => { g.fillStyle = "#a9adb0"; g.fillRect(0, 0, 256, 256); noise(g, 4000, 0.2, r => (r > 0.5 ? "#7d8186" : "#d0d3d5")); }, 1],
    snow: [0xf3f7fa, g => { g.fillStyle = "#eef3f7"; g.fillRect(0, 0, 256, 256); noise(g, 2000, 0.25, () => "#cfdbe6"); }, 1],
  };
  const CLSCOL = { metal: 0x8a96a1, ins: 0xe9c779, gap: 0xffffff, mass: 0xb48c63, board: 0xcfae80 };
  function matFor(mat, opts) {
    const o = opts || {}, look = LOOK[mat], m = TS.MATERIALS[mat] || TS.MATERIALS.custom;
    const base = o.color != null ? o.color : look ? look[0] : CLSCOL[m.cls] || 0xcccccc;
    const p = { color: base, transparent: o.op < 1, opacity: o.op == null ? 1 : o.op, side: o.side || THREE.FrontSide };
    if (o.color == null && look && look[1] && !o.flat) { const t = canvasTex(mat, look[1]).clone(); t.needsUpdate = true; t.repeat.set(Math.max(1, (o.u || 1) / look[2]), Math.max(1, (o.v || 1) / look[2])); p.map = t; p.color = 0xffffff; }
    else if (o.color != null && o.corrugated) { const t = canvasTex("steel", LOOK.steel[1]).clone(); t.needsUpdate = true; t.repeat.set((o.u || 1) / 1.2, 1); p.map = t; }
    return new THREE.MeshLambertMaterial(p);
  }
  const VIS = t => Math.max(t, 0.025);   // thin sheets drawn 25 mm thick so they can be seen

  function Twin(host) {
    const W = () => Math.max(280, host.clientWidth), H = () => Math.max(260, Math.min(460, host.clientWidth * 0.62));
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, preserveDrawingBuffer: true });
    renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
    renderer.setSize(W(), H());
    renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    host.innerHTML = ""; host.style.position = "relative"; host.appendChild(renderer.domElement);
    const labelLayer = document.createElement("div"); labelLayer.className = "twinlabels"; host.appendChild(labelLayer);
    const scene = new THREE.Scene(), cam = new THREE.PerspectiveCamera(38, W() / H(), 0.1, 220);
    scene.add(new THREE.AmbientLight(0xffffff, 0.7));
    scene.add(new THREE.HemisphereLight(0xdbe8f5, 0x8a7f6a, 0.25));
    const sun = new THREE.DirectionalLight(0xffffff, 0.75); sun.position.set(5, 10, 8);
    sun.castShadow = true; sun.shadow.mapSize.set(2048, 2048); Object.assign(sun.shadow.camera, { left: -16, right: 16, top: 16, bottom: -16, near: 1, far: 60 }); sun.shadow.bias = -0.0005;
    scene.add(sun); scene.add(sun.target);
    const grid = new THREE.GridHelper(30, 30, 0x7d8b98, 0x3a4652); grid.material.opacity = 0.35; grid.material.transparent = true; scene.add(grid);
    const group = new THREE.Group(); scene.add(group);
    const flow = new THREE.Group(); scene.add(flow);
    let az = -0.65, el = 0.42, dist = 15, drag = null, raf = 0, particles = null, pspeed = 0, labels = [];
    const place = () => { cam.position.set(dist * Math.cos(el) * Math.sin(az), dist * Math.sin(el), dist * Math.cos(el) * Math.cos(az)); cam.lookAt(0, 1.3, 0); };
    place();
    const el2 = renderer.domElement;
    el2.addEventListener("pointerdown", e => { drag = [e.clientX, e.clientY]; el2.setPointerCapture(e.pointerId); });
    el2.addEventListener("pointermove", e => { if (!drag) return; az -= (e.clientX - drag[0]) * 0.01; el = Math.max(0.05, Math.min(1.4, el + (e.clientY - drag[1]) * 0.01)); drag = [e.clientX, e.clientY]; place(); });
    el2.addEventListener("pointerup", () => (drag = null));
    el2.addEventListener("wheel", e => { e.preventDefault(); dist = Math.max(5, Math.min(45, dist * (1 + Math.sign(e.deltaY) * 0.1))); place(); }, { passive: false });

    function clear(g) { while (g.children.length) { const o = g.children.pop(); o.traverse && o.traverse(x => { if (x.geometry) x.geometry.dispose(); if (x.material) { if (x.material.map) x.material.map.dispose(); x.material.dispose(); } }); } }
    function mesh(geo, mat, cast) { const m = new THREE.Mesh(geo, mat); m.castShadow = cast !== false; m.receiveShadow = true; return m; }
    function box(w, h, dp, mat, edges) {
      const m = mesh(new THREE.BoxGeometry(w, h, dp), mat);
      if (edges) m.add(new THREE.LineSegments(new THREE.EdgesGeometry(m.geometry), new THREE.LineBasicMaterial({ color: 0x18232e, transparent: true, opacity: 0.35 })));
      return m;
    }
    function label(pos, text, cls) { labels.push({ pos, text, cls: cls || "" }); }

    /* d: design; r: engine result; mode: materials | thermal | airflow; hour; opts { explode } */
    function update(d, r, mode, hour, opts) {
      const o = opts || {}, X = o.explode && mode === "materials" ? 1 : 0;
      clear(group); clear(flow); particles = null; labels = [];
      group.rotation.y = flow.rotation.y = (180 - d.orient) * Math.PI / 180;   // front facade faces +z
      group.position.y = X ? 0.6 : 0;
      const tsi = {}; let lo = Infinity, hi = -Infinity;
      if (r && r.elems && mode === "thermal") {
        const h = Math.max(0, Math.min(r.N - 1, hour | 0)), air = r.heated.air[h];
        r.elems[h].forEach(e => { const v = air - e.U * e.rsi * (air - e.th); tsi[e.id] = v; lo = Math.min(lo, v); hi = Math.max(hi, v); });
        const mid = (lo + hi) / 2; if (hi - lo < 2) { lo = mid - 1; hi = mid + 1; }
      }
      const op = mode === "airflow" ? 0.25 : 1;
      const look = (id, l, u, v, side) => matFor(l.mat, { op, u, v, side, color: mode === "thermal" && tsi[id] != null ? tempColor(tsi[id], lo, hi) : null });
      const raised = d.floorMode === "raised", fl = d.floor.filter(l => l.mat !== "airgap"), Ft = fl.reduce((s, l) => s + VIS(l.t), 0);
      const y0 = (raised ? 0.55 : 0.18) + Ft;   // top of the floor
      const shape = d.shape || "box", GAP = 0.8;
      if (X && dist < 20) { dist = 20; el = Math.max(el, 0.5); place(); }   // step back so the pulled-apart layers fit
      const layerTag = l => { const m = TS.MATERIALS[l.mat] || TS.MATERIALS.custom; return `${m.name} · ${l.t < 0.005 ? (l.t * 1000).toFixed(1) : Math.round(l.t * 1000)} mm`; };

      // base: plinth or skids
      if (raised) { [[-1, -1], [1, -1], [-1, 1], [1, 1], [0, -1], [0, 1]].forEach(([sx, sz]) => { const s = box(0.18, 0.55, 0.18, matFor("steel", { op })); s.position.set(sx * (d.L / 2 - 0.3), 0.275, sz * (d.W / 2 - 0.3)); group.add(s); }); }
      else if (shape !== "dome") { const p = box(d.L + 0.5, 0.18, d.W + 0.5, matFor("concrete", { op, u: d.L, v: d.W })); p.position.y = 0.09; group.add(p); }

      // floor layers (bottom = outer)
      let fy = y0 - Ft;
      fl.forEach((l, i) => { const t = VIS(l.t), off = X ? -(fl.length - 1 - i) * 0.35 : 0;
        const s = shape === "dome" ? mesh(new THREE.CylinderGeometry(d.L / 2, d.L / 2, t, 40), look("floor", l, d.L, d.L)) : box(d.L, t, d.W, look("floor", l, d.L, d.W));
        s.position.y = fy + t / 2 + off; group.add(s); fy += t;
        if (X) label(new THREE.Vector3(-d.L / 2 + (i + 0.5) * d.L / fl.length, s.position.y, d.W / 2 + 0.3), `Floor ${i + 1}: ${layerTag(l)}`, "lay"); });

      if (shape === "vault" || shape === "dome") {
        // arch / dome: one shell per layer, outer first; end walls of the arch with door and window
        const ls = d.roof.filter(l => l.mat !== "airgap"), R0 = shape === "vault" ? d.W / 2 : d.L / 2;
        let s = 0;
        ls.forEach((l, i) => {
          const R = R0 - s + (X ? (ls.length - 1 - i) * GAP : 0), arc = Math.PI * R;
          const mat = matFor(l.mat, { op, u: shape === "vault" ? arc : arc, v: d.L, side: THREE.DoubleSide, flat: false,
            color: mode === "thermal" && tsi.roof != null ? tempColor(tsi.roof, lo, hi) : i === 0 && d.color != null ? d.color : null, corrugated: i === 0 && d.corrugated });
          const m = shape === "vault" ? mesh(new THREE.CylinderGeometry(R, R, d.L, 64, 1, true, -Math.PI / 2, Math.PI), mat) : mesh(new THREE.SphereGeometry(R, 48, 20, 0, Math.PI * 2, 0, Math.PI / 2), mat);
          if (shape === "vault") m.rotation.z = Math.PI / 2;
          m.position.y = y0; group.add(m);
          if (X) label(new THREE.Vector3(0, y0 + R, 0), `${i + 1}. ${layerTag(l)}`, "lay");
          s += VIS(l.t);
        });
        if (shape === "vault") {
          const endMat = matFor(ls[0] ? ls[0].mat : "steel", { op, color: d.color != null ? new THREE.Color(d.color).multiplyScalar(0.9) : null, side: THREE.DoubleSide, u: d.W, v: d.W / 2 });
          [1, -1].forEach(sx => { const e = mesh(new THREE.CircleGeometry(R0, 48, 0, Math.PI), endMat.clone()); e.rotation.y = sx * Math.PI / 2; e.position.set(sx * d.L / 2, y0, 0); group.add(e); });
          // door on the east end, window on the west end
          const door = box(0.06, 1.95, 0.95, matFor("timber", { op, u: 1, v: 2 })); door.position.set(d.L / 2 + 0.03, y0 + 0.98, 0); group.add(door);
          label(new THREE.Vector3(d.L / 2 + 0.05, y0 + 2.1, 0), "Door");
          const Aw = (d.win && d.win.front) || 0;
          if (Aw > 0) { const wh = Math.min(1.0, R0 * 0.5), ww = Math.min(R0, Aw / wh); const g = box(0.05, wh, ww, new THREE.MeshPhongMaterial({ color: 0x6fa8d6, transparent: true, opacity: 0.6, shininess: 90 })); g.position.set(-d.L / 2 - 0.03, y0 + R0 * 0.45, 0); group.add(g); label(new THREE.Vector3(-d.L / 2 - 0.05, y0 + R0 * 0.45 + wh / 2 + 0.1, 0), "Window"); }
          if (d.pv) {   // solar panels on the sunny (front, +z) side of the arch
            const n = Math.max(2, Math.floor(d.L / 1.8)), ang = 0.75, Rp = R0 + 0.08 + (X ? (ls.length) * GAP : 0);
            for (let k = 0; k < n; k++) { const p = box(1.6, 0.04, 1.0, new THREE.MeshPhongMaterial({ color: 0x1d3557, shininess: 120, specular: 0x8899aa }));
              p.position.set(-d.L / 2 + 0.9 + k * (d.L - 1.8) / Math.max(1, n - 1), y0 + Rp * Math.cos(ang), Rp * Math.sin(ang)); p.rotation.x = ang; group.add(p); }
            label(new THREE.Vector3(0, y0 + Rp * Math.cos(ang) + 0.4, Rp * Math.sin(ang)), "Solar panels");
          }
        }
        label(new THREE.Vector3(0, y0 - 0.05, d.W / 2 + 0.6), `${d.L.toFixed(1)} m L`, "dim");
        label(new THREE.Vector3(d.L / 2 + 0.6, y0 - 0.05, 0), `${(shape === "vault" ? d.W : d.L).toFixed(1)} m ${shape === "vault" ? "span" : "Ø"}`, "dim");
      } else {
        // box: walls as stacked layers, outer first
        const wl = d.wall.filter(l => l.mat !== "airgap"), WALLS = [["wall_front", 0, 1], ["wall_back", 0, -1], ["wall_right", 1, 0], ["wall_left", -1, 0]];
        let s = 0;
        wl.forEach((l, i) => {
          const t = VIS(l.t), off = X ? (wl.length - 1 - i) * GAP : 0;
          WALLS.forEach(([id, nx, nz]) => {
            const along = nz ? d.L - 2 * s : d.W - 2 * (s + t), m = box(nz ? along : t, d.H, nz ? t : along, look(id, l, along, d.H), !X);
            m.position.set(nx * (d.L / 2 - s - t / 2 + off), y0 + d.H / 2, nz * (d.W / 2 - s - t / 2 + off));
            if (X && id === "wall_left") m.visible = true;
            group.add(m);
          });
          if (X) label(new THREE.Vector3(-d.L / 2 + (i + 0.5) * d.L / wl.length, y0 + d.H * (0.85 - 0.22 * i), d.W / 2 - s + off), `Wall ${i + 1}: ${layerTag(l)}`, "lay");
          s += t;
        });
        const Wt = s;
        // roof: flat stack with overhang on the outer layer, or a pitched outer roof
        const rl = d.roof.filter(l => l.mat !== "airgap"), pitch = (d.pitch || 0) * Math.PI / 180;
        let ry = y0 + d.H;
        rl.slice().reverse().forEach((l, k) => { const i = rl.length - 1 - k, t = VIS(l.t), ov = i === 0 ? 0.3 : 0, off = X ? (rl.length - 1 - i) * GAP + 0.5 : 0;
          if (pitch > 0.01 && i === 0 && !X) return;   // pitched outer roof drawn below
          const m = box(d.L + 2 * ov, t, d.W + 2 * ov, look("roof", l, d.L, d.W), !X); m.position.y = ry + t / 2 + off; group.add(m); ry += t;
          if (X) label(new THREE.Vector3(-d.L / 2 + (i + 0.5) * d.L / rl.length, m.position.y + 0.12, 0), `Roof ${i + 1}: ${layerTag(l)}`, "lay"); });
        if (pitch > 0.01 && !X && rl[0]) {
          const Wh = d.W / 2 + 0.3, run = Wh / Math.cos(pitch);
          [1, -1].forEach(sg => { const p = box(d.L + 0.6, 0.05, run, look("roof", rl[0], d.L, run)); p.position.set(0, ry + Wh * Math.tan(pitch) / 2, sg * Wh / 2); p.rotation.x = sg * pitch; group.add(p); });
          const gable = new THREE.Shape([new THREE.Vector2(-d.W / 2, 0), new THREE.Vector2(d.W / 2, 0), new THREE.Vector2(0, d.W / 2 * Math.tan(pitch))]);
          [d.L / 2, -d.L / 2].forEach(x => { const gm = mesh(new THREE.ShapeGeometry(gable), look("wall_right", wl[0] || { mat: "steel" }, d.W, 1, THREE.DoubleSide)); gm.position.set(x, ry, 0); gm.rotation.y = Math.PI / 2; group.add(gm); });
        }
        if (!X) {
          // window with frame on the front, door on the right wall, heater flue on the roof
          const A = (d.win && d.win.front) || 0, wh = Math.min(1.2, 0.8 * d.H), ww = Math.min(d.L * 0.8, A / wh);
          if (A > 0) {
            const fr = box(ww + 0.12, wh + 0.12, 0.06, new THREE.MeshLambertMaterial({ color: 0x2b3440 })); fr.position.set(0, y0 + 0.9 + wh / 2, d.W / 2 + 0.03); group.add(fr);
            const g = box(ww, wh, 0.07, new THREE.MeshPhongMaterial({ color: 0x8ec0e6, transparent: true, opacity: 0.7, shininess: 100, specular: 0xffffff })); g.position.set(0, y0 + 0.9 + wh / 2, d.W / 2 + 0.04); group.add(g);
            const mul = box(0.04, wh, 0.08, new THREE.MeshLambertMaterial({ color: 0x2b3440 })); mul.position.copy(g.position); group.add(mul);
            label(new THREE.Vector3(0, y0 + 0.9 + wh + 0.25, d.W / 2), `Window ${A.toFixed(1)} m²`);
          }
          const dw = Math.min(0.95, d.W * 0.35), dh = Math.min(2.0, d.H - 0.3);
          const door = box(0.07, dh, dw, matFor("timber", { op, u: 1, v: 2 })); door.position.set(d.L / 2 + 0.035, y0 + dh / 2, 0); group.add(door);
          const knob = mesh(new THREE.SphereGeometry(0.04, 12, 8), new THREE.MeshPhongMaterial({ color: 0xc9a227 })); knob.position.set(d.L / 2 + 0.1, y0 + dh / 2, dw / 2 - 0.12); group.add(knob);
          label(new THREE.Vector3(d.L / 2 + 0.1, y0 + dh + 0.15, 0), "Door");
          if (d.heater !== "passive") {
            const fx = -d.L / 2 + 0.6, fz = -d.W / 2 + 0.6, ph = 1.1;
            const pipe = mesh(new THREE.CylinderGeometry(0.07, 0.07, ph, 16), new THREE.MeshPhongMaterial({ color: 0x3a3f45, shininess: 40 })); pipe.position.set(fx, ry + ph / 2, fz); group.add(pipe);
            const cap = mesh(new THREE.ConeGeometry(0.16, 0.14, 16), new THREE.MeshPhongMaterial({ color: 0x3a3f45 })); cap.position.set(fx, ry + ph + 0.08, fz); group.add(cap);
            label(new THREE.Vector3(fx, ry + ph + 0.3, fz), "Heater flue");
          }
          if (d.trombe && d.trombe.area > 0) { const tw = Math.min(d.L * 0.4, d.trombe.area / d.H), t = box(tw, d.H * 0.9, 0.12, matFor(d.trombe.mat || "stone", { op, u: tw, v: d.H }));
            t.position.set(-d.L / 2 + tw / 2 + 0.15, y0 + d.H * 0.47, d.W / 2 + 0.08); group.add(t);
            const gl = box(tw, d.H * 0.9, 0.02, new THREE.MeshPhongMaterial({ color: 0x9fd0f0, transparent: true, opacity: 0.35 })); gl.position.set(t.position.x, t.position.y, d.W / 2 + 0.17); group.add(gl);
            label(new THREE.Vector3(t.position.x, y0 + d.H, d.W / 2 + 0.2), "Trombe wall"); }
          // dimensions
          label(new THREE.Vector3(0, 0.25, d.W / 2 + 0.75), `${d.L.toFixed(1)} m L`, "dim");
          label(new THREE.Vector3(d.L / 2 + 0.75, 0.25, 0), `${d.W.toFixed(1)} m W`, "dim");
          label(new THREE.Vector3(-d.L / 2 - 0.4, y0 + d.H / 2, d.W / 2 + 0.4), `${d.H.toFixed(1)} m H`, "dim");
          label(new THREE.Vector3(-d.L / 2, y0 + d.H * 0.75, d.W / 2), `Walls: ${wl.map(l => (TS.MATERIALS[l.mat] || {}).name).join(" / ")}`, "lay");
        }
      }
      // airflow schematic
      if (mode === "airflow" && r) {
        const ach = r.ach[Math.max(0, Math.min(r.N - 1, hour | 0))], n = Math.round(60 + 140 * Math.min(1, ach / 3));
        const g = new THREE.BufferGeometry(), pos = new Float32Array(n * 3), seeds = [];
        for (let i = 0; i < n; i++) seeds.push({ u: Math.random(), x: (Math.random() - 0.5) * d.L * 0.8, z0: d.W / 2 - 0.1, z1: -d.W / 2 + 0.1, wob: Math.random() * 6.28 });
        g.setAttribute("position", new THREE.BufferAttribute(pos, 3));
        particles = { pts: new THREE.Points(g, new THREE.PointsMaterial({ color: 0x00b8d4, size: 0.09 })), seeds, d, lift: y0 };
        flow.add(particles.pts); pspeed = 0.002 + 0.004 * Math.min(1, ach / 3);
      }
      group.traverse(x => { if (x.isMesh) { x.castShadow = true; x.receiveShadow = true; } });
      host.dataset.range = isFinite(lo) ? `${lo.toFixed(1)} to ${hi.toFixed(1)} °C` : "";
      return isFinite(lo) ? { lo, hi } : null;
    }

    /* ------------------------------------------------ labels (DOM, projected each frame) */
    const pool = [];
    function drawLabels() {
      const w = el2.clientWidth, h = el2.clientHeight, v = new THREE.Vector3();
      group.updateMatrixWorld();
      labels.forEach((lb, i) => {
        let e = pool[i]; if (!e) { e = document.createElement("span"); labelLayer.appendChild(e); pool[i] = e; }
        v.copy(lb.pos).applyMatrix4(group.matrixWorld).project(cam);
        const vis = v.z < 1 && Math.abs(v.x) < 1.1 && Math.abs(v.y) < 1.1;
        e.style.display = vis ? "" : "none"; if (!vis) return;
        e.className = "tl " + lb.cls; e.textContent = lb.text;
        e.style.transform = `translate(${((v.x + 1) / 2 * w).toFixed(0)}px, ${((1 - v.y) / 2 * h).toFixed(0)}px) translate(-50%, -50%)`;
      });
      for (let i = labels.length; i < pool.length; i++) pool[i].style.display = "none";
    }

    /* ------------------------------------------------ environment
       o: { lat, lon, doy, hour, tOut, tMean, wind, terrain, snowCover, snowing }
       Sun position from TS.engine.sunPos (same as the thermal model). World
       frame: +z = south, +x = east, so the shelter group's rotation lines up. */
    const envG = new THREE.Group(); scene.add(envG);
    const amb = scene.children.find(c => c.isAmbientLight);
    const sunMesh = new THREE.Mesh(new THREE.SphereGeometry(1.6, 24, 16), new THREE.MeshBasicMaterial({ color: 0xffd36b }));
    scene.add(sunMesh); grid.visible = false;
    let snow = null, windP = null, envKey = "";
    const rnd = (a, b) => a + Math.random() * (b - a);
    function cone(r, h, color, x, z) { const m = new THREE.Mesh(new THREE.ConeGeometry(r, h, 7), new THREE.MeshLambertMaterial({ color, flatShading: true })); m.position.set(x, h / 2 - 0.5, z); return m; }
    function backdrop(o) {
      clear(envG);
      const T = o.terrain || "plain", cover = o.snowCover;
      const ground = cover ? 0xdfe7ee : T === "desert" ? 0xd9b77a : T === "coast" ? 0xd8c69a : T === "high" ? 0x9a8a72 : o.tMean > 15 ? 0x6f8f4e : 0x8a7f5e;
      const g = new THREE.Mesh(new THREE.CircleGeometry(70, 48), new THREE.MeshLambertMaterial({ color: ground }));
      g.rotation.x = -Math.PI / 2; g.position.y = -0.01; g.receiveShadow = true; envG.add(g);
      // rocks around the shelter, snow-capped when the ground is white
      for (let i = 0; i < 9; i++) { const a = rnd(0, 6.28), R = rnd(7, 14), s = rnd(0.25, 0.7);
        const rk = new THREE.Mesh(new THREE.DodecahedronGeometry(s, 0), new THREE.MeshLambertMaterial({ color: 0x4b4f55, flatShading: true }));
        rk.position.set(R * Math.sin(a), s * 0.45, R * Math.cos(a)); rk.scale.y = 0.7; rk.castShadow = rk.receiveShadow = true; envG.add(rk);
        if (cover) { const cap = new THREE.Mesh(new THREE.SphereGeometry(s * 0.85, 12, 6, 0, 6.3, 0, 1.1), new THREE.MeshLambertMaterial({ color: 0xf4f8fb })); cap.position.copy(rk.position); cap.position.y += s * 0.15; cap.scale.y = 0.6; envG.add(cap); } }
      if (T === "high" || T === "hill" || T === "valley") {
        const n = T === "valley" ? 14 : 11, rock = T === "high" ? 0x6e6a66 : 0x4f6b46;
        for (let i = 0; i < n; i++) {
          const a = (i / n) * Math.PI * 2 + rnd(-0.15, 0.15), R = rnd(36, 52), h = T === "high" ? rnd(14, 26) : T === "valley" ? rnd(12, 20) : rnd(7, 13), r = h * rnd(0.7, 1.0);
          const x = R * Math.sin(a), z = R * Math.cos(a); envG.add(cone(r, h, rock, x, z));
          const capH = h * (cover ? 0.5 : T === "high" ? 0.3 : 0);   // snow line on the peaks
          if (capH > 0) { const c = cone(r * capH / h, capH, 0xf4f8fb, x, z); c.position.y = h - capH / 2 - 0.5; envG.add(c); }
        }
      } else if (T === "desert") {
        for (let i = 0; i < 9; i++) { const a = rnd(0, 6.28), R = rnd(30, 50), m = new THREE.Mesh(new THREE.SphereGeometry(rnd(6, 11), 16, 8), new THREE.MeshLambertMaterial({ color: 0xcfa866 }));
          m.scale.y = 0.25; m.position.set(R * Math.sin(a), 0, R * Math.cos(a)); envG.add(m); }
      } else if (T === "coast") {
        const sea = new THREE.Mesh(new THREE.PlaneGeometry(140, 60), new THREE.MeshLambertMaterial({ color: 0x2f6f9a })); sea.rotation.x = -Math.PI / 2; sea.position.set(0, 0.02, 45); envG.add(sea);
      }
    }
    function makeSnow(on, wind) {
      if (snow) { scene.remove(snow.pts); snow.pts.geometry.dispose(); snow.pts.material.dispose(); snow = null; }
      if (!on) return;
      const n = 1400, pos = new Float32Array(n * 3);
      for (let i = 0; i < n; i++) { pos[i * 3] = rnd(-25, 25); pos[i * 3 + 1] = rnd(0, 18); pos[i * 3 + 2] = rnd(-25, 25); }
      const geo = new THREE.BufferGeometry(); geo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
      snow = { pts: new THREE.Points(geo, new THREE.PointsMaterial({ color: 0xffffff, size: 0.12, transparent: true, opacity: 0.9 })), drift: Math.min(0.12, (wind || 0) * 0.012) };
      scene.add(snow.pts);
    }
    function makeWind(wind) {
      if (windP) { scene.remove(windP.lines); windP.lines.geometry.dispose(); windP.lines.material.dispose(); windP = null; }
      if (!(wind > 0.5)) return;
      const n = Math.round(Math.min(160, 20 + wind * 12)), pos = new Float32Array(n * 6), seeds = [];
      for (let i = 0; i < n; i++) seeds.push({ x: rnd(-28, 28), y: rnd(0.3, 7), z: rnd(-20, 20), len: rnd(0.6, 1.6) });
      const geo = new THREE.BufferGeometry(); geo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
      windP = { lines: new THREE.LineSegments(geo, new THREE.LineBasicMaterial({ color: 0xdfe8f0, transparent: true, opacity: 0.55 })), seeds, v: 0.02 + wind * 0.018 };
      scene.add(windP.lines);
    }
    function setEnv(o) {
      if (!o || !TS.engine) return null;
      const key = [o.terrain, o.snowCover, o.snowing, Math.round((o.wind || 0) * 2), o.tMean > 15].join("|");
      if (key !== envKey) { envKey = key; backdrop(o); makeSnow(o.snowing, o.wind); makeWind(o.wind); }
      const sp = TS.engine.sunPos(o.lat, o.lon, o.doy, o.hour + 0.5, 82.5), alt = sp.alt * Math.PI / 180, az = sp.az * Math.PI / 180, R = 45;
      const dir = new THREE.Vector3(Math.cos(alt) * Math.sin(az), Math.sin(alt), -Math.cos(alt) * Math.cos(az));
      sunMesh.position.copy(dir.clone().multiplyScalar(R)); sunMesh.visible = sp.alt > -2;
      sun.position.copy(dir.clone().multiplyScalar(25)); sun.castShadow = sp.alt > 1;
      const day = Math.max(0, Math.min(1, (sp.alt + 4) / 14));            // 0 night .. 1 full day
      const dusk = Math.max(0, 1 - Math.abs(sp.alt - 2) / 8) * (sp.alt > -6 ? 1 : 0);
      const sky = new THREE.Color(0x0b1622).lerp(new THREE.Color(o.snowing ? 0xaab8c4 : 0x8ec5ff), day).lerp(new THREE.Color(0xf2a35e), dusk * 0.45);
      scene.background = sky; scene.fog = new THREE.Fog(sky, 40, 95);
      const glare = o.snowCover ? 0.75 : 1;   // snow reflects: keep the scene from washing out
      sun.intensity = (0.12 + 0.7 * day * (o.snowing ? 0.5 : 1)) * glare; sun.color.set(dusk > 0.3 ? 0xffc48a : 0xffffff);
      if (amb) { amb.intensity = (0.22 + 0.25 * day) * glare; amb.color.set(day < 0.2 ? 0x8fa6c8 : 0xffffff); }
      return { sunAlt: sp.alt, sunAz: sp.az, day: sp.alt > 0 };
    }

    function tick() {
      raf = requestAnimationFrame(tick);
      if (snow) {
        const a = snow.pts.geometry.attributes.position.array;
        for (let i = 0; i < a.length; i += 3) { a[i + 1] -= 0.04; a[i] += snow.drift; if (a[i + 1] < 0) { a[i + 1] = 18; a[i] = rnd(-25, 25); } if (a[i] > 25) a[i] = -25; }
        snow.pts.geometry.attributes.position.needsUpdate = true;
      }
      if (windP) {
        const a = windP.lines.geometry.attributes.position.array;
        windP.seeds.forEach((s, i) => { s.x += windP.v; if (s.x > 28) s.x = -28;
          a.set([s.x, s.y + 0.15 * Math.sin(s.x * 0.5), s.z, s.x + s.len, s.y + 0.15 * Math.sin((s.x + s.len) * 0.5), s.z], i * 6); });
        windP.lines.geometry.attributes.position.needsUpdate = true;
      }
      if (particles) {
        const { pts, seeds, d, lift } = particles, a = pts.geometry.attributes.position.array;
        seeds.forEach((s, i) => {
          s.u = (s.u + pspeed) % 1;
          // in low at the front, rise with the stack effect, out high at the back
          a[i * 3] = s.x + 0.15 * Math.sin(s.u * 9 + s.wob);
          a[i * 3 + 1] = lift + 0.25 + (d.H - 0.5) * Math.pow(s.u, 0.8);
          a[i * 3 + 2] = s.z0 + (s.z1 - s.z0) * s.u;
        });
        pts.geometry.attributes.position.needsUpdate = true;
      }
      renderer.render(scene, cam);
      drawLabels();
    }
    tick();
    function resize() { renderer.setSize(W(), H()); cam.aspect = W() / H(); cam.updateProjectionMatrix(); }
    return { update, setEnv, resize, snapshot: () => { renderer.render(scene, cam); return renderer.domElement.toDataURL("image/jpeg", 0.85); }, dispose: () => cancelAnimationFrame(raf) };
  }
  TS.twin3d = { Twin, tempColor };
})();
