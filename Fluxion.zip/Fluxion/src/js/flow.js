/* The guided path through the app:
     1 Mission -> 2 Results & design -> 3 Compare designs -> 4 Check in ANSYS -> 5 Report
   Back / Next on every step, reference tools under "More tools", a simple /
   advanced switch for the design inputs, and the one downloadable report. */
(function () {
  "use strict";
  const TS = window.TS, A = TS.app, $ = id => document.getElementById(id);
  const f1 = v => (v == null || !isFinite(v) ? "–" : (+v).toFixed(1)).replace(/^-/, "−");
  const f2 = v => (v == null || !isFinite(v) ? "–" : (+v).toFixed(2)).replace(/^-/, "−");
  const STEPS = [["mission", "Mission"], ["design", "Design"], ["compare", "Compare designs"], ["ansys", "Check in ANSYS"], ["results", "Results"], ["report", "Report"]];
  const HINT = {
    mission: "Choose the place, the people and how long the shelter is used. The app picks the shelter and its layers and tests them against a severe cold wave.",
    design: "Change any input or layer; the checks and numbers update at once.",
    compare: "Same weather for every option: pick the material or design that needs the least fuel.",
    ansys: "Run the same design in your ANSYS Workbench model and see both answers side by side.",
    results: "Inside temperature, heat from the sun and heat flow for this design.",
    report: "Download everything as one PDF.",
  };

  /* ---------------------------------------------------------- Back / Next */
  STEPS.forEach(([tab], i) => {
    const view = document.querySelector(`.view[data-view="${tab}"]`); if (!view) return;
    const head = document.createElement("div"); head.className = "stephead";
    head.innerHTML = `<span class="stepno">Step ${i + 1} of ${STEPS.length}</span><span>${HINT[tab]}</span>`;
    view.prepend(head);
    const nav = document.createElement("div"); nav.className = "stepnav";
    nav.innerHTML = (i > 0 ? `<button type="button" class="ghost" data-goto="${STEPS[i - 1][0]}">← ${STEPS[i - 1][1]}</button>` : "<span></span>") +
      (i < STEPS.length - 1 ? `<button type="button" class="solid" data-goto="${STEPS[i + 1][0]}">Next: ${STEPS[i + 1][1]} →</button>` : "");
    view.append(nav);
  });
  document.addEventListener("click", e => {
    const b = e.target.closest("[data-goto]"); if (!b) return;
    TS.app.showTab(b.dataset.goto); window.scrollTo({ top: 0, behavior: "smooth" });
  });

  /* ---------------------------------------------------------- More tools menu */
  const more = $("moreMenu");
  more.querySelectorAll("button").forEach(b => b.addEventListener("click", () => { more.open = false; }));
  document.addEventListener("click", e => { if (more.open && !more.contains(e.target)) more.open = false; });
  const rulesTab = document.querySelector('.tabs button[data-tab="rules"]'); if (rulesTab) rulesTab.textContent = "Design rules";
  function markMore(t) { more.classList.toggle("on", !!more.querySelector(`button[data-tab="${t}"]`)); }

  /* ---------------------------------------------------------- simple / advanced inputs */
  const AKEY = "thermashelter.advanced";
  const setAdv = on => { document.body.classList.toggle("showadv", on); $("advToggle").checked = on; try { localStorage.setItem(AKEY, on ? "1" : ""); } catch (e) {} };
  $("advToggle").addEventListener("change", e => setAdv(e.target.checked));
  try { setAdv(localStorage.getItem(AKEY) === "1"); } catch (e) { setAdv(false); }

  /* ---------------------------------------------------------- report */
  function reportItems() {
    const R = A.R, d = A.S.design, st = A.status(), ms = TS.mission && TS.mission.state(), runs = TS.bridgeUI ? TS.bridgeUI.history() : [];
    const units = d.units || 1;
    $("rpHud").innerHTML = R ? `<div class="hudcell ${st.level}"><b>${st.label}</b><span>${st.reasons.concat(st.warns).join(" · ") || "every check passes"}</span></div>` +
      `<div class="hudcell plain"><b>${f1(R.summary.passive.nightMin)}<small> °C</small></b><span>coldest hour, no heating</span></div>` +
      `<div class="hudcell plain"><b>${f2(R.summary.fuel_L * units)}<small> L/day</small></b><span>kerosene${units > 1 ? `, all ${units} shelters` : ""}</span></div>` +
      `<div class="hudcell plain"><b>${runs.length}</b><span>ANSYS run${runs.length === 1 ? "" : "s"} to compare</span></div>` : "";
    const li = (ok, t) => `<li class="${ok ? "ok" : "miss"}">${ok ? "✓" : "–"} ${t}</li>`;
    $("rpList").innerHTML =
      li(true, `Mission: ${A.designName(d)} at ${A.siteRec().name}, ${A.MONTHS[A.S.site.month]}${ms && ms.dur ? (ms.dur.use === "permanent" ? `, permanent (${ms.dur.years}-year life)` : `, temporary (${ms.dur.days} days)`) : ""}`) +
      li(true, "Results: inside temperature, heat from the sun, heat flow, and fuel") +
      li(true, "Drawings, every layer of walls, roof and floor, hourly log and every design check") +
      li(true, "Bill of materials with cost for the selected state, transport mass and fuel") +
      li(runs.length > 0, runs.length ? `ANSYS comparison: ${runs.length} run(s), latest ${runs[0].t}${runs[0].mock ? " (practice mode)" : ""}` : "ANSYS comparison: no run yet (step 4)") +
      li(!!(ms && ms.twin), "3D view of the shelter at its site");
  }
  async function download() {
    const btn = $("rpDownload"); btn.disabled = true; $("rpNote").textContent = "Building the report…";
    try {
      const ctx = TS.stages.reportCtx(), ms = TS.mission && TS.mission.state(), st = A.status();
      Object.assign(ctx, {
        status: st, typeName: A.designName(A.S.design), siteName: A.siteRec().name,
        mission: ms ? { dur: ms.dur, units: A.S.design.units || 1, verify: ms.verify } : null,
        ansysRuns: TS.bridgeUI ? TS.bridgeUI.history() : [],
        twinPng: TS.mission && TS.mission.snapshotAt ? TS.mission.snapshotAt(12) : null,   // noon view
      });
      const doc = await TS.report.build(ctx);
      const name = "Fluxion_" + A.siteRec().name.replace(/[^A-Za-z0-9]+/g, "_") + "_" + A.MONTHS[A.S.site.month] + ".pdf";
      $("rpNote").textContent = "Saved " + await TS.report.save(doc, name);
    } catch (e) { $("rpNote").textContent = "Report failed: " + e.message; console.error(e); }
    finally { btn.disabled = false; }
  }
  $("rpDownload").addEventListener("click", download);

  /* ---------------------------------------------------------- tab hook */
  const _show = TS.app.showTab;
  TS.app.showTab = t => {
    if (!document.querySelector(`.view[data-view="${t}"]`)) t = "mission";   // retired views (e.g. the old quick check)
    _show(t); markMore(t);
    document.querySelectorAll(".tabs button").forEach(b => b.setAttribute("aria-selected", String(b.dataset.tab === t)));
    if (t === "report") reportItems();
  };
  TS.flow = { reportItems, download };
  if (["field"].includes(A.S.ui.tab)) TS.app.showTab("mission");
})();
