/* Mission: the layered flow.
   Layer 1  Purpose, location, occupants (and disaster type for civilian use).
   Layer 2  Geometry: a standard shelter type sized for the occupants; how
            many units are needed. "Advanced" opens it in the Designer.
   Layer 3  Material recommendation from the optimiser, then VERIFIED against
            an extreme case: the month's normal minimum lowered by 6.5 K (the
            IMD severe-cold-wave departure) for three sunless days with doubled
            wind. If it fails, insulation is increased until it passes or the
            limit is reached. Every material stays selectable.
   One design: the recommendation becomes the active design (TS.active) that
            SIM, OPT, ANSYS and the top bar read, and the tiles here show that
            design's run (A.R). If the design is then edited in SIM, Mission
            shows and verifies the edited design until its own inputs change.
   Layer 4  ANSYS check: the bridge (contract v1.0) runs the design and its
            coldest and warmest air are put beside the app's own model for the
            same inputs. The app's numbers are not adjusted to match. */
(function () {
  "use strict";
  const TS = window.TS, A = TS.app, F = TS.field, L = TS.logistics, C = TS.charts, AC = TS.active, $ = id => document.getElementById(id);
  const clone = o => JSON.parse(JSON.stringify(o));
  const f1 = v => (v == null || !isFinite(v) ? "–" : (+v).toFixed(1)).replace(/^-/, "−");
  const f2 = v => (v == null || !isFinite(v) ? "–" : (+v).toFixed(2)).replace(/^-/, "−");
  const hh = h => String(((h % 24) + 24) % 24).padStart(2, "0") + ":00";
  const KEY = "thermashelter.mission.v1";
  const STORM_DT = 6.5;
  let M = { purpose: "military", site: "leh", month: 0, occupants: 8, disaster: "cold", insMat: null, applied: null, use: "temporary", days: 90, years: 15 };
  /* how long the shelter is used decides which types are offered and what can be built:
     temporary = carried in and taken down (days to months); permanent = built to stay (years) */
  const USE = {
    temporary: ["tent_basic", "tent_winter", "prefab_eps", "bamboo", "arctic", "frp6", "frp10", "dome_tent", "igloo", "bothy", "pod", "smartcamp", "arch_solar", "arch_nissen"],
    permanent: ["prefab_eps", "hall", "hut", "frp6", "frp10", "smartcamp", "prefab_puf", "solarO2", "ladakhi", "pod", "arch_solar", "arch_nissen"],
  };
  const STATES = [...new Set(TS.SITES.map(s => s.state || "Other"))];
  try { Object.assign(M, JSON.parse(localStorage.getItem(KEY)) || {}); } catch (e) {}
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(M)); } catch (e) {} };
  let state = { d: null, units: 1, verify: null, rec: null, loop: [], twin: null, R: null, mode: "materials", hour: 4, edited: false };

  /* ---------------------------------------------------------- view */
  const sec = document.createElement("section");
  sec.className = "view"; sec.id = "view-mission"; sec.dataset.view = "mission"; sec.hidden = true;
  sec.innerHTML = `<div class="split mission">
   <form class="inputs" onsubmit="return false" autocomplete="off">
    <fieldset><legend>1 · Mission</legend>
      <div class="seg big" id="msPurpose"><button data-v="military">Military</button><button data-v="civilian">Civilian relief</button></div>
      <div class="row2"><label>State<select id="msState"></select></label><label>Region<select id="msSite"></select></label></div>
      <div class="row2"><label>Month<select id="msMonth"></select></label><label><span>Occupants</span><input id="msOcc" type="number" min="1" step="1"></label></div>
      <label>How long will it be used?</label>
      <div class="seg big" id="msUse"><button data-v="temporary">Temporary</button><button data-v="permanent">Permanent</button></div>
      <label id="msDurWrap"><span id="msDurLbl">Days in use</span><input id="msDur" type="number" min="1" step="1"></label>
      <label>Shelter type<select id="msType"></select></label>
      <label id="msDisWrap">Disaster type<select id="msDis"><option value="cold">High-altitude cold wave</option><option value="flood">Flash flood / cyclone</option><option value="quake">Earthquake</option><option value="none">General</option></select></label>
      <p class="note">New location? Use stage 01 (Location &amp; sync) once while online.</p>
    </fieldset>
    <fieldset><legend>2 · Geometry</legend><div id="msGeo" class="note"></div>
      <div class="actions"><button type="button" class="ghost" id="msAdv">Advanced level: open in Designer</button><button type="button" class="ghost" id="msReset" hidden>Back to the Mission recommendation</button></div></fieldset>
    <fieldset><legend>3 · Materials</legend>
      <p class="note keep" id="msLayerNote">Recommended layers, outside to inside. Change any material or thickness.</p>
      <div class="seg" id="msEl" role="tablist"><button data-el="wall">Walls</button><button data-el="roof">Roof</button><button data-el="floor">Floor</button></div>
      <div class="mslayers" id="msLayerList"></div>
      <div class="layerfoot"><button type="button" class="ghost" id="msAddLayer">Add layer</button><span class="uval" id="msU"></span></div>
      <div id="msVerify"></div></fieldset>
   </form>
   <article class="results">
    <section class="block first"><h2>3D twin</h2>
      <div class="controls"><div class="seg" id="msMode"><button data-v="materials">Materials</button><button data-v="explode">Exploded layers</button><button data-v="thermal">Inner-surface temperature</button><button data-v="airflow">Airflow</button></div>
        <label class="inline">Hour<input type="range" id="msHour" min="0" max="23" step="1" style="width:160px"><output id="msHourOut"></output></label></div>
      <div class="twinwrap"><div id="msTwin" class="twin"></div><div class="twinhud" id="msTwinHud"></div>
        <button type="button" class="twinplay" id="msPlay" aria-label="Play the day">▶ Play the day</button></div>
      <p class="note keep" id="msTwinNote"></p></section>
    <section class="block"><h2>24 hours, coldest month</h2><div class="chartbox" id="msChart"></div><div class="legend" id="msLegend"></div></section>
    <section class="block" hidden><h2>4 · Check with ANSYS</h2>
      <p class="lede">ANSYS runs this design and its coldest and warmest indoor air are shown beside the app's own model for the same inputs.</p>
      <div class="actions"><button type="button" class="solid" id="msAnsys">Run ANSYS on this design</button></div>
      <p class="note" id="msLoopStatus"></p>
      <div class="tablewrap"><table class="grid" id="msLoop"></table></div></section>
   </article></div>`;
  document.querySelector("main").prepend(sec);
  let tabBtn = document.querySelector('.tabs button[data-tab="mission"]');
  if (!tabBtn) { tabBtn = document.createElement("button"); tabBtn.setAttribute("role", "tab"); tabBtn.dataset.tab = "mission"; tabBtn.textContent = "MISSION"; document.querySelector(".tabs").prepend(tabBtn); }
  tabBtn.addEventListener("click", () => A.showTab("mission"));

  /* ---------------------------------------------------------- layer 2: geometry */
  function geometry() {
    const civ = M.purpose === "civilian", perm = M.use === "permanent";
    const auto = civ ? (perm ? ({ cold: "hut", flood: "prefab_eps", quake: "prefab_eps", none: "hall" }) : ({ cold: "tent_winter", flood: "prefab_eps", quake: "bamboo", none: "prefab_eps" }))[M.disaster]
      : perm ? "prefab_puf" : M.occupants <= 4 ? "arctic" : M.occupants <= 6 ? "frp6" : M.occupants <= 10 ? "frp10" : "smartcamp";
    const ok = k => F.TYPES[k] && typeList().includes(k);
    const type = M.type && ok(M.type) ? M.type : auto;
    const T = F.TYPES[type], space = civ ? (M.disaster === "cold" ? 4.5 : 3.5) : 3.5;
    let d = clone(T), units = 1;
    const cap = { arctic: 4, frp6: 6, frp10: 10, dome_tent: 3, igloo: 3, bothy: 4 }[type];
    if (cap) units = Math.ceil(M.occupants / cap);
    else if (type.startsWith("tent")) { units = Math.ceil(M.occupants * space / (d.L * d.W)); }
    else {
      const need = Math.max(12, M.occupants * space), maxA = 40;
      units = Math.ceil(need / maxA); const a = need / units;
      if (d.shape === "dome") d.L = d.W = +(2 * Math.sqrt(a / Math.PI)).toFixed(1);
      else if (d.shape === "vault") { d.W = d.W > 4 ? d.W : Math.min(4, Math.max(2.5, d.W)); d.L = +Math.max(d.W * 0.8, a / d.W).toFixed(1); d.H = d.W / 2; }   // arch huts keep their span
      else { const w = Math.max(2.5, Math.sqrt(a / 1.75)); d.L = +(a / w).toFixed(1); d.W = +w.toFixed(1); }
    }
    const per = Math.ceil(M.occupants / units);
    const AR = L.ARCHETYPES[civ ? M.disaster : "none"];
    if (civ && AR && AR.apply) d = AR.apply(d);
    if (!civ) d.pitch = Math.max(d.pitch || 0, 0);
    Object.assign(d, { people: per, wPerson: 75, equipW: 0, heater: "bukhari" });
    return { d, units, per, type, space, forbid: civ && AR ? AR.forbid : null, archetype: civ ? M.disaster : "none" };
  }
  const typeList = () => F.PROFILES[M.purpose === "civilian" ? "relief" : "defence"].types.filter(k => F.TYPES[k] && USE[M.use].includes(k));
  /* site and month are shared with the Designer and the top-bar season chips */
  function syncSite() {
    const s = A.S.site, rec = TS.SITES.find(x => x.id === M.site) || TS.SITES[0];
    if (s.id === M.site && s.month === M.month) return;
    s.id = M.site; s.month = M.month; s.alt = rec.alt; s.ghi = +rec.GHI[M.month].toFixed(2); s.wind = rec.WS[M.month];
    s.range = rec.TMAX ? +(rec.TMAX[M.month] - rec.TMIN[M.month]).toFixed(1) : 12;
    s.albedo = siteTmean(rec, M.month) < 1 ? 0.6 : (rec.terrain === "desert" ? 0.3 : 0.2);   // snow on the ground when the month freezes
    s.horizon = rec.horizon ? rec.horizon.slice() : [0, 0, 0, 0, 0, 0, 0, 0];
  }
  const siteTmean = (rec, m) => TS.engine.siteFrom(rec, m, {}).Tmean;
  function siteNow() {
    const rec = TS.SITES.find(s => s.id === A.S.site.id) || TS.SITES[0];
    return { rec, site: A.buildSite() };
  }
  function opsNow() {
    const P = F.PROFILES[M.purpose === "civilian" ? "relief" : "defence"], h = L.HEATERS.bukhari;
    return { setpoint: P.target, eta: h.eta, burnMax: h.max, kwhPerL: h.kwh, band: [P.target, P.target + 6], P };
  }

  /* ---------------------------------------------------------- layer 3: recommend + verify */
  function verifyDesign(d, site, ops) {
    const m = { d, site, ops: Object.assign({}, ops, { withSolarFraction: false }) };
    const st = F.stressTest(m, STORM_DT), stormIdx = [...Array(72).keys()].map(i => i + 48);
    const heatMin = Math.min(...stormIdx.map(i => st.heated.op[i])), unmet = stormIdx.filter(i => st.heated.unmet[i]).length;
    return { ok: heatMin >= ops.P.safeFloor - 0.05 && unmet === 0, heatMin, unmet, st };
  }
  function recommend() {
    const g = geometry(), { rec, site } = siteNow(), ops = opsNow();
    let d = g.d;
    const w = M.purpose === "civilian" ? 0.7 : 0.25, tent = F.TYPES[g.type].kind === "tent";
    /* what can be built and carried: military shelters are airlifted (factory
       insulation, no stone Trombe wall); tents take a liner of up to 30 mm and
       no glass; other relief shelters up to 200 mm */
    const snow = F.TYPES[g.type].kind === "snow";
    const perm = M.use === "permanent";
    const lim = snow ? { allowIns: ["felt"], maxT: 0.02, noTrombe: true, noGlazing: true } : tent ? { allowIns: ["felt", "eps", "straw", "aerogel"], maxT: 0.03, noTrombe: true, noGlazing: true }
      : perm ? { maxT: 0.3, noTrombe: M.purpose === "civilian" && M.disaster !== "cold" }          // built to stay: mass walls and thicker insulation allowed
      : M.purpose === "military" ? { allowIns: ["puf", "pir", "xps", "eps", "rockwool"], maxT: 0.2, noTrombe: true }   // aerogel / VIP only by hand: 10-50x the price
      : { maxT: 0.2, noTrombe: M.disaster !== "cold" };
    state.lim = lim;
    const opt = TS.optimise.optimise(d, site, ops, w, g.forbid, lim);
    // keep the recommended envelope but the mission's own geometry
    d = Object.assign(clone(opt.design), { L: g.d.L, W: g.d.W, H: g.d.H });
    for (const el of ["wall", "roof", "floor"]) d[el] = d[el].map(l => { const c = Object.assign({}, l); delete c.k; return c; });
    if (M.insMat) d = TS.optimise.setIns(d, M.insMat, (TS.optimise.insOf(d) || { t: 0.1 }).t);
    // escalate insulation until the extreme case passes
    let v = verifyDesign(d, site, ops), steps = 0;
    while (!v.ok && steps < 8) {
      const ins = TS.optimise.insOf(d) || { mat: g.forbid && g.forbid("eps") ? "straw" : "eps", t: 0.05 };
      const t = Math.min(lim.maxT || 0.3, ins.t + (lim.maxT && lim.maxT < 0.05 ? 0.01 : 0.05)); if (t <= ins.t + 1e-9) break;
      d = TS.optimise.setIns(d, ins.mat, t); v = verifyDesign(d, site, ops); steps++;
    }
    return Object.assign(state, { d, units: g.units, g, verify: v, rec: opt, site, rec_: rec, ops, steps, edited: false });
  }
  /* the recommendation becomes the one active design */
  function share(s) {
    const a = AC.fromMission(s.d, s.units, F.TYPES[s.g.type].name, s.ops);
    A.S.design = a.design; Object.assign(A.S.ops, a.ops);
    A.syncInputs();
    A.S.verify = { sig: AC.sig(A.S.design), ok: s.verify.ok, heatMin: s.verify.heatMin };
    A.runNow();
    M.applied = AC.sig(A.S.design); A.S.verify.sig = M.applied; save();
    s.d = A.S.design;
  }
  /* the design was edited in SIM: show and verify it, do not replace it */
  function adopt() {
    const d = A.S.design, { rec, site } = siteNow(), ops = opsNow(), v = verifyDesign(d, site, ops);
    Object.assign(state, { d, units: d.units || 1, g: null, verify: v, site, rec_: rec, ops, steps: 0, edited: true });
    A.S.verify = { sig: AC.sig(d), ok: v.ok, heatMin: v.heatMin };
    A.runNow();
    return state;
  }

  /* fuel over the period of use: temporary = days x this month's daily fuel;
     permanent = the model run for all 12 months of the year x design life */
  const DIM = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  let durCache = { key: null, val: null };
  function durationFuel(d, R, units) {
    if (M.use !== "permanent") { const days = Math.max(1, M.days | 0); return { use: "temporary", days, total: R.summary.fuel_L * units * days }; }
    const key = AC.sig(d) + "|" + A.S.site.id + "|" + A.S.site.alt + "|" + units;
    if (durCache.key !== key) {
      const rec = siteNow().rec, ops = Object.assign({}, A.ops(), { withSolarFraction: false });
      const months = DIM.map((n, m) => TS.airflow.simulate(d, TS.engine.siteFrom(rec, m, { alt: A.S.site.alt, horizon: A.S.site.horizon }), ops, "kerosene").summary.fuel_L * units * n);
      durCache = { key, val: { months, year: months.reduce((a, b) => a + b, 0) } };
    }
    const years = Math.max(1, M.years | 0);
    return { use: "permanent", years, months: durCache.val.months, year: durCache.val.year, total: durCache.val.year * years };
  }

  /* ---------------------------------------------------------- layer editor (step 3) */
  // edits the active design directly; the design then counts as edited and Mission verifies it
  function renderLayers(forbid) {
    const el = state.el || "wall", d = A.S.design, E = TS.engine, ls = d[el];
    document.querySelectorAll("#msEl button").forEach(b => b.setAttribute("aria-selected", String(b.dataset.el === el)));
    const opts = Object.entries(TS.MATERIALS).filter(([k]) => k !== "custom")
      .map(([k, m]) => `<option value="${k}"${forbid && forbid(k) ? " disabled" : ""}>${m.name}</option>`).join("");
    $("msLayerList").innerHTML = ls.map((l, i) => {
      const p = E.layerProps(l, TS.MATERIALS), mm = l.t * 1000;
      return `<div class="mslayer" data-i="${i}"><span class="n">${i + 1}${i === 0 ? " <small>out</small>" : i === ls.length - 1 ? " <small>in</small>" : ""}</span>` +
        `<select data-f="mat" aria-label="Material of layer ${i + 1}">${opts}</select>` +
        `<label class="mm"><input data-f="t" type="number" min="0.1" step="${mm < 5 ? 0.1 : 5}" value="${mm < 5 ? mm.toFixed(1) : Math.round(mm)}" aria-label="Thickness of layer ${i + 1}"><small>mm</small></label>` +
        `<button type="button" class="iconbtn" data-f="del" aria-label="Remove layer ${i + 1}">×</button></div>`;
    }).join("");
    $("msLayerList").querySelectorAll(".mslayer").forEach(row => {
      const i = +row.dataset.i; row.querySelector("[data-f=mat]").value = ls[i].mat;
      row.querySelector("[data-f=mat]").addEventListener("change", e => { ls[i] = { mat: e.target.value, t: ls[i].t }; layersChanged(); });
      row.querySelector("[data-f=t]").addEventListener("change", e => { const v = parseFloat(e.target.value); if (v > 0) { ls[i].t = v / 1000; layersChanged(); } });
      row.querySelector("[data-f=del]").addEventListener("click", () => { if (ls.length > 1) { ls.splice(i, 1); layersChanged(); } });
    });
    const R = E.constructionR(ls, TS.MATERIALS), U = 1 / (E.RSI[el] + R + (el === "floor" ? 0.5 : 0.04));
    $("msU").textContent = `U ${U.toFixed(2)} W/m²K`;
  }
  function layersChanged() { A.syncInputs(); A.runNow(); render(); }

  /* ---------------------------------------------------------- render */
  function render() {
    const P = F.PROFILES[M.purpose === "civilian" ? "relief" : "defence"];
    M.site = A.S.site.id; M.month = A.S.site.month;
    document.querySelectorAll("#msPurpose button").forEach(b => b.setAttribute("aria-selected", String(b.dataset.v === M.purpose)));
    const pb = document.querySelector(`#profileSeg button[data-v=${M.purpose === "civilian" ? "relief" : "defence"}]`); if (pb && pb.getAttribute("aria-selected") !== "true") pb.click();
    const st = (TS.SITES.find(s => s.id === M.site) || TS.SITES[0]).state || "Other";
    $("msState").innerHTML = STATES.map(s => `<option>${s}</option>`).join(""); $("msState").value = st;
    $("msSite").innerHTML = TS.SITES.filter(s => (s.state || "Other") === st).map(s => `<option value="${s.id}">${s.region || s.name} (${s.alt} m)</option>`).join(""); $("msSite").value = M.site;
    document.querySelectorAll("#msUse button").forEach(b => b.setAttribute("aria-selected", String(b.dataset.v === M.use)));
    $("msDurLbl").textContent = M.use === "permanent" ? "Design life (years)" : "Days in use";
    $("msDur").value = M.use === "permanent" ? M.years : M.days;
    $("msMonth").innerHTML = F.MONTHS.map((m, i) => `<option value="${i}">${m}</option>`).join(""); $("msMonth").value = M.month;
    $("msOcc").value = M.occupants;
    const tlist = typeList();
    $("msType").innerHTML = `<option value="">Automatic for ${M.occupants} people</option>` + tlist.map(k => `<option value="${k}">${F.TYPES[k].name}</option>`).join("");
    $("msType").value = tlist.includes(M.type) ? M.type : ""; $("msDis").value = M.disaster; $("msDisWrap").hidden = M.purpose !== "civilian";
    $("msVerify").innerHTML = `<p class="note"><span class="spin"></span> Recommending and verifying…</p>`;
    setTimeout(() => {
      let s;
      if (AC.edited(A.S.design, M.applied)) s = adopt();
      else { s = recommend(); share(s); }
      const g = s.g, d = s.d, v = s.verify, R = A.R;
      state.R = R;
      $("msReset").hidden = !s.edited;
      $("msGeo").innerHTML = s.edited
        ? `<b>Your design:</b> ${AC.label(d)}, ${d.people} people per unit (changed by you). It stays until you change a Mission input or go back to the recommendation.`
        : `<b>${s.units} × ${F.TYPES[g.type].name}</b>, ${f1(d.L)} × ${f1(d.W)} × ${f1(d.H)} m each, ${g.per} people per unit (${g.space} m² per person${M.purpose === "civilian" ? ", Sphere" : ""}). ` +
          (M.purpose === "civilian" && L.ARCHETYPES[M.disaster].note ? L.ARCHETYPES[M.disaster].note : "");
      const insNow = TS.optimise.insOf(d), forbid = g && g.forbid;
      const allowed = Object.entries(TS.MATERIALS).filter(([k, m]) => m.cls === "ins");   // every option stays listed (user override)
      renderLayers(forbid);
      $("msLayerNote").textContent = s.edited ? "Your layers, outside to inside (changed from the recommendation)." : "Recommended layers, outside to inside. Change any material or thickness.";
      $("msVerify").innerHTML = `<div class="badge ${v.ok ? "ok" : "bad"}">${v.ok ? "VERIFIED" : "NOT VERIFIED"}</div>
        <p class="note">Extreme case: ${s.rec_.name} ${F.MONTHS[M.month]} normal minus ${STORM_DT} K (IMD severe cold wave), three days without sun, double wind. ` +
        `With one heater the coldest hour is ${f1(v.heatMin)} °C against a ${P.safeFloor} °C floor${v.unmet ? `; heater short ${v.unmet} h` : ""}.${s.steps ? ` Insulation raised ${s.steps} step(s) to pass.` : ""}</p>
        <p class="note">${s.edited ? "Envelope" : "Recommended"}: ${insNow ? `${TS.MATERIALS[insNow.mat].name} ${Math.round(insNow.t * 1000)} mm` : "no insulation layer"}, ${TS.GLAZING[d.glazing].name} glazing ${f1((d.win || {}).front || 0)} m²${d.trombe && d.trombe.area ? `, Trombe wall ${f1(d.trombe.area)} m²` : ""}${d.store && d.store.type !== "none" ? `, ${d.store.mass} kg water` : ""}${d.shutter ? ", night shutters" : ""}.</p>`;
      if (d.kind === "snow" || (g && F.TYPES[g.type].kind === "snow")) {
        /* snow shelters: no stove; the test is that the inner snow stays frozen.
           Above 0 °C the walls melt, which caps the room near 0 °C in reality. */
        const air = R.passive.air, mx = Math.max(...R.elems.flatMap((es, h) => es.filter(e => e.kind !== "floor").map(e => air[h] - e.U * e.rsi * (air[h] - e.th))));
        const ok = mx <= 0; v.ok = ok; A.S.verify = Object.assign({}, A.S.verify, { ok });
        $("msVerify").innerHTML = `<div class="badge ${ok ? "ok" : "bad"}">${ok ? "WALLS STAY FROZEN" : "WALLS WOULD MELT"}</div><p class="note">No heater in a snow shelter. Warmest inner snow surface ${f1(mx)} °C${ok ? "" : ": more ventilation or fewer people, otherwise the walls glaze and drip and the room settles near 0 °C"}. Survival shelter only.</p>`;
      }
      state.dur = durationFuel(d, R, s.units);
      const ax = R.amb.map((_, i) => i + 0.5);
      C.line($("msChart"), { x: ax, xTicks: [0, 3, 6, 9, 12, 15, 18, 21, 24], xEndPad: 0.5, xFmt: v => String(Math.floor(v) % 24).padStart(2, "0") + ":00", height: 240, unit: " °C", tipDigits: 1, yLabel: "°C",
        hbands: [{ y0: P.target, y1: P.target + 6, cls: "band", label: `Target ${P.target} °C and above`, fit: true }],
        series: [{ name: "Outside", y: R.amb, cls: "amb", width: 2 }, { name: "Inside, no heating", y: R.passive.op, cls: "pas", width: 2.6 }] });
      $("msLegend").innerHTML = `<span class="l-amb">Outside</span><span class="l-pas">Inside, no heating</span>`;
      if (TS.figmaui) TS.figmaui.ticker();
      drawTwin();
    }, 20);
  }
  function drawTwin() {
    if (!window.THREE) { $("msTwin").innerHTML = `<p class="note">3D view needs WebGL.</p>`; return; }
    try { if (!state.twin) state.twin = TS.twin3d.Twin($("msTwin")); }
    catch (e) { $("msTwin").innerHTML = `<p class="note">3D view unavailable on this device (${e.message}).</p>`; return; }
    document.querySelectorAll("#msMode button").forEach(b => b.setAttribute("aria-selected", String(b.dataset.v === state.mode)));
    $("msHour").value = state.hour; $("msHourOut").textContent = String(state.hour).padStart(2, "0") + ":00";
    const explode = state.mode === "explode", rg = state.twin.update(state.d, state.R, explode ? "materials" : state.mode, state.hour, { explode });
    // the site's real environment around the shelter: sun from the sun-path model, snow, wind, terrain
    const site = A.buildSite(), rec = siteNow().rec, h = state.hour, tOut = state.R.amb[h];
    // snow falls in a freezing month at night or on a dull day, not from a clear midday sky
    const sunUp = TS.engine.sunPos(site.lat, site.lon, site.doy, h + 0.5, 82.5).alt > 0, KT = state.R.meta && state.R.meta.KT;
    const snowing = site.Tmean < 0 && tOut < 1 && (!sunUp || (KT != null && KT < 0.45)), cover = A.S.site.albedo >= 0.6;
    const sky = state.twin.setEnv({ lat: site.lat, lon: site.lon, doy: site.doy, hour: h, tOut, tMean: site.Tmean, wind: site.wind, terrain: rec.terrain || "plain", snowCover: cover, snowing });
    $("msTwinHud").innerHTML = `<b>${rec.name}</b> · ${F.MONTHS[A.S.site.month]} · ${hh(h)}<br>` +
      `Outside ${f1(tOut)} °C · inside ${f1(state.R.heated.op[h])} °C with heater · wind ${f1(site.wind)} m/s<br>` +
      `${sky && sky.day ? `Sun ${Math.round(sky.sunAlt)}° up` : "Sun below the horizon"}${snowing ? " · snowing" : cover ? " · snow on the ground" : ""}`;
    $("msTwinNote").textContent = state.mode === "thermal" ? `Inner surfaces at ${String(state.hour).padStart(2, "0")}:00, heated: ${rg ? `${f1(rg.lo)} (blue) to ${f1(rg.hi)} °C (red)` : ""}. One value per surface from the zone model; corners and thermal bridges need the ANSYS field.`
      : state.mode === "airflow" ? `Schematic of the computed airflow: ${f2(state.R.ach[state.hour])} air changes an hour at this hour, in low and out high (stack effect). Not CFD.` : explode ? "Each layer pulled apart and named, outside to inside. Thin sheets are drawn 25 mm thick so they can be seen." : "Every layer is built from the design. Drag to turn, scroll to zoom.";
  }

  /* ---------------------------------------------------------- layer 4: ANSYS check */
  async function runLoop() {
    const i = TS.bridgeUI.inputsFrom(state.d), errs = TS.bridgeUI.validate(i);
    if (errs.length) { $("msLoopStatus").textContent = "Not sent to ANSYS: " + errs.join("; "); return; }
    $("msAnsys").disabled = true;
    try {
      const res = await TS.bridgeUI.runJob(i, s => ($("msLoopStatus").textContent = `ANSYS ${s.state}, ${Math.round(s.elapsed_s || 0)} s`));
      /* a mock bridge always returns the stored real base-case run, so compare
         against the inputs of that run, not the design that was sent */
      const ci = res.mock ? { L: 5, W: 4, H: 2.8, T_INS: 0.1, K_INS: 0.025, RHO_INS: 40, CP_INS: 1500, WIN_W: 1.5, WIN_H: 1.2 } : i;
      const app = TS.bridgeUI.appEquivalent(ci), o = res.outputs;
      TS.bridgeUI.record(res, ci, app, res.mock ? "Stored base case 5 × 4 × 2.8 m (practice)" : AC.label(state.d));
      state.loop.push({ n: state.loop.length + 1, mock: res.mock, aMin: o.T_AIR_MIN, aMax: o.T_AIR_MAX, pMin: app.T_AIR_MIN, pMax: app.T_AIR_MAX });
      $("msLoop").innerHTML = `<tr><th>Run</th><th>ANSYS coldest air</th><th>App coldest air</th><th>ANSYS warmest air</th><th>App warmest air</th></tr>` +
        state.loop.map(p => `<tr><td>${p.n}${p.mock ? " (mock)" : ""}</td><td>${f1(p.aMin)} °C</td><td>${f1(p.pMin)} °C</td><td>${f1(p.aMax)} °C</td><td>${f1(p.pMax)} °C</td></tr>`).join("");
      $("msLoopStatus").innerHTML = (res.mock ? "<b class='warnline'>Mock bridge: this row is the stored real base-case run (5 × 4 × 2.8 m, 100 mm PUF), not this design.</b> " : "") +
        `Same inputs in both: ANSYS ${f1(o.T_AIR_MIN)} to ${f1(o.T_AIR_MAX)} °C, app ${f1(app.T_AIR_MIN)} to ${f1(app.T_AIR_MAX)} °C. The app's numbers are not adjusted to match.`;
    } catch (e) { $("msLoopStatus").textContent = "ANSYS run failed: " + e.message; }
    finally { $("msAnsys").disabled = false; }
  }

  /* ---------------------------------------------------------- wiring */
  // any change to a Mission input asks for a fresh recommendation
  const changed = fn => e => { fn(e); M.applied = null; save(); render(); };
  document.querySelectorAll("#msPurpose button").forEach(b => b.addEventListener("click", changed(() => { M.purpose = b.dataset.v; M.insMat = null; M.type = null; })));
  $("msState").addEventListener("change", changed(e => { M.site = (TS.SITES.find(s => (s.state || "Other") === e.target.value) || TS.SITES[0]).id; syncSite(); }));
  $("msSite").addEventListener("change", changed(e => { M.site = e.target.value; syncSite(); }));
  document.querySelectorAll("#msUse button").forEach(b => b.addEventListener("click", changed(() => { M.use = b.dataset.v; M.type = null; M.insMat = null; })));
  $("msDur").addEventListener("change", e => { const v = Math.max(1, Math.round(+e.target.value || 1)); if (M.use === "permanent") M.years = v; else M.days = v; save(); render(); });
  // one mode everywhere: the top-bar MILITARY / CIVILIAN switch is the same choice as Mission's purpose
  document.querySelectorAll("#profileSeg button").forEach(b => b.addEventListener("click", () => {
    const p = b.dataset.v === "relief" ? "civilian" : "military";
    if (p === M.purpose) return;
    M.purpose = p; M.type = null; M.insMat = null; M.applied = null; save(); if (!sec.hidden) render();
  }));
  // month or region changed elsewhere (SIM, top-bar season chips): Mission recommends again for it
  ["month", "site"].forEach(id => $(id).addEventListener("change", () => { M.applied = null; save(); if (!sec.hidden) setTimeout(render, 120); }));
  let play = 0;
  $("msPlay").addEventListener("click", () => {
    if (play) { clearInterval(play); play = 0; $("msPlay").textContent = "▶ Play the day"; return; }
    $("msPlay").textContent = "❚❚ Pause";
    play = setInterval(() => { if (sec.hidden || !state.R) return; state.hour = (state.hour + 1) % 24; drawTwin(); }, 700);
  });
  $("msMonth").addEventListener("change", changed(e => { M.month = +e.target.value; syncSite(); }));
  $("msOcc").addEventListener("change", changed(e => { M.occupants = Math.max(1, Math.round(+e.target.value || 1)); }));
  $("msType").addEventListener("change", changed(e => { M.type = e.target.value || null; M.insMat = null; }));
  $("msDis").addEventListener("change", changed(e => { M.disaster = e.target.value; M.insMat = null; }));
  document.querySelectorAll("#msEl button").forEach(b => b.addEventListener("click", () => { state.el = b.dataset.el; renderLayers(); }));
  $("msAddLayer").addEventListener("click", () => { const el = state.el || "wall"; A.S.design[el].push({ mat: "rockwool", t: 0.05 }); layersChanged(); });
  $("msReset").addEventListener("click", changed(() => {}));
  $("msAdv").addEventListener("click", () => A.showTab("design"));
  $("msAnsys").addEventListener("click", runLoop);
  document.querySelectorAll("#msMode button").forEach(b => b.addEventListener("click", () => { state.mode = b.dataset.v; drawTwin(); }));
  $("msHour").addEventListener("input", e => { state.hour = +e.target.value; drawTwin(); });
  window.addEventListener("resize", () => { if (state.twin && !sec.hidden) state.twin.resize(); });

  const _show = TS.app.showTab;
  TS.app.showTab = t => { _show(t); tabBtn.setAttribute("aria-selected", String(t === "mission")); if (t === "mission") render(); };
  // picture of the shelter at its site at a given hour (for the report), then back to the user's hour
  function snapshotAt(hour) {
    if (!state.twin || !state.R) return null;
    const old = state.hour; state.hour = hour; drawTwin(); const img = state.twin.snapshot(); state.hour = old; drawTwin(); return img;
  }
  TS.mission = { render, state: () => state, verifyDesign, geometry, STORM_DT, snapshotAt };
  // one mode from the start: the top-bar switch follows Mission's purpose whatever step opens first
  { const pb = document.querySelector(`#profileSeg button[data-v=${M.purpose === "civilian" ? "relief" : "defence"}]`); if (pb && pb.getAttribute("aria-selected") !== "true") pb.click(); }
  if (A.S.ui.tab === "mission" || !A.S.ui.tab) TS.app.showTab("mission");
})();
