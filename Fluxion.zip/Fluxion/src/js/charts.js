/* Minimal SVG charts drawn for this app: line (with bands and hover read-out),
   scatter (with optional 1:1 line), horizontal bars. No dependencies, so the
   app runs fully offline in Tauri, Capacitor and the browser. */
(function (g) {
  g.TS = g.TS || {};
  const NS = "http://www.w3.org/2000/svg";
  const el = (n, a, p) => { const e = document.createElementNS(NS, n); for (const k in a || {}) e.setAttribute(k, a[k]); if (p) p.appendChild(e); return e; };
  const fmt = (v, d) => (v == null || !isFinite(v) ? "–" : (+v).toFixed(d == null ? 1 : d));

  function niceTicks(lo, hi, n) {
    if (!(hi > lo)) { hi = lo + 1; }
    const span = hi - lo, raw = span / Math.max(1, n), mag = Math.pow(10, Math.floor(Math.log10(raw)));
    const step = [1, 2, 2.5, 5, 10].map(m => m * mag).find(s => span / s <= n) || 10 * mag;
    const a = Math.floor(lo / step) * step, b = Math.ceil(hi / step) * step, t = [];
    for (let v = a; v <= b + step * 1e-9; v += step) t.push(+v.toFixed(10));
    return t;
  }
  function frame(host, cfg) {
    host.innerHTML = "";
    const W = Math.max(280, host.clientWidth || 600), H = cfg.height || 280;
    const m = Object.assign({ l: 46, r: 14, t: cfg.yLabel ? 24 : 12, b: 34 }, cfg.margin || {});
    const svg = el("svg", { viewBox: `0 0 ${W} ${H}`, width: "100%", height: H, class: "chart", role: "img" }, host);
    if (cfg.label) svg.setAttribute("aria-label", cfg.label);
    return { svg, W, H, m, iw: W - m.l - m.r, ih: H - m.t - m.b };
  }
  function axes(f, xs, ys, xt, yt, cfg) {
    const { svg, m, iw, ih } = f;
    const gA = el("g", { class: "axes" }, svg);
    for (const v of yt) {
      const y = ys(v);
      el("line", { x1: m.l, x2: m.l + iw, y1: y, y2: y, class: v === 0 ? "grid zero" : "grid" }, gA);
      el("text", { x: m.l - 6, y: y + 4, class: "tick", "text-anchor": "end" }, gA).textContent = cfg.yFmt ? cfg.yFmt(v) : v;
    }
    for (const v of xt) {
      const x = xs(v);
      el("line", { x1: x, x2: x, y1: m.t + ih, y2: m.t + ih + 4, class: "tickline" }, gA);
      el("text", { x, y: m.t + ih + 17, class: "tick", "text-anchor": "middle" }, gA).textContent = cfg.xFmt ? cfg.xFmt(v) : v;
    }
    if (cfg.yLabel) el("text", { x: 4, y: 2, class: "axlabel", "dominant-baseline": "hanging" }, gA).textContent = cfg.yLabel;
    if (cfg.xLabel) el("text", { x: m.l + iw, y: m.t + ih + 31, class: "axlabel", "text-anchor": "end" }, gA).textContent = cfg.xLabel;
  }

  /* cfg: { x:[...], series:[{name,y,cls,width,dash}], hbands:[{y0,y1,cls,label}],
           vbands:[{x0,x1,cls}], yLabel, xLabel, xFmt, yFmt, yPad, height, unit } */
  function line(host, cfg) {
    const f = frame(host, cfg), { svg, m, iw, ih } = f;
    const xs0 = cfg.x[0], xs1 = cfg.x[cfg.x.length - 1] + (cfg.xEndPad || 0);
    let lo = Infinity, hi = -Infinity;
    for (const s of cfg.series) for (const v of s.y) if (v != null && isFinite(v)) { lo = Math.min(lo, v); hi = Math.max(hi, v); }
    for (const b of cfg.hbands || []) { if (b.fit) { lo = Math.min(lo, b.y0); hi = Math.max(hi, b.y1); } }
    const pad = (hi - lo) * 0.08 + (cfg.yPad || 0.5);
    const yt = niceTicks(lo - pad, hi + pad, cfg.yTicks || 6);
    const y0 = yt[0], y1 = yt[yt.length - 1];
    const xs = v => m.l + (v - xs0) / (xs1 - xs0) * iw, ys = v => m.t + ih - (v - y0) / (y1 - y0) * ih;
    for (const b of cfg.vbands || []) el("rect", { x: xs(b.x0), y: m.t, width: Math.max(0, xs(b.x1) - xs(b.x0)), height: ih, class: b.cls }, svg);
    for (const b of cfg.hbands || []) {
      const ya = ys(Math.min(b.y1, y1)), yb = ys(Math.max(b.y0, y0));
      if (yb > ya) el("rect", { x: m.l, y: ya, width: iw, height: yb - ya, class: b.cls }, svg);
      if (b.label) el("text", { x: m.l + iw - 4, y: ya + 13, class: "bandlabel", "text-anchor": "end" }, svg).textContent = b.label;
    }
    axes(f, xs, ys, cfg.xTicks || niceTicks(xs0, xs1, 8).filter(v => v >= xs0 && v <= xs1), yt, cfg);
    if (cfg.fillBetween) {
      const [a, b] = cfg.fillBetween.map(i => cfg.series[i].y);
      let d = "";
      cfg.x.forEach((x, i) => { d += (i ? "L" : "M") + xs(x) + "," + ys(a[i]); });
      for (let i = cfg.x.length - 1; i >= 0; i--) d += "L" + xs(cfg.x[i]) + "," + ys(b[i]);
      el("path", { d: d + "Z", class: cfg.fillBetweenCls || "gap" }, svg);
    }
    for (const s of cfg.series) {
      let d = "", pen = false;
      s.y.forEach((v, i) => { if (v == null || !isFinite(v)) { pen = false; return; } d += (pen ? "L" : "M") + xs(cfg.x[i]).toFixed(1) + "," + ys(v).toFixed(1); pen = true; });
      el("path", { d, class: "series " + (s.cls || ""), "stroke-width": s.width || 2, "stroke-dasharray": s.dash || "" }, svg);
      if (s.points) s.y.forEach((v, i) => { if (v != null) el("circle", { cx: xs(cfg.x[i]), cy: ys(v), r: 3, class: "pt " + (s.cls || "") }, svg); });
    }
    // hover read-out
    const cross = el("line", { y1: m.t, y2: m.t + ih, class: "cross", visibility: "hidden" }, svg);
    const tip = document.createElement("div"); tip.className = "tip"; tip.hidden = true; host.appendChild(tip);
    const hit = el("rect", { x: m.l, y: m.t, width: iw, height: ih, fill: "transparent" }, svg);
    const move = ev => {
      const r = svg.getBoundingClientRect(), px = (ev.clientX - r.left) * f.W / r.width;
      let best = 0, bd = Infinity;
      cfg.x.forEach((x, i) => { const dd = Math.abs(xs(x) - px); if (dd < bd) { bd = dd; best = i; } });
      const X = xs(cfg.x[best]);
      cross.setAttribute("x1", X); cross.setAttribute("x2", X); cross.setAttribute("visibility", "visible");
      tip.hidden = false;
      tip.innerHTML = `<b>${cfg.xFmt ? cfg.xFmt(cfg.x[best], true) : cfg.x[best]}</b>` + cfg.series.filter(s => !s.noTip).map(s =>
        `<span class="k ${s.cls || ""}"></span>${s.name} <em>${fmt(s.y[best], cfg.tipDigits)}${cfg.unit || ""}</em>`).join("<br>");
      const left = X / f.W * r.width;
      tip.style.left = Math.min(r.width - 170, Math.max(0, left + 12)) + "px";
      tip.style.top = "8px";
    };
    hit.addEventListener("pointermove", move);
    hit.addEventListener("pointerdown", move);
    hit.addEventListener("pointerleave", () => { cross.setAttribute("visibility", "hidden"); tip.hidden = true; });
    return { xs, ys };
  }

  /* cfg: { sets:[{name,cls,pts:[[x,y],...]}], identity:bool, xLabel, yLabel } */
  function scatter(host, cfg) {
    const f = frame(host, cfg), { svg, m, iw, ih } = f;
    let xl = Infinity, xh = -Infinity, yl = Infinity, yh = -Infinity;
    for (const s of cfg.sets) for (const [x, y] of s.pts) { xl = Math.min(xl, x); xh = Math.max(xh, x); yl = Math.min(yl, y); yh = Math.max(yh, y); }
    if (cfg.identity) { xl = yl = Math.min(xl, yl); xh = yh = Math.max(xh, yh); }
    const xt = niceTicks(xl - (xh - xl) * 0.05 - 0.1, xh + (xh - xl) * 0.05 + 0.1, 7), yt = niceTicks(yl - (yh - yl) * 0.05 - 0.1, yh + (yh - yl) * 0.05 + 0.1, 6);
    const xs = v => m.l + (v - xt[0]) / (xt[xt.length - 1] - xt[0]) * iw, ys = v => m.t + ih - (v - yt[0]) / (yt[yt.length - 1] - yt[0]) * ih;
    axes(f, xs, ys, xt, yt, cfg);
    if (cfg.identity) { const a = Math.max(xt[0], yt[0]), b = Math.min(xt[xt.length - 1], yt[yt.length - 1]); el("line", { x1: xs(a), y1: ys(a), x2: xs(b), y2: ys(b), class: "identity" }, svg); }
    for (const s of cfg.sets) for (const [x, y] of s.pts) el("circle", { cx: xs(x), cy: ys(y), r: cfg.r || 3, class: "pt " + (s.cls || "") }, svg);
  }

  /* cfg: { items:[{label, value, cls, note}], unit, digits, height per row } */
  function bars(host, cfg) {
    host.innerHTML = "";
    const rows = cfg.items, W = Math.max(280, host.clientWidth || 600), rh = cfg.rowH || 26;
    const H = rows.length * rh + 10, lab = cfg.labelW || 120, valW = 70;
    const svg = el("svg", { viewBox: `0 0 ${W} ${H}`, width: "100%", height: H, class: "chart bars" }, host);
    const mx = Math.max(1e-9, ...rows.map(r => Math.abs(r.value)));
    const hasNeg = rows.some(r => r.value < 0);
    const x0 = lab + (hasNeg ? (W - lab - valW) * 0.25 : 0), span = (W - lab - valW) - (x0 - lab);
    rows.forEach((r, i) => {
      const y = 5 + i * rh;
      el("text", { x: lab - 8, y: y + rh / 2 + 4, class: "barlabel", "text-anchor": "end" }, svg).textContent = r.label;
      const w = Math.abs(r.value) / mx * span * (hasNeg && r.value < 0 ? 0.33 : 1);
      el("rect", { x: r.value >= 0 ? x0 : x0 - w, y: y + 5, width: Math.max(1, w), height: rh - 10, class: "bar " + (r.cls || "") }, svg);
      el("text", { x: (r.value >= 0 ? x0 + w : x0) + 6, y: y + rh / 2 + 4, class: "barval" }, svg).textContent = fmt(r.value, cfg.digits) + (cfg.unit || "");
    });
    if (hasNeg) el("line", { x1: x0, x2: x0, y1: 0, y2: H, class: "grid zero" }, svg);
  }

  g.TS.charts = { line, scatter, bars, niceTicks, fmt };
})(typeof window !== "undefined" ? window : globalThis);
