/* Moisture and surface temperatures.
   1. Indoor humidity: hourly water-vapour balance of the room air
        rho V dW/dt = G_w - rho Q (W - W_out)
      G_w: occupants 45 g/h each (resting adult, BS 5250 order of magnitude)
           + unflued stove water (kerosene ~C12H26: 1.38 kg water per kg fuel,
           1.09 kg per litre at 0.79 kg/L). No hygroscopic buffering, which
           over-predicts peaks slightly (conservative).
   2. Surface condensation / hoarfrost: inner surface temperature of each
      element, theta_si = theta_air - U R_si (theta_air - theta_out,eq),
      against the indoor dew point (Magnus). Below 0 C on the surface the
      deposit is frost.
   3. Interstitial (Glaser, ISO 13788 simplified, flagged above 1 g/m2 a day): steady state at the coldest
      hour; temperature and saturation vapour pressure at every layer
      interface vs the straight-line vapour-pressure profile through the
      cumulative vapour resistance (mu * d). Where the line rises above
      saturation, moisture condenses (or freezes) inside the wall.
      mu values: ISO 10456 where listed; fabrics, felt, bamboo team-estimated.
   4. Exterior skin: theta_so = theta_eq + U R_se (theta_air - theta_eq): the
      outer surface temperature, reported as contrast against outside air. */
(function (g) {
  "use strict";
  const TS = g.TS;
  const MU = { steel: 1e6, alu: 1e6, puf: 60, xps: 150, eps: 60, rockwool: 1, aerogel: 5, vip: 1e6, straw: 2, airgap: 1,
    mudbrick: 10, rammed: 10, stone: 50, brick: 10, concrete: 130, mudplast: 10, gypsum: 10, timber: 50, plywood: 200,
    canvas: 10, pesheet: 1e5, felt: 2, bamboo: 50, cplaster: 25, custom: 10 };
  const WATER_PER_UNIT = { kerosene: 1.09, lpg: 1.6, wood: 0.6 };   // kg per L or kg burnt (unflued only)

  function psat(T) { return T >= 0 ? 610.94 * Math.exp(17.625 * T / (T + 243.04)) : 611.15 * Math.exp(22.452 * T / (T + 272.55)); } // Pa, Magnus (water / ice)
  function dew(p) { const a = Math.log(Math.max(p, 1) / 610.94); return 243.04 * a / (17.625 - a); }
  function humRatio(T, RH, P) { const pv = RH / 100 * psat(T); return 0.622 * pv / (P - pv); }
  function pvFromW(W, P) { return W * P / (0.622 + W); }

  /* r: engine (or airflow) result; d: design; fuelKey for an unflued stove */
  function analyse(r, d, fuelKey, ops) {
    const P = TS.engine.pressurePa(r.site.alt), V = TS.engine.geom(d).V, rho = r.net.rhoAir, N = r.N;
    const air = r.heated.air;
    let W = humRatio(r.amb[0], r.rhOut[0], P) * 1.5;
    const rhIn = [], dpIn = [], Wseries = [];
    for (let rep = 0; rep < 3; rep++) for (let i = 0; i < N; i++) {
      const Wo = humRatio(r.amb[i], r.rhOut[i], P);
      const occ = (r.hours[i] >= 18 || r.hours[i] < 8) ? d.people : Math.ceil(d.people / 2);
      const fuelPerH = d.unflued && fuelKey ? r.heated.phi[i] / 1000 / (ops.kwhPerL * ops.eta) : 0;
      const Gw = (occ * 0.045 + fuelPerH * (WATER_PER_UNIT[fuelKey] || 0)) / 3600;   // kg/s
      const Q = r.ach[i] * V / 3600;
      for (let k = 0; k < 10; k++) W += 360 * (Gw - rho * Q * (W - Wo)) / (rho * V);
      if (rep === 2) { const pv = pvFromW(W, P); Wseries.push(W); rhIn.push(Math.min(100, 100 * pv / psat(air[i]))); dpIn.push(dew(pv)); }
    }
    // inner surfaces
    const surf = {};
    r.elems[0].forEach(e => (surf[e.id] = { id: e.id, kind: e.kind, minTsi: Infinity, hoursWet: 0, hoursFrost: 0, maxSkinContrast: -Infinity, nightSkinContrast: -Infinity }));
    for (let i = 0; i < N; i++) for (const e of r.elems[i]) {
      const s = surf[e.id], tsi = air[i] - e.U * e.rsi * (air[i] - e.th);
      s.minTsi = Math.min(s.minTsi, tsi);
      if (tsi < dpIn[i]) { s.hoursWet++; if (tsi < 0) s.hoursFrost++; }
      if (e.rse != null) {
        const tso = e.th + e.U * e.rse * (air[i] - e.th), c = tso - r.amb[i];
        s.maxSkinContrast = Math.max(s.maxSkinContrast, c);
        if (r.night[i]) s.nightSkinContrast = Math.max(s.nightSkinContrast, c);
      }
    }
    // interstitial at the coldest hour, per construction
    const iCold = r.amb.indexOf(Math.min(...r.amb));
    const inter = ["wall", "roof"].map(el => glaser(d[el], air[iCold], pvFromW(Wseries[iCold], P), r.amb[iCold],
      r.rhOut[iCold] / 100 * psat(r.amb[iCold]), TS.engine.RSI[el], 0.04, el));
    return { rhIn, dpIn, surfaces: Object.values(surf), interstitial: inter, maxRH: Math.max(...rhIn), iCold };
  }

  function glaser(layers, tIn, pvIn, tOut, pvOut, rsi, rse, name) {
    const M = TS.MATERIALS, E = TS.engine;
    const ps = layers.map(l => E.layerProps(l, M)).reverse();          // room side first
    const R = [rsi].concat(ps.map(p => E.layerR(p))).concat([rse]), Rt = R.reduce((a, b) => a + b, 0);
    const sd = ps.map((p, i) => (MU[layers[layers.length - 1 - i].mat] || 10) * p.t), SDt = sd.reduce((a, b) => a + b, 0) || 1e-9;
    const pts = []; let rc = rsi, sc = 0;
    for (let i = 0; i <= ps.length; i++) {
      const T = tIn - (tIn - tOut) * rc / Rt, pv = pvIn - (pvIn - pvOut) * sc / SDt;
      pts.push({ at: i === 0 ? "room-side surface" : i === ps.length ? "outside surface" : `between ${ps[i - 1].name} and ${ps[i].name}`, T, pv, ps: psat(T) });
      if (i < ps.length) { rc += E.layerR(ps[i]); sc += sd[i]; }
    }
    /* condensation rate at each plane where the straight line exceeds
       saturation: g = delta0 [(pv_in - ps)/Sd_in - (ps - pv_out)/Sd_out],
       delta0 = 2e-10 kg/(m s Pa). Flag only if more than 1 g/m2 a day would
       collect: vapour-tight sheets (steel, PE) pass too little to matter. */
    const D0 = 2e-10; let sdc = 0;
    const flagged = [];
    pts.forEach((p, i) => {
      if (i > 0) sdc += sd[i - 1];
      if (p.pv <= p.ps || i === 0 || i === pts.length - 1) return;
      const g = D0 * ((pvIn - p.ps) / Math.max(sdc, 1e-6) - (p.ps - pvOut) / Math.max(SDt - sdc, 1e-6));
      const perDay = g * 86400 * 1000;
      if (perDay > 1) flagged.push(Object.assign({ gPerDay: perDay }, p));
    });
    return { element: name, risk: flagged.length > 0, where: flagged.map(p => `${p.at} (${p.gPerDay.toFixed(0)} g/m² a day)`), frost: flagged.some(p => p.T < 0), pts };
  }

  TS.moisture = { analyse, glaser, psat, dew, humRatio, MU };
  if (typeof module !== "undefined") module.exports = TS;
})(typeof window !== "undefined" ? window : globalThis);
