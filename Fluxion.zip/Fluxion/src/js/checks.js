/* Design checks. Each check states its basis; where a fix exists it is a
   function that returns a corrected copy of the design, so "Auto-correct"
   is always re-simulated, never just a label change.
   Bases used:
   - Snow: IS 875 (Part 4):1987 roof shape coefficient mu1 for pitched roofs
     (0.8 up to 30 deg, falling linearly to 0 at 60 deg; same form as
     EN 1991-1-3). Load s = mu1 * s0.
   - Frozen ground: mean annual air temperature (MAAT) as a screening
     indicator for permafrost; below about -2 C permafrost is likely, between
     -2 and 0 C patchy or seasonal frost. Screening only; confirm on site.
   - Air: indoor CO2 1000 ppm as the ventilation-adequacy benchmark and
     5000 ppm as the 8-hour occupational exposure limit.
   - Glazing: the window area that minimises fuel for this site, found by
     re-running the model, not a fixed code percentage.
   ECBC 2017 is not applied: it covers commercial buildings with a connected
   load of 100 kW or more, which a shelter is not. */
(function (g) {
  "use strict";
  const TS = g.TS;
  const clone = o => JSON.parse(JSON.stringify(o));
  const f1 = v => (+v).toFixed(1).replace(/^-/, "−");

  function snowMu(pitch) { return pitch <= 30 ? 0.8 : pitch >= 60 ? 0 : 0.8 * (60 - pitch) / 30; }
  function pitchFor(ratio) { return ratio >= 0.8 ? 0 : Math.min(60, Math.ceil(60 - 30 * ratio / 0.8)); }

  function annualMeanAir(site) {
    const rec = TS.SITES.find(s => s.id === site.id);
    if (!rec) return null;
    return rec.T2M.reduce((s, v) => s + v, 0) / 12 + 6.5 * (rec.cell.elev - site.alt) / 1000;
  }

  function quickFuel(d, site, ops) { return TS.engine.simulate(d, site, Object.assign({}, ops, { withSolarFraction: false })).summary.fuel_L; }

  function bestGlazing(d, site, ops) {
    const Af = d.L * d.W, steps = [0, 0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.35].map(f => +(f * Af).toFixed(2));
    const maxA = 0.85 * d.L * d.H;
    let best = null;
    for (const A of steps) { if (A > maxA) continue; const dd = clone(d); dd.win.front = A; const f = quickFuel(dd, site, ops); if (!best || f < best.fuel - 1e-6) best = { A, fuel: f }; }
    return best;
  }

  /* r: result of TS.airflow.simulate for the current design */
  function run(d, site, ops, r, fuelKey) {
    const out = [];
    const add = (o) => out.push(o);

    // 1. Snow load
    const sn = d.snow || {};
    const s0 = sn.depth > 0 ? sn.depth * (sn.density || 300) * 9.81 / 1000 : 0;
    if (s0 > 0) {
      const mu = snowMu(d.pitch || 0), s = mu * s0;
      if (sn.capacity > 0 && s > sn.capacity) {
        const p = pitchFor(sn.capacity / s0);
        add({ id: "snow", level: "fail", title: "Roof overloaded by snow",
          detail: `${f1(sn.depth)} m of snow at ${sn.density || 300} kg/m³ gives ${s0.toFixed(2)} kN/m² on the ground; on a ${d.pitch || 0}° roof that is ${s.toFixed(2)} kN/m² (IS 875 Part 4, μ = ${mu.toFixed(2)}), above the roof's rated ${sn.capacity} kN/m².` +
            (p < 60 ? ` A pitch of ${p}° sheds enough snow to stay within the rating.` : " No practical pitch is enough: strengthen the roof or plan snow clearing."),
          fix: p < 60 ? { label: `Set roof pitch to ${p}°`, apply: dd => { dd.pitch = p; return dd; } } : null });
      } else {
        add({ id: "snow", level: sn.capacity > 0 ? "ok" : "info", title: sn.capacity > 0 ? "Roof carries the design snow" : "Snow load on the roof",
          detail: `Design snow ${s.toFixed(2)} kN/m² on a ${d.pitch || 0}° roof (IS 875 Part 4, μ = ${mu.toFixed(2)}).` + (sn.capacity > 0 ? ` Rated ${sn.capacity} kN/m².` : " Enter the roof's rated load to check it.") });
      }
    }

    // 2. Frozen ground
    const maat = annualMeanAir(site);
    if (maat != null) {
      const floorW = r.heated.paths.reduce((s, p) => s + p.floor, 0) / r.N, flux = floorW / (d.L * d.W);
      if (maat <= 0 && d.floorMode !== "raised") {
        add({ id: "ground", level: maat <= -2 ? "fail" : "warn", title: maat <= -2 ? "Permafrost likely under the floor" : "Ground may stay frozen",
          detail: `Mean annual air temperature here is ${f1(maat)} °C. The heated floor sends about ${f1(Math.max(0, flux))} W/m² into the ground, which can thaw it and let the shelter settle unevenly. A raised floor on skids with a ventilated gap keeps the ground frozen; insulate the floor well, because it then faces outside air.`,
          fix: { label: "Raise the floor on skids", apply: dd => { dd.floorMode = "raised"; return dd; } } });
      } else if (maat <= 0) {
        add({ id: "ground", level: "ok", title: "Raised floor protects frozen ground", detail: `Mean annual air temperature ${f1(maat)} °C; the floor is raised, so the ground is not warmed.` });
      }
    }

    // 3. Glazing
    const bg = bestGlazing(d, site, ops), fuelNow = r.summary.fuel_L, Anow = d.win.front || 0;
    if (bg && fuelNow - bg.fuel > Math.max(0.1, 0.05 * fuelNow) && Math.abs(bg.A - Anow) > 0.2) {
      add({ id: "glazing", level: "warn", title: Anow > bg.A ? "Too much glass on the sunny side" : "Too little glass on the sunny side",
        detail: `With ${f1(Anow)} m² facing ${TS.engine.compass(d.orient)} the shelter needs ${f1(fuelNow)} fuel units a day; ${f1(bg.A)} m² needs ${f1(bg.fuel)}. Found by re-running the model for each window size at this site.`,
        fix: { label: `Set window to ${f1(bg.A)} m²`, apply: dd => { dd.win.front = bg.A; return dd; } } });
    } else add({ id: "glazing", level: "ok", title: "Window size is near the best for this site", detail: `Best found: ${bg ? f1(bg.A) : "–"} m² facing ${TS.engine.compass(d.orient)}.` });

    // 3b. Overheating on sunny days: the warmest indoor (operative) temperature against the upper
    //     edge of the ASHRAE 55 comfort zone, about 28 C. Found by the same simulation; the fix is the
    //     largest window that stays under it (re-simulated), else shading or daytime venting.
    const OVER = 28, peak = Math.max(...r.heated.op);
    if (peak > OVER) {
      let fixA = null;
      for (let k = 1; k <= 10 && Anow > 0; k++) {
        const A = +(Anow * (1 - k / 10)).toFixed(2), dd = clone(d); dd.win.front = A;
        const pk = Math.max(...TS.engine.simulate(dd, site, Object.assign({}, ops, { withSolarFraction: false })).heated.op);
        if (pk <= OVER) { fixA = A; break; }
      }
      add({ id: "overheat", level: "warn", title: "Too hot on sunny days",
        detail: `Inside reaches ${f1(peak)} °C around midday, above the ${OVER} °C upper edge of the comfort zone (ASHRAE 55). ` +
          `The glass lets in more sun than this well-insulated shelter can lose. ` +
          (fixA != null ? `${f1(fixA)} m² of glass keeps it under ${OVER} °C. ` : "") + "Otherwise open a high vent or shade the glass at midday.",
        fix: fixA != null ? { label: `Set window to ${f1(fixA)} m²`, apply: x => { x.win.front = fixA; return x; } } : null });
    } else add({ id: "overheat", level: "ok", title: "Not too hot on sunny days", detail: `Warmest inside ${f1(peak)} °C (comfort zone upper edge about ${OVER} °C, ASHRAE 55).` });

    // 4. Night shutter
    const glass = Object.values(d.win).reduce((s, v) => s + v, 0);
    if (glass > 0.5 && !d.shutter) {
      const dd = clone(d); dd.shutter = true; const f = quickFuel(dd, site, ops);
      if (fuelNow - f > 0.05) add({ id: "shutter", level: "info", title: "Cover the glass at night", detail: `An insulating shutter or blanket over ${f1(glass)} m² of glass from sunset to sunrise saves ${f1(fuelNow - f)} fuel units a day.`,
        fix: { label: "Add night shutter", apply: x => { x.shutter = true; return x; } } });
    }

    // 5. Air and CO2
    const co2 = r.co2;
    if (d.unflued) add({ id: "flue", level: "fail", title: "Heater without a flue", detail: `All combustion gases stay inside: CO₂ reaches ${Math.round(co2.max)} ppm, and carbon monoxide, which this model does not compute, is the real danger. Fit a flue to the outside.`,
      fix: { label: "Fit a flue", apply: x => { x.unflued = false; return x; } } });
    if (co2.max > 1000) {
      const nightIdx = r.night.map((n, i) => (n ? i : -1)).filter(i => i >= 0);
      const dT = median(nightIdx.map(i => r.heated.air[i] - r.amb[i])), w = median(nightIdx.map(i => r.wind[i]));
      const Gp = d.people * 0.0052 * 1.2 / r.net.rhoAir;
      const achNeed = (Gp / ((1000 - 420) / 1e6)) * 3.6 / TS.engine.geom(d).V;
      const A = TS.airflow.ventFor(d, achNeed, dT, w);
      add({ id: "air", level: co2.max > 5000 ? "fail" : "warn", title: co2.max > 5000 ? "Air goes stale overnight" : "Air is stuffy at night",
        detail: `CO₂ peaks at ${Math.round(co2.max)} ppm with ${d.people} people (air changes ${r.airflow.achMin.toFixed(1)} to ${r.airflow.achMax.toFixed(1)} an hour, driven by wind and the warm-inside stack effect). ` +
          (A > 0 ? `A low and a high vent of about ${A} cm² each keep it near 1000 ppm on a typical night.` : ""),
        fix: A > 0 ? { label: `Add two vents of ${A} cm²`, apply: x => { x.vents = Object.assign({}, x.vents, { low: A, high: A }); return x; } } : null });
    } else add({ id: "air", level: "ok", title: "Fresh air is enough", detail: `CO₂ stays under ${Math.round(co2.max)} ppm.` });

    // 6. Codes
    add({ id: "codes", level: "info", title: "Codes applied", detail: "Sphere (living space), WHO (indoor temperature, CO), IS 875 Part 4 (snow). ECBC 2017 is not applied: it covers commercial buildings with 100 kW or more connected load, not shelters." });
    return out;
  }
  function median(a) { if (!a.length) return 0; const s = a.slice().sort((x, y) => x - y); return s[Math.floor(s.length / 2)]; }

  TS.checks = { run, snowMu, pitchFor, annualMeanAir, bestGlazing };
  if (typeof module !== "undefined") module.exports = TS;
})(typeof window !== "undefined" ? window : globalThis);
