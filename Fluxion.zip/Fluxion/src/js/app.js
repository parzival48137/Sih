/* Fluxion UI. Holds one state object, re-runs the engine on every
   change (it takes a few milliseconds) and redraws the results. */
(function () {
  "use strict";
  const TS = window.TS, E = TS.engine, A = TS.ansys, C = TS.charts, M = TS.MATERIALS;
  const $ = id => document.getElementById(id);
  const MONTHS = ["January","February","March","April","May","June","July","August","September","October","November","December"];
  const STORE_KEY = "thermashelter.v1";
  const clone = o => JSON.parse(JSON.stringify(o));
  const f1 = v => (v == null || !isFinite(v) ? "–" : (+v).toFixed(1));
  const f2 = v => (v == null || !isFinite(v) ? "–" : (+v).toFixed(2));
  const f0 = v => (v == null || !isFinite(v) ? "–" : Math.round(v).toString());
  const minus = s => String(s).replace(/^-/, "−");
  const deg = v => minus(f1(v)) + " °C";
  const COL = { c0: "#8C2131", c1: "#2F6FA3", c2: "#D99A1E", c3: "#5B7F4A", c4: "#6D5A8E", c5: "#8A6B45", c6: "#3E8A8A", c7: "#4F6070", c8: "#B05A7A" };
  const legend = (items, dot) => items.map(([name, cls]) => `<span class="lg${dot ? " dot" : ""}" style="--c:${COL[cls]}">${name}</span>`).join("");
  const hh = h => String(Math.floor(((h % 24) + 24) % 24)).padStart(2, "0") + ":00";

  /* ------------------------------------------------------------ state */
  function defaultState() {
    const rec = TS.SITES[0];
    const d = clone(TS.PRESETS.prefab);
    Object.assign(d, { people: 4, wPerson: 75, equipW: 50, ach: 0.5, preset: "prefab" });
    return {
      site: { id: rec.id, month: 0, alt: rec.alt, range: 12, toff: 0, ghi: +rec.GHI[0].toFixed(2), wind: rec.WS[0], tground: 0, albedo: 0.6, horizon: [0,0,0,0,0,0,0,0] },
      hourly: null, hourlyName: "",
      design: d,
      ops: { setpoint: 14, eta: 0.6, burnMax: 0.7, kwhPerL: 9.58 },
      ui: { elem: "wall", flowRun: "heated", period: "night", from: 18, to: 8, flowView: "time", tab: "mission" },
      saved: [],
      ansys: { map: clone(A.DEFAULT_MAP), project: "D:/SIH26/Analysis/Shelter_General.wbpj", exportCsv: "D:/SIH26/Analysis/results/ts_results.csv", doe: "" },
    };
  }
  let S = defaultState();
  try { const raw = localStorage.getItem(STORE_KEY); if (raw) { const o = JSON.parse(raw); if (o && o.v === 1) S = Object.assign(defaultState(), o.state); } } catch (e) {}
  let saveT = 0;
  function persist() { clearTimeout(saveT); saveT = setTimeout(() => { try { localStorage.setItem(STORE_KEY, JSON.stringify({ v: 1, state: Object.assign({}, S, { hourly: null }) })); } catch (e) {} }, 400); }

  function siteRec() { return TS.SITES.find(s => s.id === S.site.id) || TS.SITES[0]; }
  function buildSite() {
    const s = S.site;
    const site = E.siteFrom(siteRec(), s.month, { alt: s.alt, range: s.range, Toffset: -s.toff, H: s.ghi, wind: s.wind,
      albedo: s.albedo, Tground: s.tground, horizon: s.horizon });
    if (S.hourly) site.hourly = S.hourly;
    return site;
  }
  function ops() {
    return { setpoint: +S.ops.setpoint, eta: S.ops.eta, burnMax: S.ops.burnMax, kwhPerL: S.ops.kwhPerL, band: [14, 20] };
  }

  /* --------------------------------------------------------- toast */
  let toastT = 0;
  function toast(msg) { const t = $("toast"); t.textContent = msg; t.hidden = false; clearTimeout(toastT); toastT = setTimeout(() => (t.hidden = true), 2600); }
  function download(name, text, type) {
    const cap = window.Capacitor && window.Capacitor.Plugins;
    if (cap && cap.Filesystem) {   // Android: WebView cannot save blob links
      cap.Filesystem.writeFile({ path: name, data: text, directory: "DOCUMENTS", encoding: "utf8" })
        .then(() => toast("Saved to Documents/" + name), e => toast("Could not save: " + e.message));
      return;
    }
    const blob = new Blob([text], { type: type || "text/plain" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = name;
    document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
    toast("Saved " + name);
  }
  function readFileBytes(file) { return file.arrayBuffer().then(b => A.decode(new Uint8Array(b))); }

  /* ------------------------------------------------------- tabs */
  function showTab(t) {
    S.ui.tab = t;
    document.querySelectorAll(".tabs button").forEach(b => b.setAttribute("aria-selected", String(b.dataset.tab === t)));
    document.querySelectorAll(".view").forEach(v => (v.hidden = v.dataset.view !== t));
    if (t === "field" && TS.fieldUI) TS.fieldUI.render();
    if (t === "live" && TS.liveUI) TS.liveUI.render();
    if (t === "compare") renderCompare();
    if (t === "ansys") { renderAnsys(); if (TS.bridgeUI) TS.bridgeUI.render(); }
    if (t === "site" && TS.uiplus) TS.uiplus.renderSite();
    if (t === "compare" && TS.uiplus) TS.uiplus.renderOptimise();
    if (t === "design") { renderLive(); if (TS.uiplus && R) TS.uiplus.afterRun(R); }
    if (t === "results") renderResults();
    persist();
  }
  document.querySelectorAll(".tabs button").forEach(b => b.addEventListener("click", () => showTab(b.dataset.tab)));
  document.querySelectorAll(".mobileswitch button").forEach(b => b.addEventListener("click", () => {
    document.querySelectorAll(".mobileswitch button").forEach(x => x.setAttribute("aria-selected", String(x === b)));
    document.querySelectorAll(".pane").forEach(p => p.dataset.hidden = String(p.dataset.pane !== b.dataset.pane));
    if (b.dataset.pane === "results") renderResults();
    window.scrollTo(0, 0);
  }));
  function segment(id, key, after) {
    const host = $(id);
    host.querySelectorAll("button").forEach(b => {
      b.setAttribute("aria-selected", String((b.dataset.v || b.dataset.el) === S.ui[key]));
      b.onclick = () => { S.ui[key] = b.dataset.v || b.dataset.el; segment(id, key, after); after(); persist(); };
    });
  }

  /* ------------------------------------------------------- inputs */
  function fillSelect(sel, opts, val) {
    sel.innerHTML = opts.map(([v, t]) => `<option value="${v}">${t}</option>`).join("");
    if (val != null) sel.value = String(val);
  }
  function bindNum(id, get, set) {
    const e = $(id); e.value = get();
    e.addEventListener("input", () => { const v = parseFloat(e.value); if (isFinite(v)) { set(v); changed(); } });
  }
  function syncInputs() {
    const s = S.site, d = S.design;
    // regions grouped by state
    const states = [...new Set(TS.SITES.map(x => x.state || "Saved sites"))];
    $("site").innerHTML = states.map(st => `<optgroup label="${st}">` + TS.SITES.filter(x => (x.state || "Saved sites") === st).map(x => `<option value="${x.id}">${x.region || x.name}</option>`).join("") + `</optgroup>`).join("");
    $("site").value = s.id;
    fillSelect($("month"), MONTHS.map((m, i) => [i, m]), s.month);
    for (const [id, v] of [["alt", s.alt], ["range", s.range], ["toff", s.toff], ["ghi", +(+s.ghi).toFixed(2)], ["wind", s.wind], ["tground", s.tground],
      ["L", d.L], ["W", d.W], ["H", d.H], ["orient", d.orient], ["abs", d.absorptance], ["smass", d.store.mass], ["pcmTm", d.store.Tm != null ? d.store.Tm : 18],
      ["people", d.people], ["wper", d.wPerson], ["equip", d.equipW], ["ach", d.ach], ["eta", Math.round(S.ops.eta * 100)],
      ["burn", S.ops.burnMax], ["kwhl", S.ops.kwhPerL]]) $(id).value = v;
    $("albedo").value = String(s.albedo);
    $("setpoint").value = String(S.ops.setpoint);
    $("berm").checked = !!d.berm; $("shutter").checked = !!d.shutter;
    fillSelect($("preset"), [["", "Current design"]].concat(Object.entries(TS.PRESETS).map(([k, p]) => [k, p.name])), "");
    fillSelect($("glazing"), Object.entries(TS.GLAZING).map(([k, gz]) => [k, `${gz.name} (U ${gz.U}, g ${gz.g})`]), d.glazing);
    fillSelect($("store"), Object.entries(TS.STORE).map(([k, x]) => [k, x.name]), d.store.type);
    renderHorizon(); renderWindows(); renderLayers();
    if (TS.uiplus) TS.uiplus.sync();
  }

  function wireInputs() {
    $("site").addEventListener("change", e => {
      const rec = TS.SITES.find(x => x.id === e.target.value);
      Object.assign(S.site, { id: rec.id, alt: rec.alt, ghi: +rec.GHI[S.site.month].toFixed(2), wind: rec.WS[S.site.month],
        range: rec.TMAX ? +(rec.TMAX[S.site.month] - rec.TMIN[S.site.month]).toFixed(1) : 12, horizon: rec.horizon ? rec.horizon.slice() : [0, 0, 0, 0, 0, 0, 0, 0] });
      syncInputs(); changed();
    });
    $("month").addEventListener("change", e => {
      S.site.month = +e.target.value; const rec = siteRec();
      S.site.ghi = +rec.GHI[S.site.month].toFixed(2); S.site.wind = rec.WS[S.site.month];
      $("ghi").value = S.site.ghi; $("wind").value = S.site.wind; changed();
    });
    bindNum("alt", () => S.site.alt, v => (S.site.alt = v));
    bindNum("range", () => S.site.range, v => (S.site.range = Math.max(0, v)));
    bindNum("toff", () => S.site.toff, v => (S.site.toff = v));
    bindNum("ghi", () => S.site.ghi, v => (S.site.ghi = Math.max(0, v)));
    bindNum("wind", () => S.site.wind, v => (S.site.wind = Math.max(0, v)));
    bindNum("tground", () => S.site.tground, v => (S.site.tground = v));
    $("albedo").addEventListener("change", e => { S.site.albedo = +e.target.value; changed(); });
    bindNum("L", () => S.design.L, v => (S.design.L = Math.max(1, v)));
    bindNum("W", () => S.design.W, v => (S.design.W = Math.max(1, v)));
    bindNum("H", () => S.design.H, v => (S.design.H = Math.max(1.8, v)));
    $("orient").addEventListener("input", e => { S.design.orient = +e.target.value; renderWindows(); changed(); });
    $("berm").addEventListener("change", e => { S.design.berm = e.target.checked; changed(); });
    $("shutter").addEventListener("change", e => { S.design.shutter = e.target.checked; changed(); });
    $("abs").addEventListener("input", e => { S.design.absorptance = +e.target.value; changed(); });
    $("glazing").addEventListener("change", e => { S.design.glazing = e.target.value; changed(); });
    $("store").addEventListener("change", e => { S.design.store.type = e.target.value; if (e.target.value !== "none" && !S.design.store.mass) { S.design.store.mass = 300; $("smass").value = 300; } changed(); });
    bindNum("smass", () => S.design.store.mass, v => (S.design.store.mass = Math.max(0, v)));
    bindNum("pcmTm", () => (S.design.store.Tm != null ? S.design.store.Tm : 18), v => (S.design.store.Tm = v));
    bindNum("people", () => S.design.people, v => (S.design.people = Math.max(0, Math.round(v))));
    bindNum("wper", () => S.design.wPerson, v => (S.design.wPerson = Math.max(0, v)));
    bindNum("equip", () => S.design.equipW, v => (S.design.equipW = Math.max(0, v)));
    bindNum("ach", () => S.design.ach, v => (S.design.ach = Math.max(0.05, v)));
    $("setpoint").addEventListener("change", e => { S.ops.setpoint = +e.target.value; changed(); });
    bindNum("eta", () => Math.round(S.ops.eta * 100), v => (S.ops.eta = Math.min(1, Math.max(0.1, v / 100))));
    bindNum("burn", () => S.ops.burnMax, v => (S.ops.burnMax = Math.max(0.01, v)));
    bindNum("kwhl", () => S.ops.kwhPerL, v => (S.ops.kwhPerL = Math.max(1, v)));
    $("preset").addEventListener("change", e => {
      if (!e.target.value) return;
      const p = clone(TS.PRESETS[e.target.value]);
      const keep = { people: S.design.people, wPerson: S.design.wPerson, equipW: S.design.equipW, ach: S.design.ach };
      S.design = Object.assign(p, keep, { preset: e.target.value });
      syncInputs(); changed(); toast("Loaded " + p.name);
    });
    $("wxfile").addEventListener("change", async e => {
      const f = e.target.files[0]; if (!f) return;
      try {
        const rows = A.parseCSV(await readFileBytes(f));
        const head = rows[0].map(h => h.trim().toLowerCase());
        const iT = head.findIndex(h => /^t\b|temp/.test(h)), iG = head.findIndex(h => /ghi|solar|irr/.test(h)), iW = head.findIndex(h => /wind|ws/.test(h));
        if (iT < 0 || iG < 0) throw new Error("Need columns named T (or temperature) and GHI (or solar).");
        const data = rows.slice(1).map(r => ({ T: parseFloat(r[iT]), GHI: parseFloat(r[iG]), ws: iW >= 0 ? parseFloat(r[iW]) : undefined }))
          .filter(r => isFinite(r.T) && isFinite(r.GHI));
        const n = Math.floor(data.length / 24) * 24;
        if (n < 24) throw new Error("Need at least 24 hourly rows.");
        S.hourly = data.slice(0, n); S.hourlyName = f.name;
        $("wxstatus").innerHTML = `Using <b>${f.name}</b>: ${n / 24} day(s) of hourly data. <button type="button" class="ghost" id="wxclear">Back to design day</button>`;
        $("wxclear").onclick = () => { S.hourly = null; $("wxstatus").textContent = ""; $("wxfile").value = ""; changed(); };
        changed();
      } catch (err) { $("wxstatus").textContent = "Could not use that file: " + err.message; }
    });
    $("addLayer").addEventListener("click", () => { S.design[S.ui.elem].push({ mat: "rockwool", t: 0.05 }); renderLayers(); changed(); });
    segment("elemTabs", "elem", () => renderLayers());
  }

  function renderHorizon() {
    const names = S.site.horizon.length === 16 ? ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"] : ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];
    $("horizon").innerHTML = names.map((n, i) => `<label><span>${n} <small>°</small></span><input type="number" min="0" max="60" step="1" data-i="${i}" value="${S.site.horizon[i]}"></label>`).join("");
    $("horizon").querySelectorAll("input").forEach(inp => inp.addEventListener("input", () => {
      const v = parseFloat(inp.value); if (isFinite(v)) { S.site.horizon[+inp.dataset.i] = Math.max(0, Math.min(60, v)); changed(); }
    }));
  }
  function renderWindows() {
    const o = S.design.orient, keys = [["front", 0], ["right", 90], ["back", 180], ["left", 270]];
    $("winRow").innerHTML = keys.map(([k, off]) => `<label><span>Facing ${E.compass(o + off)} <small>m²</small></span><input type="number" min="0" step="0.1" data-k="${k}" value="${S.design.win[k] || 0}"></label>`).join("");
    $("winRow").querySelectorAll("input").forEach(inp => inp.addEventListener("input", () => {
      const v = parseFloat(inp.value); if (isFinite(v)) { S.design.win[inp.dataset.k] = Math.max(0, v); changed(); }
    }));
    $("orientOut").textContent = `${E.compass(o)} (${o}° from north)`;
  }

  const FILL = { metal: "#7F8C97", ins: "#F1D48E", gap: "#FFFFFF", mass: "#C49E72", board: "#D9BE92" };
  function matFill(mat) { if (mat === "stone") return "#A6A097"; if (mat === "concrete") return "#B4B8BA"; return FILL[(M[mat] || M.custom).cls] || "#ccc"; }
  function renderLayers() {
    const key = S.ui.elem, layers = S.design[key];
    const host = $("layers");
    const opts = Object.entries(M).map(([k, m]) => `<option value="${k}">${m.name}</option>`).join("");
    host.innerHTML = layers.map((l, i) => {
      const p = E.layerProps(l, M);
      const gap = p.cls === "gap";
      return `<div class="layer" data-i="${i}">
        <span class="sw" style="background:${matFill(l.mat)}"></span>
        <select aria-label="Layer ${i + 1} material" data-f="mat">${opts}</select>
        <input type="number" aria-label="Layer ${i + 1} thickness in mm" data-f="t" min="0.1" step="${l.t < 0.005 ? 0.1 : 5}" value="${+(l.t * 1000).toFixed(1)}">
        <span class="tools"><button type="button" class="iconbtn" data-a="del" title="Remove layer" aria-label="Remove layer ${i + 1}">×</button></span>
        <div class="props">
          <label><span>k <small>W/m·K</small></span><input type="number" data-f="k" step="0.001" value="${gap ? "" : p.k}" ${gap ? "disabled placeholder=\"R 0.18\"" : ""}></label>
          <label><span>ρ <small>kg/m³</small></span><input type="number" data-f="rho" step="1" value="${p.rho}"></label>
          <label><span>c <small>J/kg·K</small></span><input type="number" data-f="c" step="10" value="${p.c}"></label>
        </div></div>`;
    }).join("");
    host.querySelectorAll(".layer").forEach(row => {
      const i = +row.dataset.i, l = layers[i];
      row.querySelector("[data-f=mat]").value = l.mat;
      row.querySelector("[data-f=mat]").addEventListener("change", e => { layers[i] = { mat: e.target.value, t: l.t }; renderLayers(); changed(); });
      row.querySelector("[data-f=t]").addEventListener("input", e => { const v = parseFloat(e.target.value); if (v > 0) { l.t = v / 1000; drawSection(); changed(); } });
      for (const f of ["k", "rho", "c"]) row.querySelector(`[data-f=${f}]`).addEventListener("input", e => {
        const v = parseFloat(e.target.value); if (v > 0) { l[f] = v; drawSection(); changed(); }
      });
      row.querySelector("[data-a=del]").addEventListener("click", () => { if (layers.length > 1) { layers.splice(i, 1); renderLayers(); changed(); } else toast("An element needs at least one layer."); });
    });
    drawSection();
  }
  function drawSection() {
    const key = S.ui.elem, layers = S.design[key], svg = $("section");
    const W = svg.clientWidth || 360, H = 86, x0 = 52, x1 = W - 40;
    svg.setAttribute("viewBox", `0 0 ${W} ${H}`);
    const tot = layers.reduce((s, l) => s + l.t, 0);
    const minW = 5, span = x1 - x0, raw = layers.map(l => Math.max(minW, l.t / tot * span));
    const k = span / raw.reduce((s, v) => s + v, 0);
    let x = x0, out = `<defs><pattern id="hatchIns" width="8" height="8" patternUnits="userSpaceOnUse"><path d="M0 4 Q2 0 4 4 T8 4" fill="none" stroke="#B88A2E" stroke-width="1"/></pattern>
      <pattern id="hatchMass" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="6" stroke="#8D6B45" stroke-width="1"/></pattern></defs>`;
    layers.forEach(l => {
      const w = raw.shift() * k, cls = (M[l.mat] || M.custom).cls;
      out += `<rect class="lyr" x="${x}" y="14" width="${w}" height="50" fill="${matFill(l.mat)}"/>`;
      if (cls === "ins") out += `<rect x="${x}" y="14" width="${w}" height="50" fill="url(#hatchIns)"/>`;
      if (cls === "mass") out += `<rect x="${x}" y="14" width="${w}" height="50" fill="url(#hatchMass)" opacity=".5"/>`;
      x += w;
    });
    const lab = key === "floor" ? ["ground", "room"] : ["outside", "room"];
    out += `<text class="side" x="${x0 - 6}" y="43" text-anchor="end">${lab[0]}</text><text class="side" x="${x1 + 6}" y="43">${lab[1]}</text>`;
    out += `<text class="dim" x="${(x0 + x1) / 2}" y="80">${(tot * 1000).toFixed(tot < 0.01 ? 1 : 0)} mm total</text>`;
    svg.innerHTML = out;
    const R = E.constructionR(layers, M), rsi = E.RSI[key], U = 1 / (rsi + R + (key === "floor" ? 0.5 : 0.04));
    const kap = E.arealCapacity(layers, M);
    $("uval").innerHTML = `U <b>${f2(U)}</b> W/m²·K, heat storage <b>${f0(kap / 1000)}</b> kJ/m²·K`;
  }

  function drawPlan(res) {
    const d = S.design, svg = $("plan");
    const site = buildSite();
    const toXY = (az, r) => [r * Math.sin(az * Math.PI / 180), -r * Math.cos(az * Math.PI / 180)];
    let s = `<circle class="ring" r="100"/><circle class="ring" r="66" stroke-dasharray="2 4"/>`;
    for (let a = 0; a < 360; a += 30) { const [x1, y1] = toXY(a, 96), [x2, y2] = toXY(a, 100); s += `<line class="tick" x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}"/>`; }
    [["N", 0], ["E", 90], ["S", 180], ["W", 270]].forEach(([n, a]) => { const [x, y] = toXY(a, 111); s += `<text class="cardinal ${n === "N" ? "n" : ""}" x="${x}" y="${y}">${n}</text>`; });
    // sun path for the design day (radius = zenith angle)
    let p = "", first = null, noon = null, best = -1;
    for (let t = 0; t <= 24; t += 0.25) {
      const sp = E.sunPos(site.lat, site.lon, site.doy, t, 82.5);
      if (sp.alt <= 0) continue;
      const [x, y] = toXY(sp.az, sp.zen / 90 * 100);
      p += (p ? "L" : "M") + x.toFixed(1) + "," + y.toFixed(1);
      if (!first) first = [x, y];
      if (sp.alt > best) { best = sp.alt; noon = [x, y]; }
    }
    if (p) s += `<path class="sunpath" d="${p}"/>`;
    if (noon) s += `<circle class="sunrise" cx="${noon[0]}" cy="${noon[1]}" r="5"/>`;
    // shelter footprint
    const sc = 72 / Math.max(d.L, d.W);
    const fac = [{ k: "front", az: d.orient, w: d.L, dep: d.W }, { k: "right", az: d.orient + 90, w: d.W, dep: d.L },
      { k: "back", az: d.orient + 180, w: d.L, dep: d.W }, { k: "left", az: d.orient + 270, w: d.W, dep: d.L }];
    const corner = (f) => { const [nx, ny] = toXY(f.az, 1), tx = -ny, ty = nx, c = [nx * f.dep / 2 * sc, ny * f.dep / 2 * sc];
      return [[c[0] - tx * f.w / 2 * sc, c[1] - ty * f.w / 2 * sc], [c[0] + tx * f.w / 2 * sc, c[1] + ty * f.w / 2 * sc], c, [tx, ty]]; };
    const pts = fac.map(f => corner(f)[0]);
    s += `<polygon class="hut" points="${pts.map(q => q.map(v => v.toFixed(1)).join(",")).join(" ")}"/>`;
    for (const f of fac) {
      const [a, b, c, t] = corner(f);
      if (d.berm && f.k === "back") s += `<line class="bermline" x1="${a[0]}" y1="${a[1]}" x2="${b[0]}" y2="${b[1]}"/>`;
      const Aw = d.win[f.k] || 0;
      if (Aw > 0) {
        const ww = Math.min(f.w * 0.9, Aw / Math.min(1.2, 0.8 * d.H)) * sc / 2;
        s += `<line class="win" x1="${c[0] - t[0] * ww}" y1="${c[1] - t[1] * ww}" x2="${c[0] + t[0] * ww}" y2="${c[1] + t[1] * ww}"/>`;
      }
      if (f.k === "front") { const [nx, ny] = toXY(f.az, 1); s += `<circle class="front" cx="${c[0] + nx * 9}" cy="${c[1] + ny * 9}" r="3.5"/>`; }
    }
    svg.innerHTML = s;
  }

  /* -------------------------------------------------------- results */
  let R = null, firstRender = true;
  let runT = 0;
  function changed() { clearTimeout(runT); runT = setTimeout(run, 90); persist(); }
  function run() {
    const t0 = performance.now();
    try { R = TS.airflow.simulate(S.design, buildSite(), ops(), "kerosene"); }
    catch (e) { $("verdict").textContent = "The model could not run with these inputs: " + e.message; return; }
    const ms = performance.now() - t0;
    $("runInfo").textContent = `Model run: ${R.N} h simulated, airflow coupled in ${R.airflow.iterations} passes, ${ms.toFixed(0)} ms. Energy balance closes to ${Math.abs(R.passive.balanceErrPct).toExponential(0)} %.`;
    renderSiteChip(); drawPlan(R);
    if (S.ui.tab === "design") { renderLive(); if (TS.uiplus) TS.uiplus.afterRun(R); }
    if (S.ui.tab === "results") renderResults();
    if (S.ui.tab === "compare") renderCompare();
    if (S.ui.tab === "ansys") renderAnsys();
  }
  function renderSiteChip() {
    const st = buildSite();
    if ($("sitechip")) $("sitechip").textContent = S.hourly ? `${siteRec().name}, measured data (${S.hourlyName})` : `${siteRec().name}, ${MONTHS[S.site.month]}, ${st.alt} m`;
    $("sitenote").innerHTML = S.hourly ? "Design-day settings are ignored while measured data is loaded." :
      `Design day: ${deg(st.Tmin)} to ${deg(st.Tmax)}. NASA POWER monthly mean ${deg(siteRec().T2M[S.site.month])} for the grid cell at ${siteRec().cell.elev} m, moved to ${st.alt} m at 6.5 K/km (${st.lapse >= 0 ? "+" : "−"}${f1(Math.abs(st.lapse))} K).`;
  }
  function xAxis(N) {
    const x = Array.from({ length: N }, (_, i) => i + 0.5);
    const step = N <= 24 ? 3 : N <= 72 ? 6 : N <= 240 ? 24 : 48;
    const ticks = []; for (let v = 0; v <= N; v += step) ticks.push(v);
    const fmt = (v, tip) => N <= 24 ? (tip ? `${hh(v - 0.5)} to ${hh(v + 0.5)}` : hh(v)) : `Day ${Math.floor(v / 24) + 1} ${hh(Math.floor(v) % 24)}`;
    return { x, ticks, fmt };
  }
  function nightBands(R) {
    const out = []; let start = null;
    R.night.forEach((n, i) => { if (n && start == null) start = i; if (!n && start != null) { out.push({ x0: start, x1: i, cls: "nightband" }); start = null; } });
    if (start != null) out.push({ x0: start, x1: R.N, cls: "nightband" });
    return out;
  }

  /* the three outputs as numbers (Results page boxes, report and Design live line share this) */
  function outputs(r) {
    r = r || R; if (!r) return null;
    const op = r.passive.op, ni = r.night.map((n, i) => (n ? i : -1)).filter(i => i >= 0);
    const iMin = ni.reduce((b, i) => (op[i] < op[b] ? i : b), ni[0] || 0), iMax = op.indexOf(Math.max(...op));
    const keys = Object.keys(r.heated.paths[0]), tot = {};
    keys.forEach(k => (tot[k] = r.heated.paths.reduce((a, p) => a + p[k], 0) / 1000 / r.days));
    const loss = keys.reduce((a, k) => a + Math.max(0, tot[k]), 0), dT = r.heated.air.reduce((a, t, i) => a + t - r.amb[i], 0) / r.N;
    return { tMin: op[iMin], hMin: iMin % 24, tOutMin: r.amb[iMin], tMax: op[iMax], hMax: iMax % 24, tHeatMin: Math.min(...r.heated.op),
      solar: r.solar.transmitted_kWh + r.solar.opaqueIn_kWh, solarWin: r.solar.transmitted_kWh, solarWall: r.solar.opaqueIn_kWh,
      loss, dT, UA: loss * 1000 / 24 / Math.max(dT, 0.1), fuel: r.summary.fuel_L };
  }
  // one line of live numbers on the Design page, updated as inputs change
  function renderLive() {
    const el = $("designLive"); if (!el || !R) return;
    const o = outputs(), st = status(), u = S.design.units || 1;
    el.innerHTML = `<span>Coldest inside, no heating <b>${minus(f1(o.tMin))} °C</b></span><span>Sun into the room <b>${f1(o.solar)} kWh/day</b></span>` +
      `<span>Kerosene <b>${f2(o.fuel * u)} L/day</b></span><span class="st ${st.level}">${st.label}</span>`;
  }
  function renderResults() {
    if (!R) return;
    const su = R.summary, ax = xAxis(R.N), set = +S.ops.setpoint, o = outputs(), u = S.design.units || 1;
    const ms = TS.mission && TS.mission.state ? TS.mission.state() : null, dur = ms && ms.dur;
    const box = (n, title, big, lines) => `<div class="obox"><span class="on">${n}</span><h3>${title}</h3><b>${big}</b>${lines.map(l => `<p>${l}</p>`).join("")}</div>`;
    $("out3").innerHTML =
      box(1, "Inside temperature", `${minus(f1(o.tMin))} to ${minus(f1(o.tMax))} °C`, [`without heating (coldest ${hh(o.hMin)}, outside ${minus(f1(o.tOutMin))} °C)`, `with the heater: never below <b>${minus(f1(o.tHeatMin))} °C</b>`]) +
      box(2, "Heat from the sun", `${f1(o.solar)} kWh/day`, [`windows ${f1(o.solarWin)} kWh`, `walls and roof ${f1(o.solarWall)} kWh`]) +
      box(3, "Heat flow", `${f1(o.loss)} kWh/day`, [`lost at ${f1(o.dT)} °C average inside–outside difference`, `<b>${Math.round(o.UA)} W</b> for each °C of difference`]);
    const runs = TS.bridgeUI ? TS.bridgeUI.history() : [], last = runs.find(x => !x.mock) || runs[0];
    $("outFuel").innerHTML =
      `<div class="obox fuel"><h3>Kerosene</h3><b>${f2(o.fuel * u)} L/day</b><p>${u > 1 ? `${u} shelters, ${f2(o.fuel)} L each` : "one shelter"}</p>` +
      (dur ? `<p>${dur.use === "permanent" ? `${Math.round(dur.year)} L a year · ${Math.round(dur.total).toLocaleString("en-IN")} L in ${dur.years} years` : `${Math.round(dur.total)} L in ${dur.days} days`}</p>` : "") + `</div>` +
      `<div class="obox fuel"><h3>Check in ANSYS</h3>` + (last ? `<b>${minus(f1(last.aMin))} °C</b><p>ANSYS coldest air · app ${minus(f1(last.pMin))} °C</p><p>${last.t}${last.mock ? " (practice)" : ""}</p>` : `<b>–</b><p>No ANSYS run yet (step 4)</p>`) + `</div>`;

    const host = $("nightChart");
    host.classList.toggle("intro", firstRender);
    C.line(host, {
      x: ax.x, xTicks: ax.ticks, xFmt: ax.fmt, xEndPad: 0.5, height: 280, unit: " °C", label: "Inside and outside temperature over the day",
      vbands: nightBands(R).map(b => ({ x0: b.x0, x1: b.x1, cls: "nightband" })),
      hbands: [{ y0: 14, y1: 20, cls: "band", label: "Comfort 14 to 20 °C", fit: true }],
      fillBetween: [0, 1],
      series: [
        { name: "Outside", y: R.amb, cls: "amb", width: 2 },
        { name: "Inside, no heating", y: R.passive.op, cls: "pas", width: 3 },
      ],
      yLabel: "°C", tipDigits: 1,
    });
    firstRender = false;
    $("nightLegend").innerHTML = `<span class="l-amb">Outside</span><span class="l-pas">Inside, no heating</span><span class="l-band">Comfort 14 to 20 °C</span><span class="l-night">Night</span>`;

    $("readout1").innerHTML = rows([
      ["Coldest inside, no heating", minus(f1(o.tMin)), "°C"],
      ["Warmest inside, no heating", minus(f1(o.tMax)), "°C"],
      ["Kerosene to keep " + set + " °C", f2(su.fuel_L * u), "L/day"],
      ["Heater running time", f1(su.heaterHours), "h/day"],
      ["Heating supplied by the sun", R.solar.fraction == null ? "–" : f0(R.solar.fraction * 100), "%"],
    ]);

    renderSolar(); renderFlow(); renderEnv();
  }
  function rows(list) {
    return list.map(([k, v, u, n, cls]) => `<tr><td>${k}</td><td class="v ${cls || ""}">${v}<small>${u}</small></td><td class="n">${n || ""}</td></tr>`).join("");
  }

  function renderSolar() {
    const sol = R.solar, days = R.days;
    const ghiDay = R.ghi.reduce((s, v) => s + v, 0) / 1000 / days;
    $("solarLede").innerHTML = minus(`The sun puts <b>${f1(sol.transmitted_kWh)} kWh/day</b> into the room through the glass and <b>${f1(sol.opaqueIn_kWh)} kWh/day</b> through sunlit walls and roof. ` +
      `Solar on the ground is ${f2(ghiDay)} kWh/m²·day${R.meta.KT ? `, a clearness index of ${f2(R.meta.KT)}` : ""}.`);
    const fr = sol.facades.map(f => `<tr><td>${f.label} wall${f.bermed ? " (bermed)" : ""}${f.Aw > 0 ? `, ${f1(f.Aw)} m² glass` : ""}</td><td class="v">${f2(f.incidentPerM2_kWh)}</td><td class="v">${f.Aw > 0 ? f2(f.transmitted_kWh) : "–"}</td><td class="v">${f2(f.opaqueIn_kWh)}</td></tr>`).join("");
    $("solarTable").innerHTML = `<tr><th>Surface</th><th>Sun on surface<br>kWh/m²·day</th><th>Through glass<br>kWh/day</th><th>Through wall<br>kWh/day</th></tr>` + fr +
      `<tr><td>Roof</td><td class="v">${f2(sol.roofIncident_kWh / R.net.Af)}</td><td class="v">–</td><td class="v">${f2(sol.roofIn_kWh)}</td></tr>` +
      `<tr><td><b>Total into the room</b></td><td></td><td class="v">${f2(sol.transmitted_kWh)}</td><td class="v">${f2(sol.opaqueIn_kWh)}</td></tr>`;
    const ax = xAxis(R.N), cls = ["c0", "c3", "c1", "c4"];
    const series = sol.facades.map((f, i) => ({ name: `${f.label} wall`, y: R.facIrr.map(h => h[f.key]), cls: cls[i], width: 1.8 }));
    series.push({ name: "Roof", y: R.ghi.slice(), cls: "c2", width: 2.4 });
    C.line($("solarChart"), { x: ax.x, xTicks: ax.ticks, xFmt: ax.fmt, xEndPad: 0.5, height: 230, unit: " W/m²", tipDigits: 0, yPad: 10,
      series, yLabel: "Sun on each surface, W/m²", label: "Sun on each surface over the day" });
    $("solarLegend").innerHTML = legend(series.map(s => [s.name, s.cls]));
  }

  function periodIdx() {
    const N = R.N, p = S.ui.period;
    const all = Array.from({ length: N }, (_, i) => i);
    if (p === "day") return { idx: all, name: R.N > 24 ? "the whole record" : "the whole day" };
    if (p === "night") return { idx: nightOrder(true), name: "the night" };
    if (p === "sun") return { idx: all.filter(i => !R.night[i]), name: "daylight hours" };
    const a = Math.max(0, Math.min(23, S.ui.from | 0)), b = Math.max(1, Math.min(24, S.ui.to | 0));
    const idx = [];
    for (let d = 0; d < R.days; d++) {
      if (b > a) for (let h = a; h < b; h++) idx.push(d * 24 + h);
      else { for (let h = a; h < 24; h++) idx.push(d * 24 + h); for (let h = 0; h < b; h++) idx.push(((d + 1) % R.days) * 24 + h); }
    }
    return { idx, name: `${hh(a)} to ${hh(b)}` };
  }
  function nightOrder() {
    // night as one continuous stretch: evening hours then the following morning
    const ev = [], mo = [];
    R.night.forEach((n, i) => { if (n) (i % 24 >= 12 ? ev : mo).push(i); });
    return R.N <= 24 ? ev.concat(mo) : R.night.map((n, i) => (n ? i : -1)).filter(i => i >= 0);
  }
  const PATH_NAMES = () => {
    const m = { roof: "Roof", floor: "Floor", glazing: "Windows", vent: "Air leakage and ventilation", trombe: "Trombe wall" };
    R.solar.facades.forEach(f => (m["wall_" + f.key] = `${f.label} wall${f.bermed ? " (bermed)" : ""}`));
    return m;
  };
  function renderFlow() {
    S.ui.flowView = "time";   // heat flow is shown over time only
    segment("flowRun", "flowRun", renderFlow);
    segment("flowView", "flowView", renderFlow);
    $("period").value = S.ui.period;
    $("customHours").hidden = S.ui.period !== "custom";
    $("pFrom").value = S.ui.from; $("pTo").value = S.ui.to;
    const run = S.ui.flowRun === "passive" ? R.passive : R.heated;
    const { idx, name } = periodIdx();
    if (!idx.length) { $("flowLede").textContent = "No hours fall in that period."; $("flowBars").innerHTML = ""; $("flowChart").innerHTML = ""; return; }
    const names = PATH_NAMES(), keys = Object.keys(run.paths[0]);
    const tot = {}; keys.forEach(k => (tot[k] = 0));
    idx.forEach(i => keys.forEach(k => (tot[k] += run.paths[i][k] / 1000)));
    const items = keys.map(k => ({ label: names[k] || k, value: tot[k] / R.days * (R.N > 24 ? 1 : 1), k })).sort((a, b) => b.value - a.value);
    const loss = items.reduce((s, x) => s + Math.max(0, x.value), 0);
    const dT = idx.reduce((s, i) => s + (run.air[i] - R.amb[i]), 0) / idx.length;
    const top = items[0];
    const per = R.N > 24 ? " over the record" : "";
    $("flowLede").innerHTML = minus(`Over ${name}${per} the shelter loses <b>${f1(loss)} kWh</b> with the inside on average <b>${f1(dT)} K</b> warmer than outside. ` +
      `The largest path is ${top.label.toLowerCase()} at ${f0(100 * top.value / Math.max(loss, 1e-9))} %.` +
      (items.some(x => x.value < 0) ? " Negative values are heat gained, for example from ground warmer than the room." : ""));
    C.bars($("flowBars"), { items: items.map(x => ({ label: x.label, value: x.value, cls: x.value < 0 ? "gain" : x.k === "vent" ? "cool" : x.k === "glazing" ? "mute" : "" })), unit: " kWh", digits: 2, labelW: 190 });

    const order = items.map(x => x.k);
    if (S.ui.flowView === "time") {
      const N = idx.length, x = idx.map((_, j) => j + 0.5);
      const startH = idx[0] % 24;
      const step = N <= 12 ? 1 : N <= 24 ? 3 : 6, ticks = [];
      for (let v = 0; v <= N; v += step) ticks.push(v);
      C.line($("flowChart"), {
        x, xTicks: ticks, xEndPad: 0.5, xFmt: (v, tip) => (tip ? `${hh(idx[Math.min(N - 1, Math.floor(v))] % 24)} to ${hh(idx[Math.min(N - 1, Math.floor(v))] % 24 + 1)}` : hh(startH + v)),
        height: 250, unit: " W", tipDigits: 0, yPad: 10, yLabel: "W out of the room",
        series: order.map((k, j) => ({ name: names[k], y: idx.map(i => run.paths[i][k]), cls: "c" + j, width: 1.8 })),
        label: "Heat flow by path over the selected period",
      });
    } else {
      C.scatter($("flowChart"), {
        height: 260, xLabel: "Inside air minus outside air (K)", yLabel: "W out",
        sets: order.map((k, j) => ({ name: names[k], cls: "c" + j, pts: idx.map(i => [run.air[i] - R.amb[i], run.paths[i][k]]) })),
      });
    }
    $("flowLegend").innerHTML = legend(order.map((k, j) => [names[k], "c" + j]), S.ui.flowView !== "time");
  }
  $("period").addEventListener("change", e => { S.ui.period = e.target.value; renderFlow(); persist(); });
  $("pFrom").addEventListener("input", e => { S.ui.from = +e.target.value; renderFlow(); persist(); });
  $("pTo").addEventListener("input", e => { S.ui.to = +e.target.value; renderFlow(); persist(); });

  function renderEnv() {
    const n = R.net, gz = TS.GLAZING[S.design.glazing];
    const nightSky = Math.min(...R.sky);
    $("readoutEnv").innerHTML = rows([
      ["Wall U-value", f2(n.U.wall), "W/m²·K", `R of layers ${f2(n.R.wall)} m²·K/W`],
      ["Roof U-value", f2(n.U.roof), "W/m²·K", `R of layers ${f2(n.R.roof)} m²·K/W`],
      ["Floor U-value", f2(n.U.floor), "W/m²·K", "Includes 0.5 m²·K/W to the ground below"],
      ["Window U-value", f2(gz.U), "W/m²·K", S.design.shutter ? "Shutter adds 0.4 m²·K/W from sunset to sunrise" : "No night shutter"],
      ["Heat stored per kelvin", f1(n.Cm / 1e6), "MJ/K", `Effective mass area ${f0(n.Am)} m² (ISO 13790 10 cm rule)`],
      ["Time constant", f0(n.tauH), "h", "How long the room takes to lose about two thirds of a temperature difference"],
      ["Air density at site", f2(n.rhoAir), "kg/m³", `${f1(R.meta.P / 1000)} kPa; ventilation carries less heat per air change than at sea level`],
      ["Coldest sky temperature", minus(f1(nightSky)), "°C", "Berdahl–Martin clear sky with altitude correction; drives night loss from the roof"],
      ["Energy balance check", Math.abs(R.heated.balanceErrPct).toExponential(0), "%", "Gains minus losses minus stored heat, over the simulated span"],
    ]);
  }

  $("exportHourly").addEventListener("click", () => {
    const names = PATH_NAMES(), keys = Object.keys(R.heated.paths[0]);
    const head = ["hour", "T_out_C", "T_sky_C", "GHI_W_m2", "T_op_passive_C", "T_air_passive_C", "T_op_heated_C", "heater_W"].concat(keys.map(k => "Q_" + k + "_heated_W"));
    const lines = [head.join(",")];
    for (let i = 0; i < R.N; i++) lines.push([i, R.amb[i], R.sky[i], R.ghi[i], R.passive.op[i], R.passive.air[i], R.heated.op[i], R.heated.phi[i]].concat(keys.map(k => R.heated.paths[i][k])).map(v => typeof v === "number" ? +v.toFixed(3) : v).join(","));
    download("fluxion_hourly.csv", lines.join("\r\n"), "text/csv");
  });
  $("exportBC").addEventListener("click", () => {
    if (!R) return toast("Run the model first.");
    const fac = R.solar.facades;
    const head = ["time_s", "T_out_C", "T_sky_C", "GHI_roof_W_m2"].concat(fac.map(f => `G_${f.key}_${f.label}_W_m2`));
    const lines = ["# Fluxion boundary tables for ANSYS (one row per hour, value at the hour midpoint)",
      `# Site ${siteRec().name}, ${MONTHS[S.site.month]}, ${S.site.alt} m, front facade ${S.design.orient} deg from north, albedo ${S.site.albedo}`, head.join(",")];
    for (let i = 0; i < R.N; i++) lines.push([i * 3600 + 1800, R.amb[i], R.sky[i], R.ghi[i]].concat(fac.map(f => R.facIrr[i][f.key])).map(v => typeof v === "number" ? +v.toFixed(2) : v).join(","));
    download("fluxion_ansys_bc.csv", lines.join("\r\n"), "text/csv");
  });

  /* ------------------------------------------------------- compare */
  $("saveDesign").addEventListener("click", () => {
    const name = $("saveName").value.trim() || `Design ${S.saved.length + 1}`;
    S.saved.push({ name, design: clone(S.design) }); $("saveName").value = ""; persist(); renderCompare(); toast("Saved " + name);
  });
  function quick(d) { return E.simulate(d, buildSite(), Object.assign(ops(), { withSolarFraction: false })); }
  function renderCompare() {
    if (!R) return;
    const list = [{ name: "Current design", design: S.design, cur: true }].concat(S.saved);
    const rs = list.map(x => ({ x, r: quick(x.design) }));
    const best = Math.min(...rs.map(o => o.r.summary.fuel_L));
    $("savedTable").innerHTML = `<tr><th>Design</th><th>Night min, no heating</th><th>Comfort hours, no heating</th><th>Kerosene L/day</th><th>Wall U</th><th>Glass m²</th><th></th></tr>` +
      rs.map(({ x, r }, i) => `<tr class="${x.cur ? "cur" : ""}"><td>${x.name}</td><td>${deg(r.summary.passive.nightMin)}</td><td>${f0(r.summary.passive.inBandPct * 0.24)} h</td>` +
        `<td class="${r.summary.fuel_L === best ? "err" : ""}">${f2(r.summary.fuel_L)}</td><td>${f2(r.net.U.wall)}</td><td>${f1(Object.values(x.design.win).reduce((s, v) => s + v, 0))}</td>` +
        `<td>${x.cur ? "" : `<button type="button" class="iconbtn" data-load="${i - 1}" title="Load" aria-label="Load ${x.name}">↺</button> <button type="button" class="iconbtn" data-del="${i - 1}" title="Delete" aria-label="Delete ${x.name}">×</button>`}</td></tr>`).join("");
    $("savedTable").querySelectorAll("[data-load]").forEach(b => b.onclick = () => { S.design = clone(S.saved[+b.dataset.load].design); syncInputs(); changed(); toast("Loaded " + S.saved[+b.dataset.load].name); });
    $("savedTable").querySelectorAll("[data-del]").forEach(b => b.onclick = () => { S.saved.splice(+b.dataset.del, 1); persist(); renderCompare(); });
    renderSweep();
  }
  $("sweepVar").addEventListener("change", renderSweep);
  function insLayers(d) { return ["wall", "roof"].map(k => d[k][A.insulationIndex(d[k])]); }
  function renderSweep() {
    const v = $("sweepVar").value, base = S.design;
    let xs = [], label = "", mk;
    if (v === "ins") { xs = [0, 25, 50, 75, 100, 150, 200, 250, 300]; label = "Insulation thickness (mm)"; mk = x => { const d = clone(base); insLayers(d).forEach(l => (l.t = Math.max(0.001, x / 1000))); return d; }; }
    if (v === "orient") { xs = Array.from({ length: 25 }, (_, i) => i * 15); label = "Front facade azimuth (° from north)"; mk = x => Object.assign(clone(base), { orient: x }); }
    if (v === "win") { xs = [0, 1, 2, 3, 4, 5, 6, 8, 10]; label = "Front window area (m²)"; mk = x => { const d = clone(base); d.win.front = x; return d; }; }
    if (v === "ach") { xs = [0.2, 0.3, 0.5, 0.75, 1, 1.5, 2, 3, 4]; label = "Air changes per hour"; mk = x => Object.assign(clone(base), { ach: x }); }
    if (v === "store") { xs = [0, 100, 200, 400, 800, 1200, 1600]; label = "Stored-heat mass (kg)"; mk = x => { const d = clone(base); if (d.store.type === "none") d.store.type = "water"; d.store.mass = x; return d; }; }
    if (v === "mat") {
      const mats = Object.entries(M).filter(([k, m]) => m.cls === "ins");
      // insulation cost at the region's market price (prices.js), same thickness
      const insCost = (d, k) => { const rows = TS.logistics.boq(d).filter(r => r.mat === k), rate = TS.logistics.rateFor(`${k}|m3`).rate; return rate ? rows.reduce((s, r) => s + r.qty * rate, 0) : null; };
      const res = mats.map(([k, m]) => { const d = clone(base); insLayers(d).forEach(l => { l.mat = k; delete l.k; delete l.rho; delete l.c; }); return { k, m, r: quick(d), cost: insCost(d, k) }; });
      C.bars($("sweepChart"), { items: res.map(o => ({ label: o.m.name, value: o.r.summary.fuel_L })).sort((a, b) => a.value - b.value), unit: " L/day", digits: 2, labelW: 190 });
      $("sweepLegend").innerHTML = "<span>Kerosene still needed, same insulation thickness, same weather</span>";
      $("sweepTable").innerHTML = `<tr><th>Material</th><th>Coldest inside, no heating</th><th>Kerosene L/day</th><th>Insulation cost</th></tr>` +
        res.sort((a, b) => a.r.summary.fuel_L - b.r.summary.fuel_L).map(o => `<tr><td>${o.m.name}</td><td>${deg(o.r.summary.passive.nightMin)}</td><td>${f2(o.r.summary.fuel_L)}</td><td>${o.cost != null ? "₹ " + Math.round(o.cost).toLocaleString("en-IN") : "no price"}</td></tr>`).join("");
      return;
    }
    const res = xs.map(x => quick(mk(x)));
    C.line($("sweepChart"), {
      x: xs, xTicks: xs.length > 12 ? xs.filter((_, i) => i % 4 === 0) : xs, height: 260, unit: "", tipDigits: 2, yPad: 0.2, xLabel: label,
      xFmt: (x, tip) => (tip ? label.replace(/ \(.*/, "") + " " + x : x),
      series: [{ name: "Kerosene, L/day", y: res.map(r => r.summary.fuel_L), cls: "c0", width: 2.4, points: true },
        { name: "Night min no heating, °C", y: res.map(r => r.summary.passive.nightMin), cls: "c1", width: 1.8, points: true }],
    });
    $("sweepLegend").innerHTML = `<span class="l-pas">Kerosene still needed, L/day</span><span class="l-amb">Night minimum without heating, °C</span>`;
    $("sweepTable").innerHTML = `<tr><th>${label}</th><th>Coldest inside, no heating</th><th>Kerosene L/day</th></tr>` +
      res.map((r, i) => `<tr><td>${xs[i]}</td><td>${deg(r.summary.passive.nightMin)}</td><td>${f2(r.summary.fuel_L)}</td></tr>`).join("");
  }

  /* ------------------------------------------------------- ANSYS */
  let dpData = null, probeData = null;
  function journalNow() {
    const site = buildSite(), base = A.contractInputs(S.design, site);
    const pts = [base];
    const extra = S.ansys.doe.split(/[,\s]+/).map(parseFloat).filter(v => v > 0);
    extra.forEach(mm => pts.push(Object.assign({}, base, { T_INS: mm / 1000 })));
    const runId = "TS-" + new Date().toISOString().slice(0, 16).replace(/[-:T]/g, "");
    return { base, j: A.journal({ project: S.ansys.project, exportCsv: S.ansys.exportCsv, map: S.ansys.map, points: pts, runId,
      note: `Design: ${S.design.L} x ${S.design.W} x ${S.design.H} m, front ${S.design.orient} deg, ${siteRec().name} ${MONTHS[S.site.month]}` }), runId };
  }
  function renderAnsys() {
    if (!R) return;
    $("wbProject").value = S.ansys.project; $("wbExport").value = S.ansys.exportCsv; $("wbDoe").value = S.ansys.doe;
    const { base, j } = journalNow();
    $("contractTable").innerHTML = `<tr><th class="l">Name</th><th class="l">Direction</th><th class="l">Meaning</th><th>Unit</th><th>Workbench P-number</th><th>This design</th></tr>` +
      A.CONTRACT.map(c => `<tr><td><b>${c.name}</b></td><td class="l">${c.dir === "in" ? "App to ANSYS" : "ANSYS to app"}</td><td class="l">${c.desc}</td><td>${c.unit}</td>` +
        `<td><input data-p="${c.name}" value="${S.ansys.map[c.name] || ""}" placeholder="P?" aria-label="P-number for ${c.name}"></td><td>${c.dir === "in" ? minus(+(+base[c.name]).toPrecision(5)) : "from CSV"}</td></tr>`).join("");
    $("contractTable").querySelectorAll("input[data-p]").forEach(inp => inp.addEventListener("change", () => {
      const v = inp.value.trim().toUpperCase(); if (v && !/^P\d+$/.test(v)) { toast("Use the form P1, P2, …"); inp.value = S.ansys.map[inp.dataset.p] || ""; return; }
      if (v) S.ansys.map[inp.dataset.p] = v; else delete S.ansys.map[inp.dataset.p];
      persist(); renderAnsys();
    }));
    $("journalPreview").textContent = j.text;
    renderParity();
  }
  $("wbProject").addEventListener("change", e => { S.ansys.project = e.target.value; persist(); renderAnsys(); });
  $("wbExport").addEventListener("change", e => { S.ansys.exportCsv = e.target.value; persist(); renderAnsys(); });
  $("wbDoe").addEventListener("change", e => { S.ansys.doe = e.target.value; persist(); renderAnsys(); });
  $("dlJournal").addEventListener("click", () => { const { j, runId } = journalNow(); download(`fluxion_${runId}.wbjn`, j.text, "text/plain"); });
  $("copyCmd").addEventListener("click", () => {
    const cmd = `"C:\\Program Files\\ANSYS Inc\\v182\\Framework\\bin\\Win64\\RunWB2.exe" -B -R "D:\\SIH26\\Analysis\\fluxion_run.wbjn"`;
    (navigator.clipboard ? navigator.clipboard.writeText(cmd) : Promise.reject()).then(() => toast("Batch command copied"), () => { $("journalPreview").textContent = cmd; toast("Copy the command from the box below"); });
  });
  $("dpFile").addEventListener("change", async e => {
    const f = e.target.files[0]; if (!f) return;
    try { dpData = A.readDesignPoints(await readFileBytes(f), S.ansys.map); dpData.file = f.name; renderParity(); }
    catch (err) { dpData = null; $("dpStatus").textContent = "Could not read " + f.name + ": " + err.message; }
  });
  $("probeFile").addEventListener("change", async e => {
    const f = e.target.files[0]; if (!f) return;
    try { probeData = A.readTransient(await readFileBytes(f)); probeData.file = f.name; renderParity(); }
    catch (err) { probeData = null; toast("Could not read " + f.name + ": " + err.message); }
  });
  function renderParity() {
    if (dpData) {
      const p = A.parity(S.design, buildSite(), ops(), dpData.points);
      const missingIn = A.CONTRACT.filter(c => c.dir === "in" && !dpData.columns.includes(c.name)).map(c => c.name);
      $("dpStatus").innerHTML = (dpData.mock ? `<b class="warnline">This file is marked as mock test data, not an ANSYS result.</b> ` : "") +
        `Loaded <b>${dpData.file}</b>: ${dpData.points.length} design point(s).` +
        (dpData.missingOutputs.length ? ` Not in the file: ${dpData.missingOutputs.join(", ")}.` : "") +
        (missingIn.length ? ` Inputs taken from the current design: ${missingIn.join(", ")}.` : "") +
        (p.temp ? ` Temperatures: mean absolute difference <b>${f2(p.temp.mae)} K</b>, RMSE ${f2(p.temp.rmse)} K, largest ${f2(p.temp.maxAbs)} K over ${p.temp.n} values.` : "");
      const lines = [];
      p.rows.forEach(r => Object.entries(r.cmp).forEach(([k, c]) => lines.push(`<tr><td>${r.name}</td><td class="l">${k}</td><td>${minus(f2(c.app))}</td><td>${minus(f2(c.ansys))}</td><td class="err">${minus(f2(c.err))}</td><td>${k.startsWith("Q_") && Math.abs(c.ansys) > 1e-6 ? minus(f1(100 * c.err / Math.abs(c.ansys))) + " %" : ""}</td></tr>`)));
      $("parityTable").innerHTML = lines.length ? `<tr><th>Design point</th><th class="l">Output</th><th>App</th><th>ANSYS</th><th>App − ANSYS</th><th>Relative</th></tr>` + lines.join("") : "";
      const pts = []; p.rows.forEach(r => Object.entries(r.cmp).forEach(([k, c]) => { if (k.startsWith("T_")) pts.push([c.ansys, c.app]); }));
      if (pts.length) C.scatter($("parityChart"), { height: 260, identity: true, xLabel: "ANSYS indoor air (°C)", yLabel: "App (°C)", sets: [{ cls: "c0", pts }], r: 4 });
      else $("parityChart").innerHTML = "";
    }
    if (probeData && R) {
      const key = Object.keys(probeData.series)[0], y = probeData.series[key];
      const t = probeData.t_h, x = t.slice();
      const app = t.map(h => R.passive.air[Math.min(R.N - 1, Math.floor(((h % R.N) + R.N) % R.N))]);
      C.line($("probeChart"), { x, height: 240, unit: " °C", tipDigits: 2, xLabel: `Hours from start of ANSYS run (${probeData.file})`, yLabel: "°C",
        series: [{ name: key + " (ANSYS)", y, cls: "ansys", width: 2.4 }, { name: "App, indoor air, no heating", y: app, cls: "pas", width: 1.8 }] });
      const lg = document.createElement("div"); lg.className = "legend";
      lg.innerHTML = legend([[key + ", ANSYS", "c2"], ["App, indoor air, no heating, current site and design", "c0"]]);
      $("probeChart").appendChild(lg);
    }
  }

  /* ------------------------------------------------------- boot */
  window.addEventListener("resize", () => { clearTimeout(runT); runT = setTimeout(() => { drawSection(); if (S.ui.tab === "results") renderResults(); }, 150); });

  /* one GO / CAUTION / NO-GO for the active design (rules in active.js), shared
     by the top bar and Mission; cached per run */
  let stKey = null, stVal = null;
  function status() {
    if (!R) return null;
    const key = [R, JSON.stringify(S.verify || null), document.documentElement.dataset.profile];
    if (stKey && key.every((k, i) => k === stKey[i])) return stVal;
    let checks = [], condensation = false;
    try { checks = TS.checks.run(S.design, buildSite(), ops(), R, "kerosene"); } catch (e) {}
    try { const mo = TS.moisture.analyse(R, S.design, "kerosene", ops()); condensation = mo.surfaces.some(x => x.hoursWet > 0) || mo.interstitial.some(x => x.risk); } catch (e) {}
    stVal = Object.assign(TS.active.status({ summary: R.summary, checks, condensation, verify: S.verify, designSig: TS.active.sig(S.design),
      safeFloor: TS.field.PROFILES[document.documentElement.dataset.profile || "defence"].safeFloor }), { condensation });
    stKey = key;
    return stVal;
  }
  function runNow() { clearTimeout(runT); run(); persist(); }
  TS.app = { get S() { return S; }, changed, runNow, status, outputs, renderResults, renderLive, designName: TS.active.label, syncInputs, buildSite, ops, get R() { return R; }, pathNames: () => PATH_NAMES(), toast, download, siteRec, MONTHS, showTab };
  syncInputs(); wireInputs();
  showTab(S.ui.tab || "field");
  run();
  if ("serviceWorker" in navigator && /^https?:$/.test(location.protocol) && !/tauri/.test(location.hostname)) {
    navigator.serviceWorker.register("sw.js").catch(() => {});
  }
})();
