/* Fluxion <-> ANSYS Workbench bridge (interface contract v1).
   - CONTRACT: parameter names, units and meaning agreed between the app and
     the ANSYS model (Workbench project D:/SIH26/Analysis/Shelter_General.wbpj).
   - journal(): writes a Workbench R18.2 journal (.wbjn) that sets inputs,
     updates design points and exports the parameter table.
   - parseCSV() / readDesignPoints() / readTransient(): read Workbench exports.
   - designFromDP() / appPredict() / parity(): run the app model on the same
     inputs and compare against ANSYS outputs.
   Workbench names parameters P1, P2, ... in creation order, so the app keeps a
   user-editable map from contract name to P-number. */
(function (g) {
  g.TS = g.TS || {};

  const CONTRACT = [
    { name: "L",           dir: "in",  unit: "m",          wb: "[m]",            desc: "Shelter length" },
    { name: "W",           dir: "in",  unit: "m",          wb: "[m]",            desc: "Shelter breadth" },
    { name: "H",           dir: "in",  unit: "m",          wb: "[m]",            desc: "Shelter height" },
    { name: "WIN_W",       dir: "in",  unit: "m",          wb: "[m]",            desc: "Front window width" },
    { name: "WIN_H",       dir: "in",  unit: "m",          wb: "[m]",            desc: "Front window height" },
    { name: "T_INS",       dir: "in",  unit: "m",          wb: "[m]",            desc: "Insulation thickness" },
    { name: "K_INS",       dir: "in",  unit: "W/m·K",      wb: "[W m^-1 C^-1]",  desc: "Insulation conductivity" },
    { name: "RHO_INS",     dir: "in",  unit: "kg/m³",      wb: "[kg m^-3]",      desc: "Insulation density" },
    { name: "CP_INS",      dir: "in",  unit: "J/kg·K",     wb: "[J kg^-1 C^-1]", desc: "Insulation specific heat" },
    { name: "H_OUT",       dir: "in",  unit: "W/m²·K",     wb: "[W m^-2 C^-1]",  desc: "Outside convection coefficient" },
    { name: "T_INIT",      dir: "in",  unit: "°C",         wb: "[C]",            desc: "Initial temperature" },
    { name: "SOLAR_SCALE", dir: "in",  unit: "–",          wb: "",               desc: "Multiplier on design-day solar table" },
    { name: "T_AIR_MIN",   dir: "out", unit: "°C",         desc: "Indoor air probe, minimum over final 24 h" },
    { name: "T_AIR_MAX",   dir: "out", unit: "°C",         desc: "Indoor air probe, maximum over final 24 h" },
    { name: "T_AIR_MEAN",  dir: "out", unit: "°C",         desc: "Indoor air probe, mean over final 24 h" },
    { name: "Q_ROOF",      dir: "out", unit: "W",          desc: "Mean heat flow out through roof" },
    { name: "Q_WALLS",     dir: "out", unit: "W",          desc: "Mean heat flow out through walls" },
    { name: "Q_FLOOR",     dir: "out", unit: "W",          desc: "Mean heat flow out through floor" },
    { name: "Q_WINDOW",    dir: "out", unit: "W",          desc: "Mean heat flow out through window" },
  ];

  /* Known so far: P1-P3 are the PUF density, conductivity, specific heat
     created in Engineering Data. Others are filled in once the ANSYS model
     exposes them. */
  const DEFAULT_MAP = { RHO_INS: "P1", K_INS: "P2", CP_INS: "P3" };

  /* ------------------------------------------------------------ journal */
  function fmt(v) {
    if (typeof v !== "number" || !isFinite(v)) return String(v);
    const a = Math.abs(v);
    return (a !== 0 && (a < 1e-3 || a >= 1e6)) ? v.toExponential(6) : String(+v.toPrecision(8));
  }
  function expr(name, v) {
    const c = CONTRACT.find(x => x.name === name);
    return c && c.wb ? `${fmt(v)} ${c.wb}` : fmt(v);
  }
  function winPath(p) { return String(p).replace(/\\/g, "/"); }

  /* opts: { project, exportCsv, map, points: [ {L:.., W:.., ...}, ... ],
             runId, note, version } */
  function journal(opts) {
    const map = opts.map || DEFAULT_MAP;
    const pts = opts.points && opts.points.length ? opts.points : [{}];
    const used = CONTRACT.filter(c => c.dir === "in" && map[c.name] && pts.some(p => p[c.name] != null));
    const skipped = CONTRACT.filter(c => c.dir === "in" && !map[c.name] && pts.some(p => p[c.name] != null));
    const L = [];
    L.push("# encoding: utf-8");
    L.push("# Release 18.2");
    L.push(`# Fluxion -> ANSYS Workbench journal, interface contract v1`);
    L.push(`# Run ${opts.runId || ""}  generated ${opts.generated || new Date().toISOString()}`);
    if (opts.note) L.push(`# ${opts.note}`);
    L.push(`# Design points: ${pts.length}.  Batch run:`);
    L.push(`#   "C:\\Program Files\\ANSYS Inc\\v182\\Framework\\bin\\Win64\\RunWB2.exe" -B -R "<this file>"`);
    if (skipped.length) L.push(`# NOT SENT (no P-number mapped yet): ${skipped.map(c => c.name).join(", ")}`);
    L.push(`SetScriptVersion(Version="${opts.version || "18.2.109"}")`);
    L.push(`Open(FilePath="${winPath(opts.project || "D:/SIH26/Analysis/Shelter_General.wbpj")}")`);
    L.push("");
    for (const c of used) L.push(`p_${c.name} = Parameters.GetParameter(Name="${map[c.name]}")  # ${c.desc}`);
    L.push("");
    // design point 0: same form as the team's working journal (parameter.Expression)
    L.push("# Design point 0 (current)");
    for (const c of used) if (pts[0][c.name] != null) L.push(`p_${c.name}.Expression = "${expr(c.name, pts[0][c.name])}"`);
    const dpNames = [];
    for (let i = 1; i < pts.length; i++) {
      L.push("");
      L.push(`# Design point ${i}`);
      L.push(`dp${i} = Parameters.CreateDesignPoint()`);
      dpNames.push(`dp${i}`);
      for (const c of used) if (pts[i][c.name] != null)
        L.push(`dp${i}.SetParameterExpression(Parameter=p_${c.name}, Expression="${expr(c.name, pts[i][c.name])}")`);
    }
    L.push("");
    if (dpNames.length) {
      L.push(`dp0 = Parameters.GetDesignPoint(Name="0")`);
      L.push(`UpdateAllDesignPoints(DesignPoints=[dp0, ${dpNames.join(", ")}])`);
    } else {
      L.push("Update()");
    }
    L.push(`Parameters.ExportAllDesignPointsData(FilePath="${winPath(opts.exportCsv || "D:/SIH26/Analysis/results/ts_results.csv")}")`);
    L.push("Save(Overwrite=True)");
    L.push(`print("Fluxion run ${opts.runId || ""}: ${pts.length} design point(s) updated and exported")`);
    return { text: L.join("\r\n") + "\r\n", used: used.map(c => c.name), skipped: skipped.map(c => c.name) };
  }

  /* ---------------------------------------------------------------- CSV */
  function parseCSV(text) {
    const rows = [], src = String(text).replace(/^\uFEFF/, "");
    let row = [], cell = "", q = false;
    for (let i = 0; i < src.length; i++) {
      const ch = src[i];
      if (q) {
        if (ch === '"') { if (src[i + 1] === '"') { cell += '"'; i++; } else q = false; }
        else cell += ch;
      } else if (ch === '"') q = true;
      else if (ch === ",") { row.push(cell); cell = ""; }
      else if (ch === "\n" || ch === "\r") {
        if (ch === "\r" && src[i + 1] === "\n") i++;
        row.push(cell); rows.push(row); row = []; cell = "";
      } else cell += ch;
    }
    if (cell !== "" || row.length) { row.push(cell); rows.push(row); }
    return rows.filter(r => r.some(c => c.trim() !== ""));
  }
  /* Workbench writes ANSI (Windows-1252) text, e.g. the degree sign in
     "[\u00B0C]". Decode bytes as UTF-8 if valid, else as Windows-1252. */
  function decode(bytes) {
    try { return new TextDecoder("utf-8", { fatal: true }).decode(bytes); }
    catch (e) { return new TextDecoder("windows-1252").decode(bytes); }
  }
  const num = s => { const v = parseFloat(String(s).trim()); return isFinite(v) ? v : null; };

  /* Workbench parameter table: comment lines start with '#', one of them
     lists "P1 - description [unit]". Header row starts with "Name". */
  function readDesignPoints(text, map) {
    map = map || DEFAULT_MAP;
    const rows = parseCSV(text);
    const desc = {};
    for (const r of rows) {
      if (!r[0].trim().startsWith("#")) continue;
      for (const c of r) {
        const m = c.match(/^\s*#?\s*(P\d+)\s*-\s*(.+?)\s*$/);
        if (m) desc[m[1]] = m[2];
      }
    }
    const hi = rows.findIndex(r => !r[0].trim().startsWith("#") && /^name$/i.test(r[0].trim()));
    if (hi < 0) throw new Error("No 'Name,P1,P2,…' header row found. Export the Workbench parameter table or use DesignPointLog.csv.");
    const head = rows[hi].map(h => h.trim());
    const rev = {};
    for (const k in map) if (map[k]) rev[map[k]] = k;
    const colName = head.map(h => {
      const m = h.match(/^(P\d+)\b(?:\s*-\s*(.+))?/);
      if (m) {
        const P = m[1], d = m[2] || desc[P] || "";
        if (rev[P]) return rev[P];
        const first = d.trim().split(/[\s\[(]/)[0].toUpperCase();
        const hit = CONTRACT.find(c => c.name === first)
          || CONTRACT.slice().sort((a, b) => b.name.length - a.name.length)
               .find(c => c.name.length > 2 && new RegExp("(^|[^A-Z_])" + c.name + "([^A-Z_]|$)").test(d.toUpperCase()));
        return hit ? hit.name : P;
      }
      const hit = CONTRACT.find(c => c.name === h.toUpperCase());
      return hit ? hit.name : h;
    });
    const points = [];
    for (let i = hi + 1; i < rows.length; i++) {
      const r = rows[i];
      if (r[0].trim().startsWith("#")) continue;
      const o = { _name: r[0].trim() };
      for (let j = 1; j < head.length; j++) { const v = num(r[j]); if (v != null) o[colName[j]] = v; }
      points.push(o);
    }
    const missing = CONTRACT.filter(c => c.dir === "out" && !colName.includes(c.name)).map(c => c.name);
    return { columns: colName, descriptions: desc, points, missingOutputs: missing, mock: /MOCK/i.test(String(text).slice(0, 2000)) };
  }

  /* Transient probe export: ",Time [s],Temperature Probe [C],…" */
  function readTransient(text) {
    const rows = parseCSV(text).filter(r => !r[0].trim().startsWith("#"));
    const head = rows[0].map(h => h.trim());
    const ti = head.findIndex(h => /time/i.test(h));
    if (ti < 0) throw new Error("No time column found (expected a header like 'Time [s]').");
    const toH = /\[\s*s\s*\]/i.test(head[ti]) ? 1 / 3600 : /\[\s*min\s*\]/i.test(head[ti]) ? 1 / 60 : 1;
    const series = {};
    head.forEach((h, j) => { if (j !== ti && h && !/^time_h/i.test(h)) series[h] = []; });
    const t = [];
    for (let i = 1; i < rows.length; i++) {
      const tv = num(rows[i][ti]); if (tv == null) continue;
      t.push(tv * toH);
      for (const h in series) series[h].push(num(rows[i][head.indexOf(h)]));
    }
    for (const h in series) if (series[h].every(v => v == null)) delete series[h];
    // drop a leading index column (Workbench writes an unnamed counter)
    return { t_h: t, series };
  }

  /* ------------------------------------------------- app <-> contract */
  /* the layer the contract's T_INS/K_INS/... refer to: the insulation layer
     with the highest R, or the highest-R layer if the element has none */
  function insulationIndex(layers) {
    const M = g.TS.MATERIALS, E = g.TS.engine;
    const ps = layers.map(l => E.layerProps(l, M));
    const pick = idx => idx.reduce((b, i) => (b < 0 || E.layerR(ps[i]) > E.layerR(ps[b]) ? i : b), -1);
    const ins = ps.map((p, i) => (p.cls === "ins" ? i : -1)).filter(i => i >= 0);
    return ins.length ? pick(ins) : pick(ps.map((_, i) => i));
  }
  /* contract inputs describing the current app design */
  function contractInputs(design, site, res) {
    const E = g.TS.engine, M = g.TS.MATERIALS;
    const i = insulationIndex(design.wall), p = E.layerProps(design.wall[i], M);
    const Aw = (design.win && design.win.front) || 0, wh = Aw > 0 ? Math.min(1.2, 0.8 * design.H) : 0;
    const rho = E.airDensity(site.alt, (site.Tmin + site.Tmax) / 2);
    return {
      L: design.L, W: design.W, H: design.H,
      WIN_W: wh > 0 ? +(Aw / wh).toFixed(3) : 0, WIN_H: +wh.toFixed(3),
      T_INS: p.t, K_INS: p.k, RHO_INS: p.rho, CP_INS: p.c,
      H_OUT: +((4 + 4 * site.wind) * Math.pow(rho / 1.225, 0.8)).toFixed(2),
      T_INIT: +(((site.Tmin + site.Tmax) / 2)).toFixed(2), SOLAR_SCALE: 1,
    };
  }
  /* apply a design point's inputs onto a copy of the app design */
  function designFromDP(design, dp) {
    const d = JSON.parse(JSON.stringify(design));
    if (dp.L != null) d.L = dp.L; if (dp.W != null) d.W = dp.W; if (dp.H != null) d.H = dp.H;
    if (dp.WIN_W != null && dp.WIN_H != null) d.win = Object.assign({}, d.win, { front: dp.WIN_W * dp.WIN_H });
    for (const key of ["wall", "roof"]) {
      const i = insulationIndex(d[key]);
      const l = d[key][i];
      if (dp.T_INS != null) l.t = dp.T_INS;
      if (dp.K_INS != null) l.k = dp.K_INS;
      if (dp.RHO_INS != null) l.rho = dp.RHO_INS;
      if (dp.CP_INS != null) l.c = dp.CP_INS;
    }
    return d;
  }
  function appPredict(design, site, ops, dp) {
    const d = designFromDP(design, dp);
    const o = Object.assign({}, ops, { withSolarFraction: false });
    if (dp.H_OUT != null) o.hOut = dp.H_OUT;
    if (dp.SOLAR_SCALE != null) o.solarScale = dp.SOLAR_SCALE;
    const r = g.TS.engine.simulate(d, site, o);
    const a = r.passive.air, P = r.passive.paths, n = P.length;
    const mean = f => P.reduce((s, p) => s + f(p), 0) / n;
    return {
      T_AIR_MIN: Math.min(...a), T_AIR_MAX: Math.max(...a), T_AIR_MEAN: a.reduce((s, v) => s + v, 0) / a.length,
      Q_ROOF: mean(p => p.roof), Q_FLOOR: mean(p => p.floor), Q_WINDOW: mean(p => p.glazing),
      Q_WALLS: mean(p => Object.keys(p).filter(k => k.startsWith("wall_")).reduce((s, k) => s + p[k], 0)),
    };
  }
  function stats(pairs) {
    const e = pairs.map(([a, b]) => a - b), n = e.length;
    if (!n) return null;
    const mae = e.reduce((s, v) => s + Math.abs(v), 0) / n;
    const rmse = Math.sqrt(e.reduce((s, v) => s + v * v, 0) / n);
    const bias = e.reduce((s, v) => s + v, 0) / n;
    const maxAbs = Math.max(...e.map(Math.abs));
    return { n, mae, rmse, bias, maxAbs };
  }
  /* rows: per design point, app vs ANSYS on every output present */
  function parity(design, site, ops, dps) {
    const outs = CONTRACT.filter(c => c.dir === "out").map(c => c.name);
    const rows = dps.map(dp => {
      const app = appPredict(design, site, ops, dp);
      const o = { name: dp._name, inputs: dp, cmp: {} };
      for (const k of outs) if (dp[k] != null) o.cmp[k] = { app: app[k], ansys: dp[k], err: app[k] - dp[k] };
      return o;
    });
    const temp = [], flow = {};
    for (const r of rows) for (const k in r.cmp) {
      if (k.startsWith("T_")) temp.push([r.cmp[k].app, r.cmp[k].ansys]);
      else (flow[k] = flow[k] || []).push([r.cmp[k].app, r.cmp[k].ansys]);
    }
    const flowStats = {};
    for (const k in flow) flowStats[k] = stats(flow[k]);
    return { rows, temp: stats(temp), flow: flowStats };
  }
  /* time-series comparison, ANSYS series interpolated onto app hours */
  function interp(t, y, x) {
    if (x <= t[0]) return y[0];
    for (let i = 1; i < t.length; i++) if (x <= t[i]) {
      const f = (x - t[i - 1]) / (t[i] - t[i - 1]); return y[i - 1] + f * (y[i] - y[i - 1]);
    }
    return y[y.length - 1];
  }

  g.TS.ansys = { CONTRACT, DEFAULT_MAP, journal, decode, parseCSV, readDesignPoints, readTransient, contractInputs,
    designFromDP, appPredict, parity, stats, interp, insulationIndex };
  if (typeof module !== "undefined") module.exports = g.TS;
})(typeof window !== "undefined" ? window : globalThis);
