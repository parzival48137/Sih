/* The one active design. Mission writes its recommendation here and SIM, OPT,
   ANSYS and the top bar read it back, so every screen shows one design and one
   set of numbers. Pure functions, no DOM, so they run under node tests too. */
(function (g) {
  "use strict";
  const TS = g.TS;
  const clone = o => JSON.parse(JSON.stringify(o));
  const f1 = v => (+v).toFixed(1).replace(/^-/, "−");

  /* Mission recommendation -> the shared design and the operating settings */
  function fromMission(d, units, name, ops) {
    return {
      design: Object.assign(clone(d), { ach: d.ach || 0.5, units: units || 1, name }),
      ops: { setpoint: ops.setpoint, eta: ops.eta, burnMax: ops.burnMax, kwhPerL: ops.kwhPerL },
    };
  }
  const sig = d => JSON.stringify(d);
  /* true when the design was changed (in SIM) after Mission last set it */
  const edited = (design, appliedSig) => !!appliedSig && sig(design) !== appliedSig;
  const label = d => `${(d.units || 1) > 1 ? d.units + " × " : ""}${d.name || "Custom design"}, ${f1(d.L)} × ${f1(d.W)} × ${f1(d.H)} m`;
  const fuelAll = (summary, d) => summary.fuel_L * (d.units || 1);

  /* GO / CAUTION / NO-GO.
     NO-GO: a failed check, the heated night below the safe floor, an undersized
     stove, or a failed extreme case recorded for this exact design.
     CAUTION: any check that warns (CO2 above 1000 ppm, ...) or condensation risk. */
  function status(o) {
    const s = o.summary, checks = o.checks || [];
    const reasons = checks.filter(c => c.level === "fail").map(c => c.title);
    const warns = checks.filter(c => c.level === "warn").map(c => c.title);
    if (o.condensation) warns.push("Condensation risk");
    if (s.unmetHours > 0) reasons.unshift(`Heater short ${Math.round(s.unmetHours)} h`);
    if (s.heated.nightMin < o.safeFloor - 0.05) reasons.unshift(`Heated night ${f1(s.heated.nightMin)} °C, below ${o.safeFloor} °C`);
    if (o.verify && o.verify.sig === o.designSig && !o.verify.ok) reasons.unshift("Fails the extreme cold case");
    const level = reasons.length ? "nogo" : warns.length ? "caution" : "go";
    return { level, label: { go: "GO", caution: "CAUTION", nogo: "NO-GO" }[level], reasons, warns };
  }

  TS.active = { fromMission, sig, edited, label, fuelAll, status };
  if (typeof module !== "undefined") module.exports = TS;
})(typeof window !== "undefined" ? window : globalThis);
