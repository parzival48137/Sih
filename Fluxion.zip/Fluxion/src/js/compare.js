/* Compare designs: a simple optimizer. Starting from the active design it tries
   100 variants under the same weather (place and month):
     insulation material (PUF, XPS, EPS, rock wool: the ones with a market price)
     x thickness 50-250 mm (walls and roof) x south window size (5 steps)
   and picks three: least kerosene, lowest cost that still stays warm, and the
   best balance of the two. Each pick says what changes and can be applied. */
(function () {
  "use strict";
  const TS = window.TS, A = TS.app, C = TS.charts, $ = id => document.getElementById(id);
  const clone = o => JSON.parse(JSON.stringify(o));
  const f1 = v => (v == null || !isFinite(v) ? "–" : (+v).toFixed(1)).replace(/^-/, "−");
  const f2 = v => (v == null || !isFinite(v) ? "–" : (+v).toFixed(2)).replace(/^-/, "−");
  const rs = v => (v == null || !isFinite(v) ? "–" : "₹ " + Math.round(v).toLocaleString("en-IN"));
  const MATS = ["puf", "xps", "eps", "rockwool"], THICK = [0.04, 0.08, 0.12, 0.16, 0.20];

  function variants(base) {
    const w0 = (base.win && base.win.front) || 0, wins = w0 > 0.1 ? [0.5, 0.75, 1, 1.25, 1.5].map(f => +(w0 * f).toFixed(1)) : [0, 1, 2, 3, 4];
    const out = [];
    MATS.forEach(mat => THICK.forEach(t => wins.forEach(w => {
      let d = TS.optimise.setIns(clone(base), mat, t);
      d.win = Object.assign({}, d.win, { front: Math.min(w, 0.85 * d.L * d.H) });
      out.push({ d, mat, t, w: d.win.front });
    })));
    return out;
  }
  function evaluate(d, site, ops, floor) {
    const r = TS.engine.simulate(d, site, Object.assign({}, ops, { withSolarFraction: false }));
    return { fuel: r.summary.fuel_L, cold: r.summary.passive.nightMin, cost: TS.logistics.costFn(d).cost, ok: r.summary.heated.nightMin >= floor - 0.05 && r.summary.unmetHours === 0 };
  }
  let picks = [];
  function run() {
    const t0 = performance.now(), base = A.S.design, site = A.buildSite(), ops = A.ops();
    const floor = TS.field.PROFILES[document.documentElement.dataset.profile || "defence"].safeFloor;
    const cur = Object.assign({ d: base, label: "Your design" }, evaluate(base, site, ops, floor));
    const all = variants(base).map(v => Object.assign(v, evaluate(v.d, site, ops, floor)));
    // cheaper or balanced picks must stay warm and use at most a little more kerosene than the current design
    const tol = Math.max(0.1, cur.fuel * 0.25);
    const okAll = all.filter(v => v.ok && v.fuel <= cur.fuel + tol), pool = okAll.length ? okAll : all.filter(v => v.ok).length ? all.filter(v => v.ok) : all;
    const fMin = Math.min(...pool.map(v => v.fuel)), fMax = Math.max(...pool.map(v => v.fuel)), cMin = Math.min(...pool.map(v => v.cost)), cMax = Math.max(...pool.map(v => v.cost));
    const n = (v, a, b) => (b - a < 1e-9 ? 0 : (v - a) / (b - a));
    const used = new Set(), key = v => JSON.stringify([v.d.wall, v.d.roof, v.d.win]);   // the design itself, not the request
    const first = list => { const v = list.find(x => !used.has(key(x))) || list[0]; used.add(key(v)); return v; };   // three different designs
    const least = first(all.slice().sort((a, b) => a.fuel - b.fuel || a.cost - b.cost));
    const cheap = first(pool.slice().sort((a, b) => a.cost - b.cost || a.fuel - b.fuel));
    const value = first(pool.slice().sort((a, b) => (n(a.fuel, fMin, fMax) + n(a.cost, cMin, cMax)) - (n(b.fuel, fMin, fMax) + n(b.cost, cMin, cMax))));
    picks = [Object.assign({ label: "Least kerosene", why: "Uses the least fuel of all 100." }, least),
      Object.assign({ label: "Lowest cost", why: `Cheapest design that stays warm and uses at most ${f2(tol)} L/day more kerosene than yours.` }, cheap),
      Object.assign({ label: "Best value", why: "Best balance of kerosene and money among the designs that stay warm." }, value)];
    const ms = performance.now() - t0, days = 30;
    const change = p => { const ins = TS.optimise.insOf(p.d); return `${ins ? `${TS.MATERIALS[ins.mat].name} ${Math.round(ins.t * 1000)} mm` : TS.MATERIALS[p.mat].name} in walls and roof, south window ${f1(p.w)} m²`; };
    const diff = p => { const df = cur.fuel - p.fuel, dc = p.cost - cur.cost;
      return `${df >= 0.005 ? `saves <b>${f2(df)} L/day</b> (${Math.round(df * days)} L a month)` : df <= -0.005 ? `uses <b>${f2(-df)} L/day more</b>` : "same fuel"}; ` +
        `${Math.abs(dc) < 1 ? "same cost" : dc > 0 ? `costs <b>${rs(dc)} more</b>` : `costs <b>${rs(-dc)} less</b>`}`; };
    $("cmpCards").innerHTML = picks.map((p, i) => `<div class="cmpcard"><h3>${p.label}</h3><p class="why">${p.why}</p>` +
      `<div class="kv"><span>Kerosene</span><b>${f2(p.fuel)} L/day</b></div><div class="kv"><span>Cost of materials</span><b>${rs(p.cost)}</b></div>` +
      `<div class="kv"><span>Coldest inside, no heating</span><b>${f1(p.cold)} °C</b></div>` +
      `<p class="chg"><b>What changes:</b> ${change(p)}.</p><p class="vs">Compared with your design: ${diff(p)}.</p>` +
      `<button type="button" class="solid" data-use="${i}">Use this design</button></div>`).join("");
    $("cmpCards").querySelectorAll("[data-use]").forEach(b => b.onclick = () => { const p = picks[+b.dataset.use]; A.S.design = clone(p.d); A.syncInputs(); A.changed(); A.toast("Using: " + p.label); });
    C.bars($("cmpChart"), { items: [{ label: "Your design", value: cur.fuel, cls: "mute" }].concat(picks.map(p => ({ label: p.label, value: p.fuel }))), unit: " L/day", digits: 2, labelW: 150 });
    $("cmpNote").textContent = `${all.length} designs tried in ${Math.round(ms)} ms, all in the same weather (${A.siteRec().name}, ${A.MONTHS[A.S.site.month]}). ` +
      `Your design: ${f2(cur.fuel)} L/day, ${rs(cur.cost)}. Cost counts only materials with a price for this place.`;
  }
  $("cmpRun").addEventListener("click", () => { $("cmpNote").textContent = "Trying 100 designs…"; setTimeout(run, 30); });
  TS.compare = { run, variants };
})();
