/* Engineering report, built on the device with jsPDF (MIT, vendor/).
   All drawings and charts are vector (jsPDF lines, rectangles, text), so they
   stay sharp in print and the file stays small.
   Page 1  Executive summary, identification, GO / NO-GO
   Page 2  Plan, front and end elevations with dimensions; sections; specification
   Page 3  Hourly log, 24-h temperature chart, ventilation and moisture
   Page 4  Bill of materials with R-values and rates, logistics, APDL excerpt
   Then    Outputs 2 and 3, skin temperature, design checks, sensitivity, method */
(function (g) {
  "use strict";
  const TS = g.TS;
  const f0 = v => (v == null || !isFinite(v) ? "-" : String(Math.round(v)));
  const f1 = v => (v == null || !isFinite(v) ? "-" : (+v).toFixed(1));
  const f2 = v => (v == null || !isFinite(v) ? "-" : (+v).toFixed(2));
  const clean = s => String(s).replace(/−/g, "-").replace(/₂/g, "2").replace(/²/g, "2").replace(/³/g, "3").replace(/≥/g, ">=").replace(/≤/g, "<=")
    .replace(/μ/g, "mu").replace(/ρ/g, "rho").replace(/…/g, "...").replace(/[\u2009\u202f]/g, " ").replace(/→/g, "->").replace(/<[^>]+>/g, "");
  const INK = [24, 35, 46], MUTE = [125, 139, 152], GLASS = [47, 111, 163], HEAT = [140, 33, 49], OK = [61, 107, 53], BAD = [140, 33, 49];
  const FILL = { metal: [127, 140, 151], ins: [241, 212, 142], gap: [255, 255, 255], mass: [196, 158, 114], board: [217, 190, 146] };

  function peakLoss(r) { let m = 0; r.night.forEach((n, i) => { if (!n) return; let s = 0; for (const k in r.heated.paths[i]) s += Math.max(0, r.heated.paths[i][k]); m = Math.max(m, s); }); return m; }
  function goNoGo(ctx) {
    const s = ctx.r.summary, floor = ctx.safeFloor != null ? ctx.safeFloor : ctx.ops.setpoint, why = [];
    if (s.heated.nightMin < floor - 0.05) why.push(`heated night minimum ${f1(s.heated.nightMin)} C is below ${floor} C`);
    if (s.unmetHours > 0) why.push(`heater short for ${f0(s.unmetHours)} h a day`);
    (ctx.checks || []).filter(c => c.level === "fail").forEach(c => why.push(c.title.toLowerCase()));
    return { go: why.length === 0, why, floor };
  }

  /* ---------------------------------------------------------- vector helpers */
  function H(doc) {
    const col = c => { doc.setDrawColor(...c); doc.setTextColor(...c); };
    const arrow = (x1, y1, x2, y2) => {
      const a = Math.atan2(y2 - y1, x2 - x1), s = 1.6; doc.line(x1, y1, x2, y2);
      [[x1, y1, a], [x2, y2, a + Math.PI]].forEach(([x, y, b]) => doc.triangle(x, y, x + s * Math.cos(b + 0.35), y + s * Math.sin(b + 0.35), x + s * Math.cos(b - 0.35), y + s * Math.sin(b - 0.35), "F"));
    };
    const dim = (x1, y1, x2, y2, label, off, vertical) => {
      doc.setLineWidth(0.2); col(MUTE); doc.setFillColor(...MUTE); doc.setFontSize(8);
      if (vertical) { doc.line(x1, y1, x1 + off, y1); doc.line(x2, y2, x2 + off, y2); arrow(x1 + off * 0.8, y1, x2 + off * 0.8, y2); doc.text(label, x1 + off + 1, (y1 + y2) / 2, { baseline: "middle" }); }
      else { doc.line(x1, y1, x1, y1 + off); doc.line(x2, y2, x2, y2 + off); arrow(x1, y1 + off * 0.8, x2, y2 + off * 0.8); doc.text(label, (x1 + x2) / 2, y1 + off + 3.5, { align: "center" }); }
      col(INK);
    };
    const poly = (pts, style) => { const segs = pts.slice(1).map((p, i) => [p[0] - pts[i][0], p[1] - pts[i][1]]); doc.lines(segs, pts[0][0], pts[0][1], [1, 1], style || "S", true); };
    return { col, arrow, dim, poly };
  }
  function plan(doc, d, x, y, w, h) {
    const { dim, col } = H(doc), sc = Math.min(w / d.L, h / d.W), T = Math.max(0.6, 0.15 * sc), X = x + (w - d.L * sc) / 2, Y = y;
    doc.setLineWidth(0.3); col(INK); doc.setFillColor(...FILL.ins); doc.rect(X, Y, d.L * sc, d.W * sc, "FD");
    doc.setFillColor(243, 245, 247); doc.rect(X + T, Y + T, d.L * sc - 2 * T, d.W * sc - 2 * T, "FD");
    const side = { front: [X, Y + d.W * sc, 1, 0, d.L], back: [X, Y, 1, 0, d.L], left: [X, Y, 0, 1, d.W], right: [X + d.L * sc, Y, 0, 1, d.W] };
    for (const k in side) {
      const A = (d.win || {})[k] || 0; if (!A) continue;
      const [sx, sy, dx, dy, len] = side[k], ww = Math.min(len * 0.9, A / Math.min(1.2, 0.8 * d.H)) * sc, o = (len * sc - ww) / 2;
      doc.setDrawColor(...GLASS); doc.setLineWidth(1.2); doc.line(sx + dx * o, sy + dy * o, sx + dx * (o + ww), sy + dy * (o + ww));
    }
    if (d.trombe && d.trombe.area > 0) { doc.setDrawColor(...FILL.mass); doc.setLineWidth(1.4); const tw = Math.min(d.L * 0.45, d.trombe.area / d.H) * sc; doc.line(X + 1, Y + d.W * sc + 1.2, X + 1 + tw, Y + d.W * sc + 1.2); }
    dim(X, Y + d.W * sc + 3, X + d.L * sc, Y + d.W * sc + 3, `L = ${f2(d.L)} m`, 5, false);
    dim(X + d.L * sc + 3, Y, X + d.L * sc + 3, Y + d.W * sc, `W = ${f2(d.W)} m`, 5, true);
    const a = (180 - d.orient) * Math.PI / 180, cx = x + w - 6, cy = y + 8;   // the front facade is drawn at the bottom
    doc.setDrawColor(...INK); doc.setFillColor(...INK); doc.setLineWidth(0.4);
    doc.line(cx - 6 * Math.sin(a), cy + 6 * Math.cos(a), cx + 6 * Math.sin(a), cy - 6 * Math.cos(a));
    doc.circle(cx + 6 * Math.sin(a), cy - 6 * Math.cos(a), 0.8, "F"); doc.setFontSize(8); doc.text("N", cx + 9 * Math.sin(a), cy - 9 * Math.cos(a), { align: "center", baseline: "middle" });
    doc.setFontSize(9); doc.text("PLAN", x, y - 2); doc.setFontSize(7.5); col(MUTE);
    doc.text(clean(`Front faces ${TS.engine.compass(d.orient)} (${d.orient} deg). Blue: glazing. Brown: Trombe wall.`), x, y + d.W * sc + 16); col(INK);
  }
  function frontElevation(doc, d, x, y, w, h) {
    const { dim, col } = H(doc), lift = d.floorMode === "raised" ? 0.4 : 0, sc = Math.min(w / d.L, h / (d.H + lift + 0.3)), base = y + h;
    doc.setLineWidth(0.3); col(INK); doc.line(x - 2, base, x + w + 2, base);
    const X = x + (w - d.L * sc) / 2, top = base - (lift + d.H) * sc;
    if (lift) { doc.setFillColor(...MUTE); [0.2, d.L / 2, d.L - 0.4].forEach(p => doc.rect(X + p * sc, base - lift * sc, 0.2 * sc, lift * sc, "F")); }
    doc.setFillColor(243, 245, 247); doc.rect(X, top, d.L * sc, d.H * sc, "FD");
    const A = (d.win || {}).front || 0, wh = Math.min(1.2, 0.8 * d.H), ww = Math.min(d.L * 0.9, A / wh);
    if (A > 0) { doc.setFillColor(207, 224, 238); doc.setDrawColor(...GLASS); doc.rect(X + (d.L - ww) / 2 * sc, base - (lift + 0.9 + wh) * sc, ww * sc, wh * sc, "FD"); }
    doc.setDrawColor(...INK);
    dim(X, base + 2, X + d.L * sc, base + 2, `L = ${f2(d.L)} m`, 4, false);
    dim(X + d.L * sc + 3, top, X + d.L * sc + 3, base - lift * sc, `H = ${f2(d.H)} m`, 4, true);
    if (lift) { doc.setFontSize(7.5); col(MUTE); doc.text(`skids, ${lift} m clearance`, X, base + 12); col(INK); }
    doc.setFontSize(9); doc.text(clean(`FRONT ELEVATION (${TS.engine.compass(d.orient)})`), x, y - 2);
  }
  function endElevation(doc, d, x, y, w, h) {
    const { dim, col, poly } = H(doc), p = (d.pitch || 0) * Math.PI / 180, ridge = d.W / 2 * Math.tan(p), lift = d.floorMode === "raised" ? 0.4 : 0;
    const sc = Math.min(w / d.W, h / (d.H + ridge + lift + 0.3)), base = y + h, X = x + (w - d.W * sc) / 2, eave = base - (lift + d.H) * sc;
    doc.setLineWidth(0.3); col(INK); doc.line(x - 2, base, x + w + 2, base);
    doc.setFillColor(243, 245, 247); doc.rect(X, eave, d.W * sc, d.H * sc, "FD");
    if (ridge > 0.01) { doc.setFillColor(201, 211, 220); poly([[X, eave], [X + d.W * sc, eave], [X + d.W * sc / 2, eave - ridge * sc]], "FD"); doc.setFontSize(8); doc.text(`Pitch = ${d.pitch} deg`, X + d.W * sc / 2 + 2, eave - ridge * sc / 2); }
    dim(X, base + 2, X + d.W * sc, base + 2, `W = ${f2(d.W)} m`, 4, false);
    if (ridge > 0.01) dim(X + d.W * sc + 3, eave - ridge * sc, X + d.W * sc + 3, eave, `${f2(ridge)} m`, 4, true);
    doc.setFontSize(9); doc.text("END ELEVATION", x, y - 2);
  }
  function sections(doc, d, x, y) {
    const { col } = H(doc), rows = [["Wall", d.wall], ["Roof", d.roof], ["Floor", d.floor]];
    if (d.trombe && d.trombe.area > 0) rows.push(["Trombe", [{ mat: d.trombe.mat, t: d.trombe.t }]]);
    doc.setFontSize(9); doc.text("SECTIONS (outside on the left)", x, y); y += 3;
    rows.forEach(([name, ls]) => {
      const tot = ls.reduce((a, l) => a + l.t, 0), span = 90, raw = ls.map(l => Math.max(1.2, l.t / tot * span)), k = span / raw.reduce((a, b) => a + b, 0);
      let cx = x + 18; doc.setFontSize(8.5); doc.text(name, x, y + 4);
      ls.forEach((l, i) => { const m = TS.MATERIALS[l.mat] || TS.MATERIALS.custom; doc.setFillColor(...(FILL[m.cls] || [200, 200, 200])); doc.setDrawColor(...INK); doc.setLineWidth(0.2); doc.rect(cx, y, raw[i] * k, 7, "FD"); cx += raw[i] * k; });
      doc.text(clean(`${Math.round(tot * 1000)} mm, R ${f2(TS.engine.constructionR(ls, TS.MATERIALS))} m2K/W`), x + 18 + span + 3, y + 4.5);
      col(MUTE); doc.setFontSize(7); doc.text(clean(ls.map(l => `${(TS.MATERIALS[l.mat] || {}).name} ${l.t < 0.005 ? (l.t * 1000).toFixed(1) : Math.round(l.t * 1000)}`).join(" | ")), x + 18, y + 10.5); col(INK);
      y += 15;
    });
    return y;
  }
  function chart(doc, x, y, w, h, xs, series, opt) {
    const { col } = H(doc); opt = opt || {};
    let lo = Infinity, hi = -Infinity; series.forEach(s => s.y.forEach(v => { if (isFinite(v)) { lo = Math.min(lo, v); hi = Math.max(hi, v); } }));
    if (opt.band) { lo = Math.min(lo, opt.band[0]); hi = Math.max(hi, opt.band[1]); }
    const tk = TS.charts.niceTicks(lo, hi, 6), y0 = tk[0], y1 = tk[tk.length - 1], x0 = xs[0], x1 = xs[xs.length - 1];
    const X = v => x + 10 + (v - x0) / (x1 - x0) * (w - 12), Y = v => y + h - 6 - (v - y0) / (y1 - y0) * (h - 8);
    if (opt.band) { doc.setFillColor(226, 238, 220); doc.rect(x + 10, Y(opt.band[1]), w - 12, Y(opt.band[0]) - Y(opt.band[1]), "F"); }
    doc.setLineWidth(0.1); doc.setFontSize(6.5);
    tk.forEach(v => { doc.setDrawColor(225); doc.line(x + 10, Y(v), x + w - 2, Y(v)); col(MUTE); doc.text(String(v), x + 8.5, Y(v) + 1, { align: "right" }); });
    xs.forEach((v, i) => { if (i % (opt.xEvery || 3) === 0) { col(MUTE); doc.text(opt.xFmt ? opt.xFmt(v) : String(v), X(v), y + h - 1.5, { align: "center" }); } });
    series.forEach(s => {
      doc.setDrawColor(...s.c); doc.setLineWidth(s.w || 0.5); doc.setLineDashPattern(s.dash ? [1.2, 0.8] : [], 0);
      for (let i = 1; i < xs.length; i++) if (isFinite(s.y[i - 1]) && isFinite(s.y[i])) doc.line(X(xs[i - 1]), Y(s.y[i - 1]), X(xs[i]), Y(s.y[i]));
    });
    doc.setLineDashPattern([], 0);
    let lx = x + 10; doc.setFontSize(7);
    series.forEach(s => { doc.setDrawColor(...s.c); doc.setLineWidth(0.8); doc.line(lx, y + h + 3, lx + 5, y + h + 3); col(INK); doc.text(clean(s.name), lx + 6, y + h + 4); lx += 10 + doc.getTextWidth(clean(s.name)); });
    col(INK);
  }

  /* ---------------------------------------------------------- build */
  async function build(ctx) {
    const { jsPDF } = g.jspdf, doc = new jsPDF({ unit: "mm", format: "a4" });
    const PW = 210, M = 14, CW = PW - 2 * M; let y = M;
    const { d, site, r } = ctx, unit = ctx.unit || "L", opt = ctx.optR, mo = ctx.moist;
    const need = h => { if (y + h > 284) { doc.addPage(); y = M; } };
    const h1 = (t, keep) => { need(keep || 30); doc.setFont("helvetica", "bold"); doc.setFontSize(13); doc.setTextColor(...INK); doc.text(clean(t), M, y + 5); y += 9; };
    const para = (t, size) => { doc.setFont("helvetica", "normal"); doc.setFontSize(size || 9.5); doc.setTextColor(40, 50, 60);
      const ls = doc.splitTextToSize(clean(t), CW); need(ls.length * 4.4); doc.text(ls, M, y + 3.5); y += ls.length * 4.4 + 2; };
    const table = (head, rows, widths, size) => {
      doc.setFontSize(size || 8.5);
      const line = (cells, bold) => {
        const wr = cells.map((c, i) => doc.splitTextToSize(clean(c), widths[i] - 1.5)), hh = Math.max(...wr.map(w => w.length)) * 3.7 + 1.8; need(hh);
        doc.setFont("helvetica", bold ? "bold" : "normal"); doc.setTextColor(...INK); let x = M;
        wr.forEach((w, i) => { doc.text(w, x + 0.8, y + 3.4); x += widths[i]; }); y += hh; doc.setDrawColor(225); doc.setLineWidth(0.1); doc.line(M, y, M + CW, y);
      };
      line(head, true); rows.forEach(rr => line(rr, false)); y += 3;
    };
    const gng = goNoGo(ctx), mg = TS.weather ? TS.weather.toMGRS(site.lat, site.lon) : null;

    /* page 1 */
    doc.setFillColor(...INK); doc.rect(0, 0, PW, 30, "F");
    doc.setTextColor(255); doc.setFont("helvetica", "bold"); doc.setFontSize(16.5); doc.text("Fluxion: shelter thermal design report", M, 13);
    doc.setFont("helvetica", "normal"); doc.setFontSize(9);
    doc.text(clean(`${ctx.classification || "Defence"} | ${ctx.typeName || "Custom design"} | generated ${new Date().toISOString().replace("T", " ").slice(0, 16)} UTC on this device`), M, 21);
    doc.text("Team AETHERION. No data left the device.", M, 26);
    y = 38;
    // the app's one STATUS (GO / CAUTION / NO-GO) when given, else the report's own GO / NO-GO
    const st = ctx.status, lab = st ? st.label : gng.go ? "GO" : "NO-GO", why = st ? st.reasons.concat(st.warns) : gng.why;
    doc.setFillColor(...(lab === "GO" ? OK : lab === "CAUTION" ? [196, 124, 18] : BAD)); doc.roundedRect(M, y, 46, 16, 2, 2, "F"); doc.setTextColor(255); doc.setFont("helvetica", "bold"); doc.setFontSize(18);
    doc.text(lab, M + 23, y + 10.5, { align: "center" });
    doc.setTextColor(...INK); doc.setFontSize(9.5); doc.setFont("helvetica", "normal");
    doc.text(doc.splitTextToSize(clean(lab === "GO" ? `Holds ${gng.floor} C or more all night with the heater; every check passes.` : (lab === "CAUTION" ? "Usable, with warnings: " : "Not ready: ") + why.join("; ") + "."), CW - 52), M + 52, y + 5); y += 22;
    table(["Identification", ""], [
      ["Location", `${ctx.siteName}: ${f2(site.lat)} N, ${f2(site.lon)} E${mg ? `, MGRS ${mg.text}` : ""}`],
      ["Elevation", `${f0(site.alt)} m (air density ${f2(r.net.rhoAir)} kg/m3, ${f1(TS.engine.pressurePa(site.alt) / 1000)} kPa)`],
      ["Climate case", ctx.climateText || `${ctx.monthName} design day ${f1(site.Tmin)} to ${f1(site.Tmax)} C, solar ${f2(site.H)} kWh/m2.day`],
      ["Shelter", `${f2(d.L)} x ${f2(d.W)} x ${f2(d.H)} m, front ${TS.engine.compass(d.orient)}, roof ${d.pitch || 0} deg, floor ${d.floorMode === "raised" ? "raised on skids" : "on ground"}, ${d.people} occupants`],
      ["Heating", ctx.heaterName || "Kerosene heater"],
    ], [40, CW - 40]);
    table(["Result", "Baseline", opt ? "Optimised" : "", "Basis"], [
      ["Coldest night hour, no heating", `${f1(r.summary.passive.nightMin)} C`, opt ? `${f1(opt.summary.passive.nightMin)} C` : "", "operative temperature"],
      ["Coldest night hour, heated", `${f1(r.summary.heated.nightMin)} C`, opt ? `${f1(opt.summary.heated.nightMin)} C` : "", `heater target ${ctx.ops.setpoint} C`],
      ["Fuel per 24 h", `${f2(r.summary.fuel_L)} ${unit}`, opt ? `${f2(opt.summary.fuel_L)} ${unit}` : "", `${Math.round(ctx.ops.eta * 100)} % efficiency`],
      ["Peak night heat loss", `${f0(peakLoss(r))} W`, opt ? `${f0(peakLoss(opt))} W` : "", "all paths, heated"],
      ["Solar heat into room", `${f1(r.solar.transmitted_kWh + r.solar.opaqueIn_kWh)} kWh/day`, opt ? `${f1(opt.solar.transmitted_kWh + opt.solar.opaqueIn_kWh)} kWh/day` : "", "glass, walls, roof, Trombe"],
      ["Peak CO2", `${f0(r.co2 && r.co2.max)} ppm`, opt && opt.co2 ? `${f0(opt.co2.max)} ppm` : "", "occupants, flue state"],
      ["Structural mass", ctx.log ? `${f0(ctx.log.mass)} kg` : "-", ctx.optLog ? `${f0(ctx.optLog.mass)} kg` : "", "BOQ; water filled on site"],
      ["Cost", ctx.log && ctx.log.costComplete ? `INR ${f0(ctx.log.cost)}` : "rates not entered", ctx.optLog && ctx.optLog.costComplete ? `INR ${f0(ctx.optLog.cost)}` : "", "user-entered unit rates"],
    ], [52, 34, 34, CW - 120]);
    if (ctx.mission && ctx.mission.dur) {
      const md = ctx.mission.dur, u = ctx.mission.units || 1;
      table(["Use", ""], [
        ["Shelter use", md.use === "permanent" ? `Permanent, ${md.years}-year design life` : `Temporary, ${md.days} days in use`],
        ["Shelters needed", `${u} x ${ctx.typeName}`],
        ["Fuel over the period", md.use === "permanent" ? `${f0(md.year)} ${unit} a year (all 12 months modelled), ${f0(md.total)} ${unit} over ${md.years} years` : `${f0(md.total)} ${unit} over ${md.days} days (${Math.ceil(md.total / 20)} jerrycans of 20 L)`],
        ["Extreme cold case", ctx.mission.verify ? `${ctx.mission.verify.ok ? "VERIFIED" : "NOT VERIFIED"}: coldest heated hour ${f1(ctx.mission.verify.heatMin)} C in a 3-day severe cold wave (IMD -6.5 K), no sun, double wind` : "-"],
      ], [40, CW - 40]);
    }
    /* the three results, in numbers */
    {
      const op = r.passive.op, ni = r.night.map((n, i) => (n ? i : -1)).filter(i => i >= 0), iMin = ni.reduce((b, i) => (op[i] < op[b] ? i : b), ni[0] || 0), iMax = op.indexOf(Math.max(...op));
      const keys = Object.keys(r.heated.paths[0]), tot = {}; keys.forEach(k => (tot[k] = r.heated.paths.reduce((a, p) => a + p[k], 0) / 1000 / r.days));
      const loss = keys.reduce((a, k) => a + Math.max(0, tot[k]), 0), dT = r.heated.air.reduce((a, t, i) => a + t - r.amb[i], 0) / r.N;
      h1("Results", 40);
      table(["Output", "Result"], [
        ["1. Inside temperature", `Without heating ${f1(op[iMin])} C at ${String(iMin % 24).padStart(2, "0")}:00 (outside ${f1(r.amb[iMin])} C) to ${f1(op[iMax])} C at ${String(iMax % 24).padStart(2, "0")}:00; with one heater never below ${f1(Math.min(...r.heated.op))} C.`],
        ["2. Heat from the sun", `${f1(r.solar.transmitted_kWh + r.solar.opaqueIn_kWh)} kWh a day into the room: ${f1(r.solar.transmitted_kWh)} through windows, ${f1(r.solar.opaqueIn_kWh)} through walls and roof.`],
        ["3. Heat flow vs inside-outside difference", `${f1(loss)} kWh lost over 24 h with the inside on average ${f1(dT)} K warmer than outside: about ${f0(loss * 1000 / 24 / Math.max(dT, 0.1))} W per K.`],
        ["Fuel", `${f2(r.summary.fuel_L)} ${unit} of kerosene a day per shelter.`],
      ], [52, CW - 52]);
    }
    if (TS.buildup) {
      h1("Layers of walls, roof and floor (outside to inside)", 40);
      TS.buildup.data(d).forEach(e => {
        table([`${e.name}: ${f1(e.area)} m2, U ${f2(e.U)} W/m2K`, "Thickness", "Quantity", "Mass", "Cost INR"],
          e.layers.map((l, i) => [`${i + 1}. ${l.name}`, `${l.mm < 5 ? l.mm.toFixed(1) : Math.round(l.mm)} mm`, l.qty, `${f0(l.mass)} kg`, l.cost != null ? f0(l.cost) : "enter rate"]), [70, 24, 28, 26, CW - 148], 8);
      });
      para(`Prices: Indian market listings (Oct 2026) adjusted by the CPWD building cost index for ${ctx.siteName} (${TS.prices ? TS.prices.factor(TS.app.S.site.id).station : "Delhi"}); user-entered rates replace them.`, 8);
    }
    if (ctx.ansysRuns && ctx.ansysRuns.length) {
      h1("Check in ANSYS (Workbench model, same inputs)", 40);
      table(["Run", "Design sent", "ANSYS coldest", "App coldest", "ANSYS warmest", "App warmest"],
        ctx.ansysRuns.slice(0, 10).map(h => [h.t + (h.mock ? " (practice)" : ""), h.label || `${h.i.L} x ${h.i.W} x ${h.i.H} m`, `${f1(h.aMin)} C`, `${f1(h.pMin)} C`, `${f1(h.aMax)} C`, `${f1(h.pMax)} C`]),
        [30, 56, 24, 24, 24, CW - 158], 8);
      para("ANSYS: parametric box shelter, 48-hour transient, Leh January boundary conditions (contract v1.0). App: the same case solved by the app with every boundary condition from ansys_case_v1.0.json (shell, glass, air, ambient functions, solar tables, -6 C start, min/max over 48 h); nothing is adjusted to match ANSYS. Practice-mode rows repeat the stored real base-case run. In the v1.0 Workbench model the window sun is a fixed heat rate per m3 of air, so it does not follow the window size.", 8.5);
    }
    if (ctx.explainText) { h1("Summary", 20); para(ctx.explainText); }
    if (ctx.alertText) { h1("Weather alert", 20); para(ctx.alertText); }
    if (ctx.twinPng) {
      need(100); h1("The shelter at its site (3D view)", 100);
      try { doc.addImage(ctx.twinPng, "JPEG", M, y, CW, CW * 0.55); y += CW * 0.55 + 4; } catch (e) { para("3D view could not be embedded."); }
    }

    /* page 2 */
    doc.addPage(); y = M; h1("Drawings and specification");
    plan(doc, d, M, y + 4, 96, 64);
    frontElevation(doc, d, M + 114, y + 4, 50, 32);
    endElevation(doc, d, M + 114, y + 54, 50, 32);
    y += 100; y = sections(doc, d, M, y) + 2;
    table(["Component", "Specification"], [
      ["Glazing", `${TS.GLAZING[d.glazing].name}, U ${TS.GLAZING[d.glazing].U}, g ${TS.GLAZING[d.glazing].g}; windows ${f1(Object.values(d.win).reduce((a, b) => a + b, 0))} m2${d.shutter ? ", night shutters" : ""}`],
      ["Trombe wall", d.trombe && d.trombe.area > 0 ? `${f1(d.trombe.area)} m2 of ${TS.MATERIALS[d.trombe.mat].name}, ${Math.round(d.trombe.t * 1000)} mm, behind glazing` : "none"],
      ["Stored heat", d.store && d.store.type !== "none" ? `${TS.STORE[d.store.type].name}, ${d.store.mass} kg` : "none"],
      ["Ventilation", `vents ${(d.vents || {}).low || 0} / ${(d.vents || {}).high || 0} cm2 (low/high)${(d.vents || {}).cross ? ", opposite walls" : ""}; heater ${d.unflued ? "UNFLUED" : "flued"}`],
    ], [36, CW - 36]);

    /* page 3 */
    doc.addPage(); y = M; h1("Hourly thermal and ventilation log");
    const hrs = Array.from({ length: 24 }, (_, i) => i);
    chart(doc, M, y, CW, 62, hrs.map(h => h + 0.5), [
      { name: "Outside", y: r.amb.slice(0, 24), c: GLASS, w: 0.5 },
      { name: "Inside, baseline, no heating", y: r.passive.op.slice(0, 24), c: HEAT, w: 0.8 },
      ...(opt ? [{ name: "Inside, optimised, no heating", y: opt.passive.op.slice(0, 24), c: OK, w: 0.8 }] : []),
    ], { band: [14, 20], xEvery: 3, xFmt: v => String(Math.floor(v)).padStart(2, "0") + ":00" });
    y += 72;
    table(["Hour", "Out C", "Solar W/m2", "In base C", opt ? "In opt C" : "", "Dew pt C", "Infiltr. W", "ACH"],
      hrs.map(i => [String(i).padStart(2, "0") + ":00", f1(r.amb[i]), f0(r.ghi[i]), f1(r.passive.op[i]), opt ? f1(opt.passive.op[i]) : "", mo ? f1(mo.dpIn[i]) : "-", f0(r.heated.paths[i].vent), f2(r.ach[i])]),
      [16, 18, 24, 22, 22, 22, 24, 34], 7.5);
    h1("Ventilation and moisture", 40);
    table(["Item", "Value", "Status"], [
      ["Air changes (leakage, vents, stack, wind)", `${f2(r.airflow.achMin)} to ${f2(r.airflow.achMax)} /h`, r.airflow.achMin < 0.5 && d.heater !== "passive" ? "below 0.5 with a combustion heater: CO risk" : "ok"],
      ["Peak CO2", `${f0(r.co2.max)} ppm`, r.co2.max > 5000 ? "above 8-h limit" : r.co2.max > 1000 ? "stuffy" : "ok"],
      ["Peak indoor relative humidity", mo ? `${f0(mo.maxRH)} %` : "-", mo && mo.maxRH > 80 ? "high" : "ok"],
      ...(mo ? mo.surfaces.filter(s => s.hoursWet > 0).map(s => [`Condensation on ${s.id.replace("_", " ")}`, `${s.hoursWet} h/day${s.hoursFrost ? `, ${s.hoursFrost} h as frost` : ""}`, "risk"]) : []),
      ...(mo ? mo.interstitial.filter(i => i.risk).map(i => [`Inside the ${i.element}`, i.where.join("; "), i.frost ? "hoarfrost risk" : "condensation risk"]) : []),
    ], [70, 50, CW - 120]);

    /* page 4 */
    doc.addPage(); y = M; h1("Bill of materials");
    if (ctx.log) {
      const rates = TS.logistics.cfg().rates;
      table(["Material", "Thick mm", "Qty", "Unit", "Density", "R m2K/W", "Rate INR", "Amount INR"], ctx.log.rows.map(b => [b.item, b.thick ? (b.thick * 1000).toFixed(b.thick < 0.005 ? 1 : 0) : "-",
        b.qty < 10 ? b.qty.toFixed(2) : b.qty.toFixed(1), b.unit, b.rho ? f0(b.rho) : "-", b.R != null ? f2(b.R) : "-", rates[b.key] ? f0(rates[b.key]) : "-", rates[b.key] ? f0(rates[b.key] * b.qty) : "-"]),
        [52, 15, 15, 11, 16, 18, 18, CW - 145], 7.8);
      para(ctx.log.costComplete ? `Total: INR ${f0(ctx.log.cost)}.` : `Rates missing for ${ctx.log.costMissing.length} item(s); enter them on the Logistics stage.`, 9);
      h1("Logistics", 40);
      table(["Item", "Value"], [
        ["Package mass", `${f0(ctx.log.mass)} kg (water for thermal storage filled on site)`],
        ...ctx.log.loads.map(l => [l.name, `${l.trips} load(s) at ${l.payload} kg; fuel for 30 days: ${l.fuelTrips} load(s)`]),
        ["Fuel for 30 days", `${f1(ctx.log.fuelMonth)} ${unit}`],
        ["Assembly", ctx.log.manHours != null ? `${f0(ctx.log.manHours)} man-hours, about ${f1(ctx.log.days)} days for the crew entered` : "enter man-hours per m2 on the Logistics stage"],
      ], [50, CW - 50]);
    }
    if (ctx.apdl) {
      h1("ANSYS APDL starter script (excerpt; untested; full file exported separately)", 40);
      doc.setFont("courier", "normal"); doc.setFontSize(6.6); doc.setTextColor(...INK);
      ctx.apdl.split("\n").filter(l => !/^T[A-Z]+\(\d+,[01]\)=/.test(l)).slice(0, 48).forEach(l => { need(3); doc.text(clean(l).slice(0, 120), M, y + 2.5); y += 2.9; });
      doc.setFont("helvetica", "normal"); y += 3;
    }

    /* remaining */
    doc.addPage(); y = M; h1("Output 2: solar energy collected");
    table(["Surface", "Sun on surface kWh/m2.day", "Through glass kWh/day", "Through wall kWh/day"],
      r.solar.facades.map(f => [`${f.label} wall${f.Aw ? `, ${f1(f.Aw)} m2 glass` : ""}`, f2(f.incidentPerM2_kWh), f.Aw ? f2(f.transmitted_kWh) : "-", f2(f.opaqueIn_kWh)])
        .concat([["Roof", f2(r.solar.roofIncident_kWh / r.net.Af), "-", f2(r.solar.roofIn_kWh)]]).concat(r.solar.trombeIn_kWh ? [["Trombe wall", "-", "-", f2(r.solar.trombeIn_kWh)]] : []), [62, 40, 38, 42]);
    h1("Output 3: heat flow by path, heated");
    const night = r.night.map((n, i) => (n ? i : -1)).filter(i => i >= 0), day = r.night.map((n, i) => (n ? -1 : i)).filter(i => i >= 0);
    const tot = idx => { const t = {}; idx.forEach(i => { for (const k in r.heated.paths[i]) t[k] = (t[k] || 0) + r.heated.paths[i][k] / 1000; }); return t; };
    const tn = tot(night), td = tot(day), mdt = idx => idx.reduce((s, i) => s + r.heated.air[i] - r.amb[i], 0) / Math.max(1, idx.length);
    table(["Path", `Night kWh (mean dT ${f1(mdt(night))} K)`, `Day kWh (mean dT ${f1(mdt(day))} K)`], Object.keys(tn).map(k => [(ctx.pathNames || {})[k] || k, f2(tn[k]), f2(td[k])]), [70, 56, 56]);
    if (mo) { h1("Exterior skin temperature against outside air");
      table(["Surface", "Night, K warmer than air", "Day, K warmer than air"], mo.surfaces.filter(s => isFinite(s.nightSkinContrast)).map(s => [s.id.replace("_", " "), f1(s.nightSkinContrast), f1(s.maxSkinContrast)]), [70, 56, 56]); }
    h1("Design checks");
    table(["Check", "Status", "Detail"], (ctx.checks || []).map(c => [c.title, c.level, c.detail]), [46, 16, CW - 62]);
    if (ctx.sens) { h1("What moves the result"); table(["Variable", "Range tested", "Share", ctx.sens.metric === "fuel" ? `Fuel ${unit}/day` : "Night min C"],
      ctx.sens.rows.map(s => [s.label, s.range, `${Math.round(s.share * 100)} %`, `${f2(s.lo)} to ${f2(s.hi)}`]), [46, 62, 22, 52]); }
    h1("Method and limits", 24);
    para("Hourly single-zone model to EN ISO 13790 (5R1C) with sol-air surfaces and Berdahl-Martin sky temperature (cloud factor when forecast cloud is given); airflow network (ASHRAE leakage, stack and wind through vents) iterated with the thermal model; CO2 and water-vapour balances; surface condensation and simplified Glaser interstitial check (ISO 13788); IS 875 Part 4 snow coefficient; Sphere and WHO thresholds. One well-mixed zone, heating only. Material values are typical; the app's Method tab lists every source and limit.", 8.5);
    return doc;
  }

  async function save(doc, name) {
    const cap = g.Capacitor && g.Capacitor.Plugins;
    if (cap && cap.Filesystem) { await cap.Filesystem.writeFile({ path: name, data: doc.output("datauristring").split(",")[1], directory: "DOCUMENTS" }); return "Documents/" + name; }
    doc.save(name); return name;
  }
  function boqCSV(rows) {
    const rt = TS.logistics.cfg().rates;
    return "item,thickness_mm,quantity,unit,density,R_m2K_W,rate_INR,amount_INR\r\n" + rows.map(r => `"${r.item}",${r.thick ? (r.thick * 1000).toFixed(1) : ""},${r.qty.toFixed(3)},${r.unit},${r.rho || ""},${r.R != null ? r.R.toFixed(3) : ""},${rt[r.key] || ""},${rt[r.key] ? (rt[r.key] * r.qty).toFixed(0) : ""}`).join("\r\n") + "\r\n";
  }

  TS.report = { build, save, boqCSV, goNoGo, peakLoss, clean };
})(typeof window !== "undefined" ? window : globalThis);
