/* The ANSYS Workbench case (Shelter_General.wbpj, contract v1.0) solved by the
   app, so "App - ANSYS" compares like with like. Every boundary condition is
   taken from ansys_case_v1.0.json (ThermaSync_ANSYS_alignment kit):
   - box shell of one uniform layer (T_INS, K_INS, RHO_INS, CP_INS) for walls,
     roof and floor; indoor air body (rho 0.87, cp 1005, k_eff 10: well mixed);
     window = conduction-only glass block (thickness T_INS, k 0.53, rho 200, cp 840)
   - walls and window: h 15 to -5.9 + 5.4 cos(2 pi (t - 54000)/86400)
     roof: h 18.5 to -10.84 + 4.38 cos(...) (sky folded in); floor underside h 2 to 0 C
   - absorbed solar per face from the pvlib clear-sky tables (Leh, 15 Jan), linear
     between clock hours; window sun 0.8 x south irradiance x window area put
     straight into the air body (as built: the base case's W/m3 table, see solve());
     no occupants, no ventilation
   - start -6 C everywhere, 48 h; T_AIR_MIN / MAX over the whole run.
   Numerics (the only modelling choices, fixed, not fitted to ANSYS): each face is
   a 1-D slab (nodes on both surfaces, converged at 8 cells); the air body couples to
   each inner surface with k_eff / (V/A), the mean distance from a surface into a
   well-mixed body; explicit time steps sized for stability. Rx_* are the
   convection reactions: heat into the body from the surrounding fluid, W. */
(function (g) {
  "use strict";
  const TS = g.TS = g.TS || {};
  const CASE = {
    ambWall: t => -5.9 + 5.4 * Math.cos(2 * Math.PI * (t - 54000) / 86400),
    ambRoof: t => -10.84 + 4.38 * Math.cos(2 * Math.PI * (t - 54000) / 86400),
    hWall: 15, hRoof: 18.5, hFloor: 2, tGround: 0, t0: -6, duration: 172800,
    air: { k: 10, rho: 0.87, cp: 1005 }, glass: { k: 0.53, rho: 200, cp: 840 },
    sill: 0.9, tauWin: 0.8, absOpaque: 0.6,
    // window sun as entered in the Workbench model: W/m3 of the AIR body (base case, 47.424 m3)
    winW_m3: [0, 0, 0, 0, 0, 0, 0, 0, 11.0, 22.9, 30.3, 34.9, 37.2, 37.2, 34.8, 30.1, 22.6, 10.4, 0, 0, 0, 0, 0, 0],
    flux: {   // absorbed W/m2 (already x 0.6), clock hours 0..23
      ROOF: [0, 0, 0, 0, 0, 0, 0, 0, 41.4, 180.0, 302.2, 389.5, 434.5, 433.8, 387.4, 298.9, 175.7, 37.4, 0, 0, 0, 0, 0, 0],
      SOUTH: [0, 0, 0, 0, 0, 0, 0, 0, 217.0, 452.5, 599.5, 690.0, 735.3, 734.4, 687.5, 595.1, 446.1, 205.8, 0, 0, 0, 0, 0, 0],
      EAST: [0, 0, 0, 0, 0, 0, 0, 0, 362.3, 527.1, 493.0, 381.1, 229.0, 143.9, 127.2, 96.1, 56.5, 12.0, 0, 0, 0, 0, 0, 0],
      WEST: [0, 0, 0, 0, 0, 0, 0, 0, 13.3, 57.9, 97.2, 128.0, 144.2, 234.9, 386.0, 496.2, 526.8, 349.1, 0, 0, 0, 0, 0, 0],
      NORTH: [0, 0, 0, 0, 0, 0, 0, 0, 13.3, 57.9, 97.2, 128.0, 144.2, 143.9, 127.2, 96.1, 56.5, 12.0, 0, 0, 0, 0, 0, 0],
    },
  };
  const at = (tab, t) => { const h = (t / 3600) % 24, i = Math.floor(h), f = h - i; return tab[i] * (1 - f) + tab[(i + 1) % 24] * f; };

  function solve(i, opts) {
    const o = opts || {}, NN = o.nodes || 8;
    const T = i.T_INS, Lin = i.L - 2 * T, Win = i.W - 2 * T, Hin = i.H - 2 * T, Awin = i.WIN_W * i.WIN_H;
    const V = Lin * Win * Hin, Ain = 2 * (Lin * Win + Lin * Hin + Win * Hin), hIn = CASE.air.k / (V / Ain);
    const shell = { k: i.K_INS, rc: i.RHO_INS * i.CP_INS }, gl = { k: CASE.glass.k, rc: CASE.glass.rho * CASE.glass.cp };
    // faces: outer area, inner area, material, outer BC
    const F = [
      { id: "Wall", name: "south", Ao: i.L * i.H - Awin, Ai: Lin * Hin - Awin, m: shell, h: CASE.hWall, amb: CASE.ambWall, q: CASE.flux.SOUTH },
      { id: "Wall", name: "north", Ao: i.L * i.H, Ai: Lin * Hin, m: shell, h: CASE.hWall, amb: CASE.ambWall, q: CASE.flux.NORTH },
      { id: "Wall", name: "east", Ao: i.W * i.H, Ai: Win * Hin, m: shell, h: CASE.hWall, amb: CASE.ambWall, q: CASE.flux.EAST },
      { id: "Wall", name: "west", Ao: i.W * i.H, Ai: Win * Hin, m: shell, h: CASE.hWall, amb: CASE.ambWall, q: CASE.flux.WEST },
      { id: "Roof", Ao: i.L * i.W, Ai: Lin * Win, m: shell, h: CASE.hRoof, amb: CASE.ambRoof, q: CASE.flux.ROOF },
      // contract 1.1: FLOOR 1 = raised (h 15 to the wall ambient), 0 = on the ground (h 2 to 0 C)
      i.FLOOR >= 0.5 ? { id: "Floor", Ao: i.L * i.W, Ai: Lin * Win, m: shell, h: CASE.hWall, amb: CASE.ambWall, q: null }
        : { id: "Floor", Ao: i.L * i.W, Ai: Lin * Win, m: shell, h: CASE.hFloor, amb: () => CASE.tGround, q: null },
      { id: "Window", Ao: Awin, Ai: Awin, m: gl, h: CASE.hWall, amb: CASE.ambWall, q: null },
    ];
    // NN + 1 nodes per slab, the first on the outer surface and the last on the inner
    // surface (half-cells at both ends): second-order accurate in the slab
    const dx = T / NN, NP = NN + 1;
    F.forEach(f => {
      f.A = (f.Ao + f.Ai) / 2;                        // conduction area through the slab
      f.T = new Float64Array(NP).fill(CASE.t0);
      f.C = new Float64Array(NP).fill(f.m.rc * f.A * dx); f.C[0] /= 2; f.C[NN] /= 2;   // J/K per node
      f.G = f.m.k * f.A / dx;                          // W/K between nodes
      f.Gout = f.h * f.Ao;                             // outer fluid -> outer surface node
      f.Gin = hIn * f.Ai;                              // inner surface node -> air
    });
    const Cair = CASE.air.rho * CASE.air.cp * V;
    let Ta = CASE.t0;
    // stable explicit step
    let dt = 60;
    F.forEach(f => { dt = Math.min(dt, 0.45 * f.C[1] / (2 * f.G), 0.45 * f.C[0] / (f.G + f.Gout), 0.45 * f.C[NN] / (f.G + f.Gin)); });
    dt = Math.min(dt, 0.45 * Cair / F.reduce((s, f) => s + f.Gin, 0));
    // extremes are taken at result times only: ANSYS stores no result at t = 0 (first stored step 3600 s),
    // so the initial -6 C instant is excluded. Optional: longer run, min/max over the last day only.
    const dur = o.days ? o.days * 86400 : CASE.duration, from = o.lastDay ? dur - 86400 : 3600;
    const steps = Math.ceil(dur / dt); dt = dur / steps;
    let tMin = Infinity, tMax = -Infinity;
    const rx = {}; ["Wall", "Roof", "Floor", "Window"].forEach(k => (rx[k] = { min: Infinity, max: -Infinity }));
    const sample = Math.max(1, Math.round(60 / dt)), hourly = [];
    for (let s = 0; s <= steps; s++) {
      const t = s * dt;
      if (t >= from - 1e-6) { if (Ta < tMin) tMin = Ta; if (Ta > tMax) tMax = Ta; }
      // window sun into the air body: 0.8 x south irradiance (SOUTH/0.6) x window area
      /* window sun into the air body: 0.8 x south irradiance x window area (contract 1.0.1:
         the bridge sets Solar_Window from WIN_W x WIN_H and the air volume for every run).
         winPerM3: true reproduces runs made before 4 Oct 2026, when Solar_Window was the
         base case's fixed W/m3 table. */
      const qWin = o.winPerM3 ? at(CASE.winW_m3, t) * V : CASE.tauWin * (at(CASE.flux.SOUTH, t) / CASE.absOpaque) * Awin;
      // contract 1.1: occupant / equipment heat into the air, and air leakage to the wall ambient
      const Gleak = CASE.air.rho * CASE.air.cp * V * (i.ACH || 0) / 3600;
      let qAir = qWin + (i.Q_INT || 0) - Gleak * (Ta - CASE.ambWall(t)); const sums = { Wall: 0, Roof: 0, Floor: 0, Window: 0 };
      const dT = F.map(f => {
        const n = f.T, d = new Float64Array(NP);
        const qOut = f.Gout * (f.amb(t) - n[0]) + (f.q ? at(f.q, t) * f.Ao : 0);
        sums[f.id] += f.Gout * (f.amb(t) - n[0]);     // convection from the fluid into the outer surface = h A (T_fluid - T_surface)
        for (let j = 0; j < NP; j++) {
          let q = 0;
          if (j === 0) q += qOut; else q += f.G * (n[j - 1] - n[j]);
          if (j === NN) { const qi = f.Gin * (Ta - n[j]); q += qi; qAir -= qi; } else q += f.G * (n[j + 1] - n[j]);
          d[j] = q * dt / f.C[j];
        }
        return d;
      });
      if (s % sample === 0 && t >= from - 1e-6) { for (const k in sums) { rx[k].min = Math.min(rx[k].min, sums[k]); rx[k].max = Math.max(rx[k].max, sums[k]); } }
      if (s % Math.round(3600 / dt) === 0) hourly.push(Ta);
      if (s === steps) break;
      F.forEach((f, k) => { for (let j = 0; j < NP; j++) f.T[j] += dT[k][j]; });
      Ta += qAir * dt / Cair;
    }
    return { T_AIR_MIN: tMin, T_AIR_MAX: tMax, Rx: rx, hourly, dt, hIn };
  }
  TS.ansysCase = { CASE, solve };
  if (typeof module !== "undefined") module.exports = TS;
})(typeof window !== "undefined" ? window : globalThis);
