/* Pre-deployment sync and the cold-surge alert.
   Open-Meteo (open-meteo.com, free, no key): hourly forecast from global
   weather models for the next 7 days plus the past 7 days, and terrain
   elevation (Copernicus GLO-90 DEM). Fetched while online, cached in
   IndexedDB, then used offline.

   The alert applies the India Meteorological Department's cold-wave
   departure criteria to that forecast (not a probability):
     SEVERE  forecast daily minimum 6.5 K or more below the normal minimum
             (IMD "severe cold wave" departure)
     WATCH   4.5 K or more below normal (IMD "cold wave" departure), or wind
             above 15 m/s
     STABLE  otherwise
   Consecutive dull days (solar under half normal) are reported alongside.
   "Normal" is the NASA POWER climatology of the site (lapse-corrected).
   The forecast is also run through the thermal engine hour by hour, so the
   alert says what the shelter will do, not only what the weather does. */
(function (g) {
  "use strict";
  const TS = g.TS;
  const FC = "https://api.open-meteo.com/v1/forecast";
  const EL = "https://api.open-meteo.com/v1/elevation";

  /* ---------------------------------------------------------- IndexedDB */
  const store = (() => {
    let dbp = null;
    const open = () => dbp || (dbp = new Promise((res, rej) => {
      if (typeof indexedDB === "undefined") return rej(new Error("no IndexedDB"));
      const q = indexedDB.open("thermashelter", 1);
      q.onupgradeneeded = () => q.result.createObjectStore("kv");
      q.onsuccess = () => res(q.result); q.onerror = () => rej(q.error);
    }));
    const tx = (mode, fn) => open().then(db => new Promise((res, rej) => { const t = db.transaction("kv", mode), s = t.objectStore("kv"), r = fn(s); t.oncomplete = () => res(r && r.result); t.onerror = () => rej(t.error); }));
    return {
      async get(k) { try { return await tx("readonly", s => s.get(k)); } catch (e) { try { return JSON.parse(localStorage.getItem("ts.kv." + k)); } catch (x) { return null; } } },
      async set(k, v) { try { await tx("readwrite", s => s.put(v, k)); } catch (e) { try { localStorage.setItem("ts.kv." + k, JSON.stringify(v)); } catch (x) {} } },
    };
  })();

  /* ---------------------------------------------------------- fetch */
  async function fetchForecast(lat, lon, fetchFn) {
    const f = fetchFn || g.fetch.bind(g);
    const url = `${FC}?latitude=${lat}&longitude=${lon}&hourly=temperature_2m,relative_humidity_2m,wind_speed_10m,shortwave_radiation,cloud_cover` +
      `&wind_speed_unit=ms&timezone=Asia%2FKolkata&past_days=7&forecast_days=7`;
    const r = await f(url); if (!r.ok) throw new Error("Open-Meteo forecast answered " + r.status);
    return parseForecast(await r.json());
  }
  /* Open-Meteo radiation is the mean over the preceding hour, so the value
     stamped hh+1:00 belongs to our hour hh. */
  function parseForecast(j) {
    const h = j.hourly, n = h.time.length - 1, hours = [];
    for (let i = 0; i < n; i++) hours.push({ time: h.time[i], T: h.temperature_2m[i], RH: h.relative_humidity_2m[i], ws: h.wind_speed_10m[i],
      GHI: Math.max(0, h.shortwave_radiation[i + 1] || 0), cloud: (h.cloud_cover[i] || 0) / 100 });
    const start = hours.findIndex(x => x.time.endsWith("T00:00"));
    const whole = hours.slice(start, start + Math.floor((hours.length - start) / 24) * 24);
    return { elevation: j.elevation, fetched: new Date().toISOString(), hours: whole };
  }
  async function fetchElevation(points, fetchFn) {
    const f = fetchFn || g.fetch.bind(g), out = [];
    for (let i = 0; i < points.length; i += 100) {
      if (i) await new Promise(r => setTimeout(r, 400));
      const ch = points.slice(i, i + 100);
      const r = await f(`${EL}?latitude=${ch.map(p => p[0].toFixed(5)).join(",")}&longitude=${ch.map(p => p[1].toFixed(5)).join(",")}`);
      if (!r.ok) throw new Error("Open-Meteo elevation answered " + r.status);
      const j = await r.json(); out.push(...j.elevation);
    }
    return out;
  }

  /* ---------------------------------------------------------- alert */
  function days(fc, siteAlt) {
    const adj = fc.elevation != null && siteAlt != null ? 6.5 * (fc.elevation - siteAlt) / 1000 : 0;
    const out = [];
    for (let d = 0; d < fc.hours.length / 24; d++) {
      const hs = fc.hours.slice(d * 24, d * 24 + 24);
      out.push({ date: hs[0].time.slice(0, 10), tmin: Math.min(...hs.map(x => x.T)) + adj, tmax: Math.max(...hs.map(x => x.T)) + adj,
        tmean: hs.reduce((s, x) => s + x.T, 0) / 24 + adj, wmax: Math.max(...hs.map(x => x.ws)), ghi: hs.reduce((s, x) => s + x.GHI, 0) / 1000,
        cloud: hs.reduce((s, x) => s + x.cloud, 0) / 24, future: new Date(hs[0].time) >= new Date(new Date().toISOString().slice(0, 10)) });
    }
    return { days: out, lapseAdj: adj };
  }
  function normals(rec, month, alt) {
    const lapse = 6.5 * (rec.cell.elev - alt) / 1000;
    const tmin = rec.TMIN ? rec.TMIN[month] + lapse : rec.T2M[month] + lapse - 6;
    return { tmin, tmean: rec.T2M[month] + lapse, ghi: rec.GHI[month] };
  }
  function alert(ds, nrm) {
    let level = "STABLE", reasons = [], dull = 0, worst = null;
    for (const d of ds.filter(x => x.future)) {
      d.anom = d.tmin - nrm.tmin;
      dull = d.ghi < 0.5 * nrm.ghi ? dull + 1 : 0;
      if (!worst || d.anom < worst.anom) worst = d;
      if (d.anom <= -6.5) { level = "SEVERE"; reasons.push(`${d.date}: low ${d.tmin.toFixed(1)} °C, ${(-d.anom).toFixed(1)} K below normal${dull >= 2 ? `, ${dull} dull days in a row` : ""}`); }
      else if ((d.anom <= -4.5 || d.wmax > 15) && level !== "SEVERE") { level = "WATCH"; reasons.push(`${d.date}: ${d.anom <= -4.5 ? `low ${d.tmin.toFixed(1)} °C (${(-d.anom).toFixed(1)} K below normal)` : ""}${d.wmax > 15 ? ` wind ${d.wmax.toFixed(0)} m/s` : ""}`); }
    }
    const past = ds.filter(x => !x.future).map(x => x.tmean), steps = past.slice(1).map((v, i) => v - past[i]);
    const vol = steps.length ? Math.sqrt(steps.reduce((s, v) => s + v * v, 0) / steps.length) : null;
    return { level, reasons, worst, volatility: vol };
  }
  /* run the 14 days (past 7 + next 7) through the engine */
  function simulateForecast(design, site, ops, fc) {
    const adj = fc.elevation != null ? 6.5 * (fc.elevation - site.alt) / 1000 : 0;
    const hourly = fc.hours.map(x => ({ T: x.T + adj, GHI: x.GHI, ws: x.ws, cloud: x.cloud, RH: x.RH }));
    const r = TS.engine.simulate(design, Object.assign({}, site, { hourly, doy: dayOfYear(fc.hours[0].time) }), Object.assign({}, ops, { withSolarFraction: false }));
    const perDay = [];
    for (let d = 0; d < r.N / 24; d++) {
      const a = d * 24, b = a + 24, sl = arr => arr.slice(a, b);
      perDay.push({ date: fc.hours[a].time.slice(0, 10), out: Math.min(...sl(r.amb)), pas: Math.min(...sl(r.passive.op)), heat: Math.min(...sl(r.heated.op)),
        fuel: sl(r.heated.phi).reduce((s, v) => s + v, 0) / 1000 / (r.ops.kwhPerL * r.ops.eta), unmet: sl(r.heated.unmet).filter(Boolean).length });
    }
    return { r, perDay };
  }
  function dayOfYear(iso) { const d = new Date(iso.slice(0, 10) + "T00:00:00Z"); return Math.floor((d - Date.UTC(d.getUTCFullYear(), 0, 0)) / 864e5); }

  /* ---------------------------------------------------------- MGRS (WGS84) */
  function toMGRS(lat, lon) {
    if (lat < -80 || lat > 84) return null;
    const a = 6378137, f = 1 / 298.257223563, e2 = f * (2 - f), ep2 = e2 / (1 - e2), k0 = 0.9996;
    const zone = Math.floor((lon + 180) / 6) + 1, lon0 = (zone - 1) * 6 - 180 + 3;
    const p = lat * Math.PI / 180, l = (lon - lon0) * Math.PI / 180;
    const N = a / Math.sqrt(1 - e2 * Math.sin(p) ** 2), T = Math.tan(p) ** 2, C = ep2 * Math.cos(p) ** 2, A = Math.cos(p) * l;
    const M = a * ((1 - e2 / 4 - 3 * e2 ** 2 / 64 - 5 * e2 ** 3 / 256) * p - (3 * e2 / 8 + 3 * e2 ** 2 / 32 + 45 * e2 ** 3 / 1024) * Math.sin(2 * p)
      + (15 * e2 ** 2 / 256 + 45 * e2 ** 3 / 1024) * Math.sin(4 * p) - (35 * e2 ** 3 / 3072) * Math.sin(6 * p));
    const E = k0 * N * (A + (1 - T + C) * A ** 3 / 6 + (5 - 18 * T + T * T + 72 * C - 58 * ep2) * A ** 5 / 120) + 500000;
    let Nn = k0 * (M + N * Math.tan(p) * (A * A / 2 + (5 - T + 9 * C + 4 * C * C) * A ** 4 / 24 + (61 - 58 * T + T * T + 600 * C - 330 * ep2) * A ** 6 / 720));
    if (lat < 0) Nn += 1e7;
    const band = "CDEFGHJKLMNPQRSTUVWX"[Math.min(19, Math.floor((lat + 80) / 8))];
    const cols = ["ABCDEFGH", "JKLMNPQR", "STUVWXYZ"][(zone - 1) % 3], col = cols[Math.floor(E / 1e5) - 1];
    const row = "ABCDEFGHJKLMNPQRSTUV"[(Math.floor(Nn / 1e5) + (zone % 2 === 0 ? 5 : 0)) % 20];
    const pad = v => String(Math.floor(v % 1e5)).padStart(5, "0");
    return { zone, band, text: `${zone}${band} ${col}${row} ${pad(E)} ${pad(Nn)}`, E, N: Nn };
  }

  /* approximate coordinates; Sync fetches climate, elevation and terrain */
  const PRESETS = [
    { name: "Leh, Ladakh", lat: 34.1526, lon: 77.5771 }, { name: "Siachen sector (approx.)", lat: 35.42, lon: 77.11 },
    { name: "Tawang, Arunachal", lat: 27.5860, lon: 91.8590 }, { name: "Thar Desert, Jaisalmer", lat: 26.9157, lon: 70.9083 },
    { name: "Uttarkashi flood zone", lat: 30.7268, lon: 78.4354 },
  ];

  TS.weather = { store, fetchForecast, parseForecast, fetchElevation, days, normals, alert, simulateForecast, toMGRS, PRESETS, dayOfYear };
  if (typeof module !== "undefined") module.exports = TS;
})(typeof window !== "undefined" ? window : globalThis);
