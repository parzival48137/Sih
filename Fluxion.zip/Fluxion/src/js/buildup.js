/* "Layers of this design": every layer of walls, roof and floor, outside to
   inside, with thickness, quantity, mass and cost for the selected region.
   Used on Mission (step 3) and Design, and in the report. */
(function (g) {
  "use strict";
  const TS = g.TS;
  const EL = [["wall", "Walls"], ["roof", "Roof"], ["floor", "Floor"]];
  const f0 = v => (v == null || !isFinite(v) ? "–" : Math.round(v).toLocaleString("en-IN"));
  const qty = r => (r.unit === "m2" ? `${r.qty.toFixed(1)} m²` : `${r.qty < 1 ? r.qty.toFixed(2) : r.qty.toFixed(1)} m³`);

  /* plain data, for the report */
  function data(d) {
    const rows = TS.logistics.boq(d), E = TS.engine;
    return EL.map(([el, name]) => {
      const ls = rows.filter(r => r.el === el), Rsum = E.constructionR(d[el], TS.MATERIALS), U = 1 / (E.RSI[el] + Rsum + (el === "floor" ? 0.5 : 0.04));
      return { el, name, area: ls.length ? ls[0].area : 0, U, layers: ls.map(r => {
        const rate = TS.logistics.rateFor(r.key);
        return { name: TS.MATERIALS[r.mat] ? TS.MATERIALS[r.mat].name : r.mat, mm: r.thick * 1000, qty: qty(r), mass: r.mass, cost: rate.rate ? rate.rate * r.qty : null, src: rate.src };
      }) };
    });
  }
  function html(d, opts) {
    const o = opts || {}, all = data(d);
    let total = 0, priced = true, mass = 0;
    const body = all.map(e => `<tr class="elhead"><th colspan="5">${e.name} <small>outside → inside · ${e.area.toFixed(1)} m² · U ${e.U.toFixed(2)} W/m²K</small></th></tr>` +
      e.layers.map((l, i) => { if (l.cost != null) total += l.cost; else priced = false; mass += l.mass;
        return `<tr><td>${i + 1}. ${l.name}</td><td>${l.mm < 5 ? l.mm.toFixed(1) : Math.round(l.mm)} mm</td><td>${l.qty}</td><td>${f0(l.mass)} kg</td><td>${l.cost != null ? "₹ " + f0(l.cost) : "<small>enter rate</small>"}</td></tr>`; }).join("")).join("");
    const region = TS.app && TS.app.siteRec ? TS.app.siteRec().name : "", fct = TS.prices && TS.app ? TS.prices.factor(TS.app.S.site.id) : null;
    return `<div class="tablewrap"><table class="grid buildup"><tr><th class="l">Layer</th><th>Thickness</th><th>Quantity</th><th>Mass</th><th>Cost</th></tr>${body}` +
      `<tr class="tot"><td>Total, one shelter</td><td></td><td></td><td>${f0(mass)} kg</td><td>₹ ${f0(total)}${priced ? "" : "+"}</td></tr></table></div>` +
      (o.note === false ? "" : `<p class="note keep">Prices for ${region}${fct ? `: ${fct.station}, ×${fct.f.toFixed(2)} of Delhi` : ""}. "Enter rate" items and your own rates: More tools › Materials & transport.</p>`);
  }
  TS.buildup = { data, html };
})(typeof window !== "undefined" ? window : globalThis);
