/* Pipeline stages 01-05, themes, heating systems, moisture checks, Pareto
   comparison, logistics and the verification report. */
(function () {
  "use strict";
  const TS = window.TS, A = TS.app, C = TS.charts, W = TS.weather, L = TS.logistics, $ = id => document.getElementById(id);
  const clone = o => JSON.parse(JSON.stringify(o));
  const f0 = v => (v == null || !isFinite(v) ? "–" : String(Math.round(v)));
  const f1 = v => (v == null || !isFinite(v) ? "–" : (+v).toFixed(1)).replace(/^-/, "−");
  const f2 = v => (v == null || !isFinite(v) ? "–" : (+v).toFixed(2)).replace(/^-/, "−");
  const HKEY = "thermashelter.theme";

  /* ---------------------------------------------------------- theme */
  function applyTheme() {
    const t = $("theme").value, prof = document.documentElement.dataset.profile || "relief";
    const eff = t === "auto" ? (prof === "defence" ? "tactical" : "relief") : t === "field" ? "light" : t;
    document.documentElement.dataset.theme = eff;
    try { localStorage.setItem(HKEY, t); } catch (e) {}
    if (A.R && A.S.ui.tab === "design") setTimeout(() => A.changed(), 0);   // redraw charts in the new colours
  }
  try { $("theme").value = localStorage.getItem(HKEY) || "auto"; } catch (e) {}
  $("theme").addEventListener("change", applyTheme);
  new MutationObserver(() => { if ($("theme").value === "auto") applyTheme(); }).observe(document.documentElement, { attributes: true, attributeFilter: ["data-profile"] });
  applyTheme();

  /* ---------------------------------------------------------- stepper */
  let step = null;
  function markStep() {
    const tab = A.S.ui.tab;
    document.querySelectorAll(".stepper button").forEach(b => {
      const on = b.dataset.tab === tab && (tab !== "design" || b.dataset.step === (step || "inputs"));
      b.classList.toggle("on", on); b.setAttribute("aria-current", on ? "step" : "false");
    });
  }
  document.querySelectorAll(".stepper button").forEach(b => b.addEventListener("click", () => {
    step = b.dataset.step; A.showTab(b.dataset.tab);
    if (b.dataset.tab === "design") {
      const pane = step === "results" ? "results" : "inputs", sw = document.querySelector(`.mobileswitch button[data-pane=${pane}]`);
      if (getComputedStyle(document.querySelector(".mobileswitch")).display !== "none") sw.click();
      else document.getElementById(pane).scrollIntoView({ behavior: "smooth", block: "start" });
    }
    markStep();
  }));
  const _show = A.showTab;
  TS.app.showTab = t => { _show(t); if (t === "logistics") renderLogistics(); if (t === "site") renderSync(); markStep(); };
  document.querySelectorAll(".tabs button").forEach(b => b.addEventListener("click", markStep));

  /* ---------------------------------------------------------- heating systems */
  const HT = L.HEATERS;
  $("heater").innerHTML = Object.entries(HT).map(([k, h]) => `<option value="${k}">${h.name}</option>`).join("");
  $("heater").value = A.S.ops.heater || "bukhari";
  $("heater").addEventListener("change", e => {
    const h = HT[e.target.value]; Object.assign(A.S.ops, { heater: e.target.value, eta: h.eta, kwhPerL: h.kwh, burnMax: h.max });
    A.S.design.heater = e.target.value;
    $("eta").value = Math.round(h.eta * 100); $("kwhl").value = h.kwh; $("burn").value = h.max; A.changed();
  });
  const heaterNow = () => HT[A.S.ops.heater || "bukhari"];

  /* ---------------------------------------------------------- moisture + extra checks */
  let extra = [], moist = null;
  function afterRun(R) {
    if (!R || !R.elems) return;
    const d = A.S.design, h = A.S.ops.heater || "bukhari", fuelKey = h === "bukhari" ? "kerosene" : null;
    moist = TS.moisture.analyse(R, d, fuelKey, A.ops());
    const wet = moist.surfaces.filter(s => s.hoursWet > 0), inter = moist.interstitial.filter(i => i.risk);
    const badge = (t, cls) => `<span class="badge ${cls}">${t}</span>`;
    $("moistBadges").innerHTML = badge(`Indoor RH peak ${f0(moist.maxRH)} %`, moist.maxRH > 80 ? "warn" : "ok") +
      badge(wet.length ? `Surface condensation on ${wet.length} surface(s)` : "No surface condensation", wet.length ? "bad" : "ok") +
      badge(inter.length ? `Inside-wall moisture risk: ${inter.map(i => i.element).join(", ")}` : "No inside-wall moisture", inter.length ? "warn" : "ok") +
      badge(`Air changes ${f2(R.airflow.achMin)}–${f2(R.airflow.achMax)} /h`, R.airflow.achMin < 0.5 && h !== "passive" ? "bad" : "ok");
    $("moistTable").innerHTML = `<tr><th class="l">Surface</th><th>Coldest inner surface</th><th>Hours wet</th><th>Hours frost</th><th>Night skin vs air</th></tr>` +
      moist.surfaces.map(s => `<tr><td>${(A.pathNames()[s.id] || s.id)}</td><td>${f1(s.minTsi)} °C</td><td>${s.hoursWet}</td><td>${s.hoursFrost}</td><td>${isFinite(s.nightSkinContrast) ? f1(s.nightSkinContrast) + " K" : "–"}</td></tr>`).join("");
    extra = [];
    if (h !== "passive" && R.airflow.achMin < 0.5)
      extra.push({ id: "co", level: "fail", title: "Carbon monoxide asphyxiation risk", detail: `A combustion heater with air changes falling to ${f2(R.airflow.achMin)} an hour: below 0.5 there is too little dilution if the flue leaks or backdrafts. Add vents.`,
        fix: { label: "Add two 150 cm² vents", apply: x => { x.vents = Object.assign({}, x.vents, { low: Math.max((x.vents || {}).low || 0, 150), high: Math.max((x.vents || {}).high || 0, 150) }); return x; } } });
    if (wet.length) extra.push({ id: "dew", level: wet.some(s => s.hoursFrost) ? "fail" : "warn", title: wet.some(s => s.hoursFrost) ? "Hoarfrost on inside surfaces" : "Condensation on inside surfaces",
      detail: wet.map(s => `${A.pathNames()[s.id] || s.id}: ${s.hoursWet} h a day below the indoor dew point${s.hoursFrost ? `, ${s.hoursFrost} h as frost` : ""} (coldest ${f1(s.minTsi)} °C)`).join("; ") + ". More insulation or more ventilation removes it." });
    if (inter.length) extra.push({ id: "glaser", level: inter.some(i => i.frost) ? "fail" : "warn", title: inter.some(i => i.frost) ? "Hoarfrost inside the insulation" : "Condensation inside the wall",
      detail: inter.map(i => `${i.element}: ${i.where.join("; ")}`).join(". ") + ". A vapour barrier on the warm (room) side stops indoor moisture reaching the cold layers.",
      fix: { label: "Add a vapour barrier on the room side", apply: x => { for (const el of ["wall", "roof"]) if (x[el][x[el].length - 1].mat !== "pesheet") x[el].push({ mat: "pesheet", t: 0.0002 }); return x; } } });
    const host = $("checksList");
    host.insertAdjacentHTML("afterbegin", extra.map((c, i) => `<div class="check ${c.level}"><span class="dot"></span><div><b>${c.title}</b><p>${c.detail}</p>${c.fix ? `<button type="button" class="ghost small" data-xfix="${i}">${c.fix.label}</button>` : ""}</div></div>`).join(""));
    host.querySelectorAll("[data-xfix]").forEach(b => b.onclick = () => { A.S.design = extra[+b.dataset.xfix].fix.apply(clone(A.S.design)); A.syncInputs(); A.changed(); A.toast("Applied: " + extra[+b.dataset.xfix].fix.label); });
  }
  const _after = TS.uiplus.afterRun;
  TS.uiplus.afterRun = R => { _after(R); afterRun(R); };
  if (A.R) afterRun(A.R);

  /* ---------------------------------------------------------- 04 Pareto */
  let par = null, parOptR = null;
  const fuelUnit = () => (heaterNow().unit === "-" ? "L" : heaterNow().unit);
  $("parRun").addEventListener("click", () => {
    $("parCards").innerHTML = `<p class="note"><span class="spin"></span> Running 125 designs…</p>`;
    setTimeout(() => {
      const site = A.buildSite(), ops = A.ops(), t0 = performance.now();
      par = TS.optimise.pareto(A.S.design, site, ops, L.costFn);
      const ms = performance.now() - t0;
      $("parObj").textContent = par.objective === "cost" ? "cost" : "transported mass (enter all unit rates to use cost)";
      if (!par.knee) { $("parCards").innerHTML = `<p class="note">None of the 125 designs lets the heater hold the target; enlarge the heater or change the envelope.</p>`; return; }
      const baseR = TS.airflow.simulate(A.S.design, site, ops, "kerosene"); parOptR = TS.airflow.simulate(par.knee.d, site, ops, "kerosene");
      const bL = L.summary(A.S.design, baseR.summary.fuel_L), oL = L.summary(par.knee.d, parOptR.summary.fuel_L);
      const card = (title, R, lg, cls) => `<div class="card ${cls}"><h3>${title}</h3>
        <div class="kv"><span>Peak night heat loss</span><b>${f0(TS.report.peakLoss(R))}<small> W</small></b></div>
        <div class="kv"><span>Fuel</span><b>${f2(R.summary.fuel_L)}<small> ${fuelUnit()}/24 h</small></b></div>
        <div class="kv"><span>Coldest night, no heating</span><b>${f1(R.summary.passive.nightMin)}<small> °C</small></b></div>
        <div class="kv"><span>Coldest night, heated</span><b>${f1(R.summary.heated.nightMin)}<small> °C</small></b></div>
        <div class="kv"><span>Structural mass</span><b>${f0(lg.mass)}<small> kg</small></b></div>
        <div class="kv"><span>Cost</span><b>${lg.costComplete ? "₹ " + f0(lg.cost) : "<small>rates needed</small>"}</b></div></div>`;
      $("parCards").innerHTML = card("Baseline", baseR, bL, "base") + card(`Optimised: ${Math.round(par.knee.insT * 1000)} mm, WWR ${par.knee.wwr}, ${par.knee.water} kg water`, parOptR, oL, "opt");
      $("parApply").hidden = false;
      const yv = p => (par.objective === "cost" ? p.cost : p.mass);
      C.scatter($("parChart"), { height: 280, xLabel: `Fuel, ${fuelUnit()}/24 h`, yLabel: par.objective === "cost" ? "Cost, ₹" : "Transported mass, kg", r: 3.5,
        sets: [{ cls: "c7", pts: par.pts.filter(p => p.unmet === 0).map(p => [p.fuel, yv(p)]) }, { cls: "c0", pts: par.front.map(p => [p.fuel, yv(p)]) },
          { cls: "c2", pts: [[par.knee.fuel, yv(par.knee)]] }, { cls: "c1", pts: [[baseR.summary.fuel_L, yv(Object.assign({}, bL, { cost: bL.cost }))]] }] });
      $("parLegend").innerHTML = `<span class="lg dot" style="--c:#4F6070">Feasible designs (${par.feasible} of 125)</span><span class="lg dot" style="--c:#8C2131">Pareto front</span><span class="lg dot" style="--c:#D99A1E">Suggested (knee)</span><span class="lg dot" style="--c:#2F6FA3">Baseline</span><span>${Math.round(ms)} ms</span>`;
    }, 30);
  });
  $("parApply").addEventListener("click", () => { if (!par || !par.knee) return; A.S.design = clone(par.knee.d); A.syncInputs(); A.changed(); A.toast("Optimised specification applied"); });

  /* ---------------------------------------------------------- 01 location & sync */
  $("sdPresets").innerHTML = W.PRESETS.map((p, i) => `<button type="button" class="chip" data-p="${i}">${p.name}</button>`).join("");
  $("sdPresets").querySelectorAll("[data-p]").forEach(b => b.onclick = () => { const p = W.PRESETS[+b.dataset.p]; $("sdName").value = p.name; $("sdLat").value = p.lat; $("sdLon").value = p.lon; mgrs(); });
  function mgrs() { const la = parseFloat($("sdLat").value), lo = parseFloat($("sdLon").value), m = isFinite(la) && isFinite(lo) ? W.toMGRS(la, lo) : null; $("sdMgrs").textContent = m ? "MGRS " + m.text : ""; }
  ["sdLat", "sdLon"].forEach(id => $(id).addEventListener("input", mgrs));
  $("sdLocate").addEventListener("click", () => {
    if (!navigator.geolocation) return A.toast("No location service on this device");
    navigator.geolocation.getCurrentPosition(p => { $("sdLat").value = p.coords.latitude.toFixed(4); $("sdLon").value = p.coords.longitude.toFixed(4); if (!$("sdName").value) $("sdName").value = "My location"; mgrs(); },
      e => A.toast("Location not available: " + e.message), { enableHighAccuracy: true, timeout: 15000 });
  });
  // Pre-deployment sync = climate + terrain (sitedata) + forecast (weather), all cached
  const fetchBtn = $("sdFetch"), oldFetch = fetchBtn.cloneNode(true); fetchBtn.replaceWith(oldFetch);
  oldFetch.addEventListener("click", async () => {
    const name = $("sdName").value.trim() || "New site", lat = parseFloat($("sdLat").value), lon = parseFloat($("sdLon").value);
    if (!(lat >= -60 && lat <= 60 && lon >= -180 && lon <= 180)) { $("sdStatus").textContent = "Enter a latitude and longitude, or pick a preset."; return; }
    if (!navigator.onLine) { $("sdStatus").textContent = "Offline. Sync on a connected machine and import the site pack."; return; }
    try {
      const rec = await TS.sitedata.buildPack(name, lat, lon, null, t => ($("sdStatus").textContent = t));
      $("sdStatus").textContent = "Fetching the 14-day forecast…";
      const fc = await W.fetchForecast(lat, lon);
      TS.sitedata.install(rec); await W.store.set("fc:" + rec.id, fc); await W.store.set("pack:" + rec.id, rec);
      A.syncInputs(); $("sdSite").value = rec.id; TS.uiplus.renderSite(); renderSync();
      $("sdStatus").textContent = `Synced ${rec.name} (${rec.alt} m): climate, terrain and forecast cached. Works offline from now on.`;
    } catch (e) { $("sdStatus").textContent = "Sync failed: " + e.message + ". Browsers can block these requests; the Windows and Android apps fetch directly."; }
  });
  $("sdSite").addEventListener("change", renderSync);
  async function renderSync() {
    const id = $("sdSite").value || A.S.site.id, rec = TS.SITES.find(s => s.id === id); if (!rec) return;
    const fc = await W.store.get("fc:" + id);
    if (!fc) { $("wxBadge").textContent = "NO FORECAST CACHED"; $("wxBadge").className = "alertbadge"; $("wxText").textContent = "Run Pre-deployment sync for this site while online."; $("wxChart").innerHTML = ""; $("wxTable").innerHTML = ""; $("wxLegend").innerHTML = ""; return; }
    const month = +fc.hours[Math.floor(fc.hours.length / 2)].time.slice(5, 7) - 1, nrm = W.normals(rec, month, rec.alt);
    const ds = W.days(fc, rec.alt), al = W.alert(ds.days, nrm);
    const site = TS.engine.siteFrom(rec, month, {}), sim = W.simulateForecast(A.S.design, site, A.ops(), fc);
    TS.stages.lastAlert = { al, rec, fc, sim };
    $("wxBadge").textContent = al.level === "SEVERE" ? "SEVERE COLD WAVE (IMD departure ≤ −6.5 K)" : al.level === "WATCH" ? "COLD WAVE WATCH (IMD departure ≤ −4.5 K)" : "STABLE WEATHER";
    $("wxBadge").className = "alertbadge " + al.level.toLowerCase();
    const worstShelter = sim.perDay.filter((_, i) => ds.days[i] && ds.days[i].future).reduce((b, p) => (!b || p.heat < b.heat ? p : b), null);
    $("wxText").innerHTML = (al.reasons.length ? al.reasons.join(". ") + ". " : `Next 7 days stay within 4.5 K of the ${A.MONTHS[month]} normal minimum (${f1(nrm.tmin)} °C), below the IMD cold-wave departure. `) +
      (worstShelter ? `With the current design the coldest forecast night is <b>${worstShelter.date}</b>: inside ${f1(worstShelter.heat)} °C with the heater, ${f1(worstShelter.pas)} °C without${worstShelter.unmet ? `, heater short for ${worstShelter.unmet} h` : ""}. ` : "") +
      (al.volatility != null ? `Day-to-day swing over the past week: ${f1(al.volatility)} K. ` : "") + `Forecast fetched ${fc.fetched.slice(0, 16).replace("T", " ")} UTC. IMD cold-wave departure criteria applied to the forecast; not a probability.`;
    const r = sim.r, x = r.amb.map((_, i) => i + 0.5), firstFuture = ds.days.findIndex(d => d.future) * 24;
    C.line($("wxChart"), { x, xTicks: x.filter((_, i) => i % 24 === 0).map(v => v - 0.5), xFmt: (v, tip) => (fc.hours[Math.min(fc.hours.length - 1, Math.floor(v))] || {}).time.slice(5, tip ? 16 : 10).replace("T", " "),
      height: 260, unit: " °C", tipDigits: 1, yLabel: "°C", vbands: firstFuture >= 0 ? [{ x0: firstFuture, x1: r.N, cls: "nightband" }] : [],
      hbands: [{ y0: 14, y1: 20, cls: "band", fit: false }],
      series: [{ name: "Outside", y: r.amb, cls: "amb", width: 1.6 }, { name: "Inside, no heating", y: r.passive.op, cls: "pas", width: 2.2 }] });
    $("wxLegend").innerHTML = `<span class="l-amb">Outside (forecast)</span><span class="l-pas">Inside, no heating</span><span class="l-night">Forecast period</span>`;
    $("wxTable").innerHTML = `<tr><th class="l">Day</th><th>Outside min</th><th>Normal min</th><th>Below normal</th><th>Wind max</th><th>Inside min, no heat</th><th>Inside min, heated</th><th>Fuel</th></tr>` +
      ds.days.map((d0, i) => { const p = sim.perDay[i] || {}; return `<tr class="${d0.future ? "" : "cur"}"><td>${d0.date}${d0.future ? "" : " (past)"}</td><td>${f1(d0.tmin)}</td><td>${f1(nrm.tmin)}</td><td class="${d0.tmin - nrm.tmin <= -8 ? "err" : ""}">${f1(nrm.tmin - d0.tmin)} K</td><td>${f0(d0.wmax)} m/s</td><td>${f1(p.pas)}</td><td>${f1(p.heat)}</td><td>${f2(p.fuel)}</td></tr>`; }).join("");
  }

  /* ---------------------------------------------------------- 05 logistics */
  function renderLogistics() {
    const R = A.R; if (!R) return;
    const s = L.summary(A.S.design, R.summary.fuel_L, fuelUnit()), cfg = L.cfg();
    $("boqTable").innerHTML = `<tr><th class="l">Item</th><th>Thickness</th><th>Quantity</th><th>Mass</th><th>R</th><th>Rate, ₹ per unit</th><th>Amount, ₹</th></tr>` +
      s.rows.map((b, i) => `<tr><td>${b.item}</td><td>${b.thick ? (b.thick * 1000).toFixed(b.thick < 0.005 ? 1 : 0) + " mm" : "–"}</td><td>${b.qty < 10 ? b.qty.toFixed(2) : b.qty.toFixed(1)} ${b.unit.replace("m2", "m²").replace("m3", "m³")}</td>` +
        `<td>${f0(b.mass)} kg</td><td>${b.R != null ? f2(b.R) : "–"}</td><td><input type="number" min="0" step="1" data-rate="${b.key}" value="${cfg.rates[b.key] || ""}" placeholder="${(() => { const r = L.rateFor(b.key); return r.src === "market" ? r.rate + " (market)" : "enter"; })()}" aria-label="Rate for ${b.item}"></td><td>${(() => { const r = L.rateFor(b.key); return r.rate ? f0(r.rate * b.qty) : "–"; })()}</td></tr>`).join("") +
      `<tr><td colspan="7" class="l note">Market prices for ${A.siteRec().name}: ${TS.prices.factor(A.S.site.id).station}; price factor ×${TS.prices.factor(A.S.site.id).f.toFixed(2)} over Delhi. Type your own rate to replace any of them.</td></tr>`;
    $("boqTable").querySelectorAll("[data-rate]").forEach(inp => inp.addEventListener("change", () => { L.setRate(inp.dataset.rate, parseFloat(inp.value)); setTimeout(renderLogistics, 0); }));
    const kpi = (k, v, u) => `<div><span>${k}</span><b>${v}<small>${u || ""}</small></b></div>`;
    $("boqKpis").innerHTML = kpi("Package mass", f0(s.mass), " kg") + kpi("Cost", s.costComplete ? "₹ " + f0(s.cost) : f0(s.cost) ? "₹ " + f0(s.cost) + "+" : "–", s.costComplete ? "" : ` (${s.costMissing.length} rate(s) missing)`) +
      kpi("Fuel, 30 days", f1(s.fuelMonth), " " + fuelUnit());
    $("vehTable").innerHTML = `<tr><th class="l">Vehicle</th><th>Payload, kg</th><th>Loads for the shelter</th><th>Loads for 30 days of fuel</th><th></th></tr>` +
      cfg.vehicles.map((v, i) => `<tr><td><input data-vn="${i}" value="${v.name}" style="width:220px" aria-label="Vehicle name"></td><td><input type="number" min="0" step="50" data-vp="${i}" value="${v.payload || ""}" placeholder="enter"></td>` +
        `<td>${v.payload > 0 ? Math.ceil(s.mass / v.payload) : "–"}</td><td>${v.payload > 0 ? Math.ceil(s.fuelMonth * 0.85 / v.payload) : "–"}</td><td><button type="button" class="iconbtn" data-vd="${i}" aria-label="Remove">×</button></td></tr>`).join("");
    $("vehTable").querySelectorAll("[data-vn]").forEach(i => i.onchange = () => { cfg.vehicles[+i.dataset.vn].name = i.value; L.setCfg({ vehicles: cfg.vehicles }); });
    $("vehTable").querySelectorAll("[data-vp]").forEach(i => i.onchange = () => { cfg.vehicles[+i.dataset.vp].payload = parseFloat(i.value) || 0; L.setCfg({ vehicles: cfg.vehicles }); setTimeout(renderLogistics, 0); });
    $("vehTable").querySelectorAll("[data-vd]").forEach(b => b.onclick = () => { cfg.vehicles.splice(+b.dataset.vd, 1); L.setCfg({ vehicles: cfg.vehicles }); renderLogistics(); });
    $("mhRate").value = cfg.manHoursPerM2 || ""; $("crew").value = cfg.crew; $("hpd").value = cfg.hoursPerDay;
    $("logKpis").innerHTML = kpi("Assembly", s.manHours != null ? f0(s.manHours) : "–", s.manHours != null ? " man-hours" : " enter effort per m²") + kpi("With the crew", s.days != null ? f1(s.days) : "–", " days");
  }
  $("vehAdd").addEventListener("click", () => { const c = L.cfg(); c.vehicles.push({ name: "Vehicle", payload: 0 }); L.setCfg({ vehicles: c.vehicles }); renderLogistics(); });
  [["mhRate", "manHoursPerM2"], ["crew", "crew"], ["hpd", "hoursPerDay"]].forEach(([id, k]) => $(id).addEventListener("change", e => { L.setCfg({ [k]: Math.max(0, parseFloat(e.target.value) || 0) }); setTimeout(renderLogistics, 0); }));

  /* ---------------------------------------------------------- report */
  function reportCtx() {
    const R = A.R, d = A.S.design, site = A.buildSite(), al = TS.stages.lastAlert;
    return { d, site, r: R, ops: A.ops(), checks: extra.concat(TS.uiplus.lastChecks ? TS.uiplus.lastChecks() : []), sens: TS.optimise.sensitivity(d, site, A.ops(), "fuel"),
      optR: parOptR, log: L.summary(d, R.summary.fuel_L, fuelUnit()), optLog: par && par.knee && parOptR ? L.summary(par.knee.d, parOptR.summary.fuel_L, fuelUnit()) : null,
      moist, apdl: TS.apdl.generate(d, R), unit: fuelUnit(), explainText: $("plainText").textContent, siteName: A.siteRec().name, monthName: A.MONTHS[A.S.site.month],
      typeName: "Designer", heaterName: heaterNow().name, classification: (document.documentElement.dataset.profile === "defence" ? "Defence" : "Disaster relief"),
      safeFloor: TS.field.PROFILES[document.documentElement.dataset.profile || "defence"].safeFloor, pathNames: A.pathNames(),
      alertText: al ? `${al.al.level}: ${al.al.reasons.join("; ") || "no cold surge in the next 7 days"} (rule on Open-Meteo forecast for ${al.rec.name}).` : "" };
  }
  async function downloadReport() {
    try { A.toast("Building the report…"); const doc = await TS.report.build(reportCtx()); A.toast("Saved " + await TS.report.save(doc, "fluxion_verification.pdf")); }
    catch (e) { A.toast("Report failed: " + e.message); console.error(e); }
  }
  $("logReport").addEventListener("click", downloadReport);
  $("logBoq").addEventListener("click", () => A.download("fluxion_bom.csv", TS.report.boqCSV(L.boq(A.S.design)), "text/csv"));
  $("logApdl").addEventListener("click", () => A.download("fluxion_apdl.txt", TS.apdl.generate(A.S.design, A.R), "text/plain"));
  // Designer buttons use the same report
  ["dlReport", "dlBoq"].forEach(id => { const b = $(id), nb = b.cloneNode(true); b.replaceWith(nb); });
  $("dlReport").addEventListener("click", downloadReport);
  $("dlBoq").addEventListener("click", () => A.download("fluxion_bom.csv", TS.report.boqCSV(L.boq(A.S.design)), "text/csv"));

  /* ---------------------------------------------------------- Quick check: badges, archetype, glove targets */
  const fForm = document.querySelector("#view-field form");
  fForm.insertAdjacentHTML("afterbegin", `<label class="inline" id="fArchWrap">Disaster type<select id="fArch">${Object.entries(L.ARCHETYPES).map(([k, a]) => `<option value="${k}">${a.name}</option>`).join("")}</select></label>`);
  $("fArch").value = TS.fieldUI.answers().archetype || "none";
  $("fArch").addEventListener("change", e => { TS.fieldUI.answers().archetype = e.target.value; TS.fieldUI.render(); });
  document.querySelector("#view-field .answers").insertAdjacentHTML("afterbegin", `<div class="hud" id="fHud"></div>`);
  function fieldHud(last) {
    if (!last) return;
    const { m, r } = last, P = m.P, ans = TS.fieldUI.answers(), stove = ans.stove;
    const minT = stove ? r.summary.heated.nightMin : r.summary.passive.nightMin, ok = minT >= P.safeFloor - 0.05 && !(stove && r.summary.unmetHours > 0);
    const cap = TS.field.capacity(m, ans.people), days = stove && r.summary.fuel_L > 0.05 ? ans.stock / r.summary.fuel_L : null;
    const ring = (v, max, cls) => { const p = Math.max(0, Math.min(1, v / max)); return `<svg viewBox="0 0 36 36" class="ring ${cls}"><circle cx="18" cy="18" r="15.5"/><circle cx="18" cy="18" r="15.5" class="val" stroke-dasharray="${(p * 97.4).toFixed(1)} 97.4"/></svg>`; };
    $("fHud").innerHTML = `<div class="hudcell ${ok ? "go" : "nogo"}"><b>${ok ? "GO" : "NO-GO"}</b><span>tonight</span></div>` +
      `<div class="hudcell">${ring(minT - (P.safeFloor - 20), 30, ok ? "ok" : "bad")}<b>${f1(minT)}<small>°C</small></b><span>coldest hour${stove ? ", heated" : ""}</span></div>` +
      `<div class="hudcell">${ring(Math.min(ans.people, cap.nSpace), Math.max(ans.people, cap.nSpace), ans.people > cap.nSpace ? "bad" : "ok")}<b>${cap.nSpace}</b><span>people fit (${ans.people} entered)</span></div>` +
      `<div class="hudcell">${ring(days || 0, 30, days != null && days < 7 ? "bad" : "ok")}<b>${days != null ? f1(days) : "–"}</b><span>days of fuel</span></div>`;
  }
  TS.stages = { fieldHud, renderSync, renderLogistics, reportCtx, lastAlert: null };
  const _frender = TS.fieldUI.render; TS.fieldUI.render = () => { _frender(); setTimeout(() => fieldHud(TS.fieldLast), 0); };
  document.querySelectorAll("#fTypes, #view-field form").forEach(el => el.addEventListener("click", () => setTimeout(() => fieldHud(TS.fieldLast), 60)));
  document.querySelector("#view-field form").addEventListener("input", () => setTimeout(() => fieldHud(TS.fieldLast), 60));
  fieldHud(TS.fieldLast); markStep();
})();
