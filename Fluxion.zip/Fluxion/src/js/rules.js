/* DESIGN RULES: the high-altitude design parameters, each computed from the
   current design and site, with a one-click fix where one exists.
   Passive solar: within 15 deg of true south; east-west elongation 1:1.5-1:2;
     south glass 7-12 % of floor (model optimum shown); SHGC >= 0.5; exposed
     mass 3-6 x south glass area; unshaded south facade 09:00-15:00 on 21 Dec
     (terrain horizon); overhang sized from solstice noon altitudes.
   Structure: snow shedding (>= 45 deg or curved roof; IS 875-4 load), wind
     uplift and anchorage (IS 875-3, from WIND & SNOW), seismic mass.
   Envelope: U-values, thermal-bridge allowance, heat-recovery ventilation.
   Materials: UV exposure and cold brittleness of the outer layer (typical
     limits, confirm with suppliers).
   Life support: oxygen partial pressure and equivalent altitude (indoor
     oxygen above 23.5 % is an oxygen-enriched atmosphere, a fire hazard);
     CO2; condensation.
   Power and water: PV sized on the tilted-plane irradiation of the month,
     battery autonomy, snow-melt energy for water (Sphere 15 L/person/day). */
(function () {
  "use strict";
  const TS = window.TS, A = TS.app, $ = id => document.getElementById(id);
  const D2R = Math.PI / 180, clone = o => JSON.parse(JSON.stringify(o));
  const f0 = v => (v == null || !isFinite(v) ? "–" : String(Math.round(v)));
  const f1 = v => (v == null || !isFinite(v) ? "–" : (+v).toFixed(1)).replace(/^-/, "−");
  const f2 = v => (v == null || !isFinite(v) ? "–" : (+v).toFixed(2)).replace(/^-/, "−");
  const KEY = "thermashelter.rules.v1";
  let P = { zone: "IV", kwh: 1.5, days: 3, water: 15 };
  try { Object.assign(P, JSON.parse(localStorage.getItem(KEY)) || {}); } catch (e) {}

  // typical outer-layer limits: [UV if exposed: good/fair/poor, lowest service temperature degC]
  const MAT = { steel: ["good", -20], alu: ["good", -80], grp: ["good", -40], canvas: ["fair", -40], pesheet: ["fair", -50], puf: ["poor", -50], eps: ["poor", -50],
    xps: ["poor", -50], pir: ["poor", -50], rockwool: ["fair", -60], felt: ["poor", -60], straw: ["poor", -60], timber: ["fair", -60], plywood: ["fair", -40],
    stone: ["good", -60], mudbrick: ["fair", -30], rammed: ["fair", -30], mudplast: ["fair", -30], concrete: ["good", -30], cplaster: ["good", -30], snow: ["good", -90], bamboo: ["fair", -40] };

  const sec = document.createElement("section");
  sec.className = "view"; sec.id = "view-rules"; sec.dataset.view = "rules"; sec.hidden = true;
  sec.innerHTML = `<div class="page"><div class="row4">
      <label>Seismic zone (IS 1893)<select id="ruZone"><option>II</option><option>III</option><option>IV</option><option>V</option></select></label>
      <label><span>Electrical load <small>kWh/day</small></span><input id="ruKwh" type="number" min="0" step="0.1"></label>
      <label><span>Battery autonomy <small>days</small></span><input id="ruDays" type="number" min="1" step="1"></label>
      <label><span>Water <small>L/person/day</small></span><input id="ruWater" type="number" min="1" step="1"></label></div>
    <div id="ruGroups"></div></div>`;
  document.querySelector("main").appendChild(sec);
  const tab = document.createElement("button"); tab.setAttribute("role", "tab"); tab.dataset.tab = "rules"; tab.textContent = "DESIGN RULES";
  const after = document.querySelector('.fxtabs button[data-tab="wind"]'); (after || document.querySelector(".tabs").lastElementChild).after(tab);
  tab.addEventListener("click", () => TS.app.showTab("rules"));

  function horizonAt(h, az) { if (!h || !h.length) return 0; const n = h.length, s = 360 / n, x = ((az % 360) + 360) % 360 / s, i = Math.floor(x) % n, j = (i + 1) % n, f = x - Math.floor(x); return h[i] * (1 - f) + h[j] * f; }
  function altFromP(Pa) { return (1 - Math.pow(Pa / 101325, 1 / 5.25588)) / 2.25577e-5; }
  function erbs(KT, ws) { return ws <= 81.4 ? (KT < 0.715 ? 1 - 0.2727 * KT + 2.4495 * KT ** 2 - 11.9514 * KT ** 3 + 9.3879 * KT ** 4 : 0.143) : (KT < 0.722 ? 1 + 0.2832 * KT - 2.5557 * KT ** 2 + 0.8448 * KT ** 3 : 0.175); }
  /* monthly-mean daily irradiation on a south-facing plane tilted beta (Liu-Jordan isotropic) */
  function tilted(site, beta) {
    const E = TS.engine, n = site.doy, phi = site.lat * D2R, b = beta * D2R, dec = E.declination(n) * D2R;
    const ws = Math.acos(Math.max(-1, Math.min(1, -Math.tan(phi) * Math.tan(dec))));
    const wsp = Math.min(ws, Math.acos(Math.max(-1, Math.min(1, -Math.tan(phi - b) * Math.tan(dec)))));
    const Rb = (Math.cos(phi - b) * Math.cos(dec) * Math.sin(wsp) + wsp * Math.sin(phi - b) * Math.sin(dec)) / (Math.cos(phi) * Math.cos(dec) * Math.sin(ws) + ws * Math.sin(phi) * Math.sin(dec));
    const KT = Math.min(0.85, site.H / E.H0day(site.lat, n)), fd = erbs(KT, ws / D2R);
    return site.H * ((1 - fd) * Rb + fd * (1 + Math.cos(b)) / 2 + site.albedo * (1 - Math.cos(b)) / 2);
  }

  function evaluate() {
    const d = A.S.design, R = A.R, site = A.buildSite(), ops = A.ops(), G = TS.engine.geom(d), groups = [];
    const add = (g, it) => { let x = groups.find(q => q.name === g); if (!x) groups.push(x = { name: g, items: [] }); x.items.push(it); };
    const it = (t, v, u, st, rule, fix) => ({ t, v, u, st, rule, fix });
    // ---- passive solar
    const dev = Math.abs(((d.orient - 180 + 540) % 360) - 180);
    add("Passive solar", it("Facing true south", f0(dev), "° off", dev <= 15 ? "ok" : dev <= 30 ? "warn" : "bad", "within 15° of true solar south",
      dev > 15 ? { label: "Face south", apply: x => { x.orient = 180; return x; } } : null));
    if ((d.shape || "box") === "box") {
      const r = d.L / d.W, Af = d.L * d.W;
      add("Passive solar", it("East–west elongation", "1:" + f2(r), "", r >= 1.5 && r <= 2.0 ? "ok" : r >= 1.2 && r <= 2.5 ? "warn" : "bad", "long side facing south, 1:1.5 to 1:2",
        r < 1.5 || r > 2.0 ? { label: "Set 1:1.75, same floor area", apply: x => { x.L = +Math.sqrt(Af * 1.75).toFixed(2); x.W = +(Af / x.L).toFixed(2); return x; } } : null));
    }
    const Aw = (d.win && d.win.front) || 0, gpct = 100 * Aw / G.Af, best = TS.checks.bestGlazing(d, site, ops);
    add("Passive solar", it("South glass", f1(gpct), "% of floor", gpct >= 7 && gpct <= 12 ? "ok" : gpct > 0 ? "warn" : "bad", `rule 7–12 %; this site's fuel optimum ${f1(100 * best.A / G.Af)} %`,
      Math.abs(best.A - Aw) > 0.2 ? { label: `Set to optimum ${f1(best.A)} m²`, apply: x => { x.win.front = best.A; return x; } } : null));
    const g = TS.GLAZING[d.glazing].g;
    add("Passive solar", it("South glass SHGC", f2(g), "", g >= 0.5 ? "ok" : "warn", "≥ 0.50, low-e to keep heat in", g < 0.5 ? { label: "Double low-e (g 0.60)", apply: x => { x.glazing = "lowe"; return x; } } : null));
    const mg = Aw > 0 ? R.net.Am / Aw : null;
    add("Passive solar", it("Exposed mass : glass", mg == null ? "–" : f1(mg), "× area", mg == null ? "" : mg >= 3 && mg <= 6 ? "ok" : mg > 6 ? "ok" : "warn", "3–6 m² of exposed thermal mass per m² of south glass; keep floors bare",
      mg != null && mg < 3 ? { label: "Add 400 kg water store", apply: x => { x.store = { type: "water", mass: 400 }; return x; } } : null));
    let sun = 0; for (let t = 9; t < 15; t += 0.25) { const sp = TS.engine.sunPos(site.lat, site.lon, 355, t + 0.125, 82.5);
      if (sp.alt > horizonAt(site.horizon, sp.az) && Math.cos((sp.az - d.orient) * D2R) > 0) sun += 0.25; }
    add("Passive solar", it("Winter sun on the south facade", f1(sun), "of 6 h", sun >= 5 ? "ok" : sun >= 3 ? "warn" : "bad", "21 Dec, 09:00–15:00, terrain horizon applied", null));
    const wh = Math.min(1.2, 0.8 * (G.H || d.H)), gap = 0.3, aW = 90 - site.lat - 23.45, aS = 90 - site.lat + 23.45;
    const Psum = (gap + wh) / Math.tan(aS * D2R), Pwin = gap / Math.tan(aW * D2R), Prec = Psum <= Pwin ? Psum : Pwin, Pnow = (d.overhang && d.overhang.P) || 0;
    add("Passive solar", it("South overhang", f2(Pnow), " m", Aw === 0 ? "" : Math.abs(Pnow - Prec) < 0.08 ? "ok" : "warn",
      `${f2(Prec)} m ${Psum <= Pwin ? "blocks summer noon sun and admits all winter sun" : "admits all winter sun (summer shading only partial)"}; noon sun ${f0(aW)}° winter, ${f0(aS)}° summer`,
      Aw > 0 && Math.abs(Pnow - Prec) >= 0.08 ? { label: `Set ${f2(Prec)} m`, apply: x => { x.overhang = { P: +Prec.toFixed(2), g: gap }; return x; } } : null));
    // ---- structure
    const ws = TS.windsnow ? TS.windsnow.compute() : null, curved = d.shape === "dome" || d.shape === "vault";
    add("Structure", it("Snow shedding", curved ? "curved" : f0(d.pitch || 0), curved ? "" : "° pitch", curved || (d.pitch || 0) >= 45 ? "ok" : (d.pitch || 0) >= 30 ? "warn" : "bad",
      `≥ 45° or a smooth curved roof${ws && ws.s0 ? `; roof snow ${f2(ws.s)} kN/m² (IS 875-4)` : ""}`, !curved && (d.pitch || 0) < 45 ? { label: "Pitch 45°", apply: x => { x.pitch = 45; return x; } } : null));
    if (ws) add("Structure", it("Wind uplift", f1(ws.uplift), " kN", ws.anchor > 0 ? "warn" : "ok", ws.anchor > 0 ? `anchor at least ${f1(ws.anchor)} kN beyond the roof's weight (IS 875-3)` : "held by roof weight (IS 875-3)", null));
    const mass = TS.logistics.boq(d).reduce((s, r) => s + r.mass, 0), heavy = TS.logistics.heavyLayers(d), hz = P.zone === "IV" || P.zone === "V";
    add("Structure", it("Seismic mass", f0(mass / G.Af), " kg/m² floor", hz && heavy.length ? "bad" : hz && mass / G.Af > 300 ? "warn" : "ok",
      `zone ${P.zone}: light frame, flexible joints${heavy.length ? `; heavy layers: ${heavy.join(", ")}` : ""}`, null));
    // ---- envelope
    add("Thermal envelope", it("Wall / roof U", `${f2(R.net.U.wall)} / ${f2(R.net.U.roof)}`, " W/m²K", "", "lower is better; VIP or PIR for thin, high-R walls", null));
    add("Thermal envelope", it("Thermal bridges", f2(d.tb || 0), " ΔU", !d.tb ? "ok" : d.tb <= 0.05 ? "warn" : "bad", "isolate frames from the outside with thermal breaks",
      d.tb ? { label: "Thermal breaks (ΔU 0)", apply: x => { x.tb = 0; return x; } } : null));
    const co2 = R.co2 ? R.co2.max : R.summary.co2_ppm, mech = d.mech && d.mech.ach > 0;
    let hrvFix = null, hrvNote = mech ? `${f1(d.mech.ach)} air ch./h at ${f0(d.mech.eff * 100)} % recovery` : "no mechanical ventilation";
    if (co2 > 1000 && !mech) {
      const need = Math.max(0.2, (R.summary.achFor1000 || 1) - R.airflow.achMean);
      const fH = TS.engine.simulate(Object.assign(clone(d), { mech: { ach: need, eff: 0.75 } }), site, Object.assign({}, ops, { withSolarFraction: false })).summary.fuel_L;
      const fV = TS.engine.simulate(Object.assign(clone(d), { ach: d.ach + need }), site, Object.assign({}, ops, { withSolarFraction: false })).summary.fuel_L;
      hrvNote = `CO₂ ${f0(co2)} ppm: fresh air by HRV costs ${f2(fH)} L/day, by open vents ${f2(fV)}`;
      hrvFix = { label: `HRV ${f1(need)} air ch./h, 75 %`, apply: x => { x.mech = { ach: +need.toFixed(2), eff: 0.75 }; return x; } };
    }
    add("Thermal envelope", it("Ventilation", mech ? "HRV" : f0(co2), mech ? "" : " ppm CO₂", co2 > 1000 && !mech ? "warn" : "ok", hrvNote, hrvFix));
    // ---- materials
    const outer = ["wall", "roof"].map(el => ({ el, l: d[el][0] })), Tdes = site.Tmin - 6.5;
    outer.forEach(({ el, l }) => { const m = MAT[l.mat] || ["fair", -30], nm = TS.MATERIALS[l.mat].name;
      add("Materials", it(`${el === "wall" ? "Wall" : "Roof"} outer layer`, nm, "", m[0] === "poor" || m[1] > Tdes ? "bad" : m[0] === "fair" ? "warn" : "ok",
        `UV ${m[0]} when exposed; usable to about ${m[1]} °C vs design low ${f0(Tdes)} °C${l.mat === "steel" && m[1] > Tdes ? ": use a low-temperature impact-tested grade" : ""}`, null)); });
    add("Materials", it("Transport mass", f0(mass), " kg", "", "prefabricated, light modules shorten the short building season", null));
    // ---- life support
    const Pa = TS.engine.pressurePa(site.alt), c = (d.o2 || 20.95) / 100, pO2 = c * Pa / 1000, eqAlt = altFromP(Pa * c / 0.2095);
    add("Life support", it("Oxygen partial pressure", f1(pO2), " kPa", c > 0.235 ? "bad" : eqAlt > 3000 ? "warn" : "ok",
      `${f1(c * 100)} % O₂ feels like ${f0(Math.max(0, eqAlt))} m${c > 0.235 ? "; above 23.5 % is an oxygen-enriched atmosphere: fire hazard" : ""}`,
      eqAlt > 3000 && c <= 0.235 ? { label: "Enrich to 23 %", apply: x => { x.o2 = 23; return x; } } : c > 0.235 ? { label: "Limit to 23 %", apply: x => { x.o2 = 23; return x; } } : null));
    add("Life support", it("Peak CO₂", f0(co2), " ppm", co2 <= 1000 ? "ok" : co2 <= 5000 ? "warn" : "bad", "1000 ppm comfort, 5000 ppm 8-hour limit", null));
    add("Life support", it("Daylight and view", (d.win && Object.values(d.win).some(v => v > 0)) ? TS.GLAZING[d.glazing].name : "none", "", (d.win && Object.values(d.win).some(v => v > 0)) ? "ok" : "warn", "a triple-glazed window eases long storm confinement", null));
    // ---- power and water
    const beta = Math.max(0, Math.min(90, site.lat + 15)), Ht = tilted(site, beta), kWp = P.kwh / (Ht * 0.75), bat = P.kwh * P.days / 0.8;
    add("Power and water", it("Solar PV", f2(kWp), " kWp", "", `${f1(P.kwh)} kWh/day at ${f2(Ht)} kWh/m²·day on a ${f0(beta)}° south tilt, PR 0.75`, null));
    add("Power and water", it("Battery", f1(bat), " kWh", "", `${P.days} days of autonomy, 80 % depth; generator with cold-start kit as backup`, null));
    const Tsnow = Math.min(0, site.Tmean), kJkg = 2.09 * (0 - Tsnow) + 334 + 4.18 * 10, kg = P.water * d.people, kwhW = kJkg * kg / 3600;
    add("Power and water", it("Snow melt for water", f1(kwhW), " kWh/day", "", `${f0(kg)} L/day for ${d.people} people = ${f2(kwhW / (ops.kwhPerL * ops.eta))} L kerosene, or use generator waste heat; keep tanks heated`, null));
    if (d.wall.some(l => l.mat === "snow")) {
      const air = R.heated.air, mx = Math.max(...R.elems.flatMap((es, h) => es.filter(e => e.kind !== "floor").map(e => air[h] - e.U * e.rsi * (air[h] - e.th))));
      add("Structure", it("Snow walls stay frozen", f1(mx), " °C inner surface", mx < 0 ? "ok" : "bad", "inner snow surface must stay below 0 °C or it melts and drips", null));
    }
    return groups;
  }
  function render() {
    if (!A.R) return;
    $("ruZone").value = P.zone; $("ruKwh").value = P.kwh; $("ruDays").value = P.days; $("ruWater").value = P.water;
    const groups = evaluate(), fixes = [];
    $("ruGroups").innerHTML = groups.map(g => `<section class="block"><h2>${g.name}</h2><div class="rulegrid">` + g.items.map(x => {
      const fi = x.fix ? fixes.push(x.fix) - 1 : -1;
      return `<div class="rcard ${x.st}"><span>${x.t}</span><b>${x.v}<small>${x.u}</small></b><em>${x.rule}</em>${fi >= 0 ? `<button type="button" class="ghost small" data-rf="${fi}">${x.fix.label}</button>` : ""}</div>`;
    }).join("") + `</div></section>`).join("");
    $("ruGroups").querySelectorAll("[data-rf]").forEach(b => b.onclick = () => { A.S.design = fixes[+b.dataset.rf].apply(clone(A.S.design)); A.syncInputs(); A.changed(); A.toast("Applied: " + fixes[+b.dataset.rf].label); setTimeout(render, 400); });
  }
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(P)); } catch (e) {} };
  $("ruZone").addEventListener("change", e => { P.zone = e.target.value; save(); render(); });
  [["ruKwh", "kwh"], ["ruDays", "days"], ["ruWater", "water"]].forEach(([id, k]) => $(id).addEventListener("change", e => { P[k] = Math.max(0, +e.target.value || 0); save(); render(); }));
  const _show = TS.app.showTab;
  TS.app.showTab = t => { _show(t); tab.setAttribute("aria-selected", String(t === "rules")); if (t === "rules") setTimeout(render, 50); };
  TS.rules = { evaluate, render, tilted };
})();
