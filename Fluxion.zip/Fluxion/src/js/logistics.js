/* Logistics, cost and assembly. Nothing here has a hidden default price,
   helicopter payload or labour norm: those come from the user (unit rates,
   vehicle payloads, man-hours per m2) and are stored on the device. What the
   app computes is quantities and masses from the design.
   Glazing mass: typical 10 kg/m2 single, 20 double, 30 triple, 3 polycarbonate. */
(function (g) {
  "use strict";
  const TS = g.TS;
  const KEY = "thermashelter.logistics.v1";
  const GLASS_KG = { single: 10, double: 20, lowe: 20, triple: 30, polycarb: 3 };

  const DEFAULTS = {
    rates: {},                                   // "mat|unit" -> INR per unit
    vehicles: [{ name: "Truck, 3 t", payload: 3000 }, { name: "Helicopter (enter payload)", payload: 0 }],
    manHoursPerM2: 0, crew: 6, hoursPerDay: 8,
  };
  let cfg = JSON.parse(JSON.stringify(DEFAULTS));
  try { const o = JSON.parse(localStorage.getItem(KEY)); if (o) cfg = Object.assign(cfg, o); } catch (e) {}
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(cfg)); } catch (e) {} };

  /* bill of quantities with keys, masses and R-values */
  function boq(d) {
    const rows = [], E = TS.engine, M = TS.MATERIALS, pitch = (d.pitch || 0) * Math.PI / 180;
    const glass = Object.values(d.win || {}).reduce((s, v) => s + v, 0);
    const G = TS.engine.geom(d), facA = Object.values(G.fac).reduce((a, b) => a + b, 0);
    const area = { wall: Math.max(0, facA - glass - ((d.trombe && d.trombe.area) || 0)), roof: G.roof, floor: G.Af };
    for (const el of ["wall", "roof", "floor"]) for (const l of d[el]) {
      const p = E.layerProps(l, M), sheet = l.t < 0.005, a = area[el];
      const local = l.mat === "snow";   // cut on site, not transported
      rows.push({ el, area: a, key: `${l.mat}|${sheet ? "m2" : "m3"}`, item: `${p.name} (${el})${local ? ", cut on site" : ""}`, mat: l.mat, thick: l.t, unit: sheet ? "m2" : "m3",
        qty: sheet ? a : a * l.t, mass: local ? 0 : p.rho * a * l.t, rho: p.rho, R: E.layerR(p) });
    }
    if (d.trombe && d.trombe.area > 0) {
      const p = E.layerProps({ mat: d.trombe.mat, t: d.trombe.t }, M);
      rows.push({ key: `${d.trombe.mat}|m3`, item: `${p.name} (Trombe wall)`, mat: d.trombe.mat, thick: d.trombe.t, unit: "m3", qty: d.trombe.area * d.trombe.t, mass: p.rho * d.trombe.area * d.trombe.t, rho: p.rho, R: E.layerR(p) });
      rows.push({ key: `glz_${d.glazing}|m2`, item: `${TS.GLAZING[d.glazing].name} glazing (Trombe)`, mat: "glass", thick: 0, unit: "m2", qty: d.trombe.area, mass: d.trombe.area * GLASS_KG[d.glazing], rho: null, R: 1 / TS.GLAZING[d.glazing].U });
    }
    if (glass > 0) rows.push({ key: `glz_${d.glazing}|m2`, item: `${TS.GLAZING[d.glazing].name} glazing (windows)`, mat: "glass", thick: 0, unit: "m2", qty: glass, mass: glass * GLASS_KG[d.glazing], rho: null, R: 1 / TS.GLAZING[d.glazing].U });
    if (d.vents && d.vents.low > 0) rows.push({ key: "vent|no", item: `Vent with closable cover, ${d.vents.low} cm²`, mat: "vent", thick: 0, unit: "no", qty: 2, mass: 4, rho: null, R: null });
    if (d.floorMode === "raised") rows.push({ key: "skid|set", item: "Skids / raised-floor supports", mat: "skid", thick: 0, unit: "set", qty: 1, mass: 0, rho: null, R: null });
    if (d.store && d.store.type !== "none" && d.store.mass > 0)
      rows.push({ key: `store_${d.store.type}|kg`, item: TS.STORE[d.store.type].name + (d.store.type === "water" ? " (filled on site)" : ""), mat: d.store.type, thick: 0, unit: "kg", qty: d.store.mass,
        mass: d.store.type === "water" ? 0 : d.store.mass, rho: null, R: null });
    return rows;
  }
  /* rate used for a key: the user's own rate if typed, else the regional market
     price (prices.js) for the selected region, else none */
  function rateFor(key) {
    if (cfg.rates[key] > 0) return { rate: cfg.rates[key], src: "yours" };
    const region = TS.app && TS.app.S ? TS.app.S.site.id : "delhi", p = TS.prices ? TS.prices.price(key, region) : null;
    return p != null ? { rate: p, src: "market" } : { rate: 0, src: null };
  }
  function costOf(rows) {
    let cost = 0, missing = [];
    for (const r of rows) { const { rate } = rateFor(r.key); if (rate > 0) cost += rate * r.qty; else if (!missing.includes(r.key)) missing.push(r.key); }
    return { cost, missing, complete: missing.length === 0 };
  }
  function summary(d, fuelPerDay, fuelUnit) {
    const rows = boq(d), mass = rows.reduce((s, r) => s + r.mass, 0), c = costOf(rows), Af = d.L * d.W;
    const fuelMonth = (fuelPerDay || 0) * 30;
    const loads = cfg.vehicles.filter(v => v.payload > 0).map(v => ({ name: v.name, payload: v.payload, trips: Math.ceil(mass / v.payload), fuelTrips: Math.ceil(fuelMonth * 0.85 / v.payload) }));
    const mh = cfg.manHoursPerM2 > 0 ? cfg.manHoursPerM2 * Af : null;
    return { rows, mass, cost: c.cost, costMissing: c.missing, costComplete: c.complete, loads, manHours: mh,
      days: mh != null ? mh / (cfg.crew * cfg.hoursPerDay) : null, fuelMonth, fuelUnit };
  }
  /* for the optimiser: cost if complete, mass always */
  function costFn(d) { const rows = boq(d), c = costOf(rows); return { cost: c.cost, mass: rows.reduce((s, r) => s + r.mass, 0), complete: c.complete }; }

  /* ---------------------------------------------------------- archetypes */
  const ARCHETYPES = {
    none: { name: "General", note: "" },
    flood: { name: "Flash flood / cyclone",
      note: "Raised floor on stilts, a waterproof membrane under the floor, cross-ventilation openings.",
      apply: d => { d.floorMode = "raised"; if (!d.floor.some(l => l.mat === "pesheet")) d.floor.unshift({ mat: "pesheet", t: 0.0005 });
        d.vents = Object.assign({}, d.vents, { low: Math.max((d.vents || {}).low || 0, 200), high: Math.max((d.vents || {}).high || 0, 200), cross: true }); return d; },
      forbid: m => ["mudbrick", "rammed", "mudplast"].includes(m) },
    quake: { name: "Earthquake zone",
      note: "Light frame, dry joints, no heavy masonry in walls or roof (density over 1200 kg/m³ is excluded).",
      apply: d => d, forbid: m => (TS.MATERIALS[m] || {}).rho > 1200 },
    cold: { name: "High-altitude cold wave",
      note: "Maximum insulation, steep roof of at least 35° to shed snow, sealed envelope with controlled low and high vents.",
      apply: d => { d.pitch = Math.max(d.pitch || 0, 35); d.vents = Object.assign({}, d.vents, { low: Math.max((d.vents || {}).low || 0, 100), high: Math.max((d.vents || {}).high || 0, 100) }); return d; },
      forbid: null },
  };
  function heavyLayers(d) { return ["wall", "roof"].flatMap(el => d[el].filter(l => (TS.MATERIALS[l.mat] || {}).rho > 1200 && l.t >= 0.05).map(l => `${TS.MATERIALS[l.mat].name} in the ${el}`)); }

  /* ---------------------------------------------------------- heating systems
     Energy per fuel unit and efficiency at the point of use. Kerosene per the
     team decision; others are typical values to confirm, editable in the
     Designer (stove efficiency, energy per unit, max rate). Electric heat is
     reported as kWh and as diesel for a generator at 0.3 L/kWh. */
  const HEATERS = {
    passive: { name: "Passive envelope only", unit: "-", kwh: 1, eta: 1, max: 0.0001 },
    bukhari: { name: "Bukhari kerosene heater", unit: "L", kwh: 9.58, eta: 0.60, max: 0.7 },
    dieselFA: { name: "Diesel forced-air heater (flued)", unit: "L", kwh: 10.0, eta: 0.80, max: 0.5 },
    electric: { name: "Electric ceramic heater (on a diesel generator)", unit: "L diesel", kwh: 3.33, eta: 1.0, max: 0.6 },
  };

  TS.logistics = { rateFor, cfg: () => cfg, setCfg: o => { cfg = Object.assign(cfg, o); save(); }, setRate: (k, v) => { if (v > 0) cfg.rates[k] = v; else delete cfg.rates[k]; save(); },
    boq, costOf, costFn, summary, ARCHETYPES, heavyLayers, HEATERS, GLASS_KG };
  if (typeof module !== "undefined") module.exports = TS;
})(typeof window !== "undefined" ? window : globalThis);
