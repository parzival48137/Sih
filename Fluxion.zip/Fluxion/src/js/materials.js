/* Fluxion material library.
   k [W/m.K], rho [kg/m3], c [J/kg.K]. Typical design values drawn from
   ISO 10456:2007 tables and CIBSE Guide A (2015) ranges. Every value is
   editable per layer in the app: replace with supplier data where known.
   cls: "ins" marks insulation (used by the ISO 13790 effective-mass rule). */
(function (g) {
  g.TS = g.TS || {};

  const M = {
    steel:     { name: "Steel sheet",              k: 50,    rho: 7800, c: 450,  cls: "metal" },
    alu:       { name: "Aluminium sheet",          k: 160,   rho: 2700, c: 880,  cls: "metal" },
    puf:       { name: "PUF (rigid polyurethane)", k: 0.025, rho: 35,   c: 1400, cls: "ins" },
    xps:       { name: "XPS board",                k: 0.034, rho: 35,   c: 1450, cls: "ins" },
    eps:       { name: "EPS board",                k: 0.038, rho: 20,   c: 1450, cls: "ins" },
    rockwool:  { name: "Rock wool",                k: 0.038, rho: 60,   c: 1030, cls: "ins" },
    aerogel:   { name: "Aerogel blanket",          k: 0.016, rho: 150,  c: 1000, cls: "ins" },
    vip:       { name: "Vacuum insulation panel",  k: 0.008, rho: 190,  c: 800,  cls: "ins" },
    straw:     { name: "Straw / sawdust fill",     k: 0.065, rho: 100,  c: 2000, cls: "ins" },
    airgap:    { name: "Still air gap (R 0.18)",   k: null,  rho: 1.2,  c: 1006, cls: "gap", R: 0.18 },
    mudbrick:  { name: "Sun-dried mud brick",      k: 0.6,   rho: 1600, c: 1000, cls: "mass" },
    rammed:    { name: "Rammed earth",             k: 0.9,   rho: 1900, c: 1000, cls: "mass" },
    stone:     { name: "Stone masonry",            k: 1.7,   rho: 2200, c: 840,  cls: "mass" },
    brick:     { name: "Fired clay brick",         k: 0.8,   rho: 1700, c: 840,  cls: "mass" },
    concrete:  { name: "Dense concrete",           k: 1.75,  rho: 2300, c: 1000, cls: "mass" },
    mudplast:  { name: "Mud plaster",              k: 0.8,   rho: 1500, c: 1000, cls: "mass" },
    gypsum:    { name: "Gypsum board",             k: 0.25,  rho: 900,  c: 1000, cls: "board" },
    timber:    { name: "Softwood timber",          k: 0.13,  rho: 500,  c: 1600, cls: "board" },
    plywood:   { name: "Plywood",                  k: 0.13,  rho: 500,  c: 1600, cls: "board" },
    canvas:    { name: "Tent canvas / polyester",  k: 0.10,  rho: 600,  c: 1300, cls: "board" },
    pesheet:   { name: "PE groundsheet / tarp",    k: 0.33,  rho: 950,  c: 1900, cls: "board" },
    felt:      { name: "Felt / wool liner",        k: 0.045, rho: 150,  c: 1300, cls: "ins" },
    bamboo:    { name: "Bamboo mat / board",       k: 0.15,  rho: 700,  c: 1300, cls: "board" },
    cplaster:  { name: "Cement plaster",           k: 0.72,  rho: 1800, c: 840,  cls: "mass" },
    pir:       { name: "PIR (polyisocyanurate) board", k: 0.022, rho: 32, c: 1400, cls: "ins" },
    snow:      { name: "Packed snow (350 kg/m³)",  k: 0.18,  rho: 350,  c: 2090, cls: "mass" },
    grp:       { name: "Fibreglass (GRP) skin",    k: 0.30,  rho: 1800, c: 1000, cls: "board" },
    custom:    { name: "Custom material",          k: 0.5,   rho: 1000, c: 1000, cls: "board" },
  };

  /* Snow conductivity from Sturm et al. (1997): k = 0.138 - 1.01 rho + 3.233 rho^2
     (rho in g/cm3) gives 0.18 W/m.K at 0.35 g/cm3. */
  /* Glazing: U [W/m2.K] centre-of-glass incl. surface resistances, g = total
     solar energy transmittance at normal incidence. Typical values; single
     glass g 0.85 is consistent with the LEDeG/GERES tau = 0.80 figure. */
  const GLAZING = {
    single:   { name: "Single clear",              U: 5.8, g: 0.85 },
    double:   { name: "Double clear",              U: 2.8, g: 0.75 },
    lowe:     { name: "Double low-e",              U: 1.8, g: 0.60 },
    triple:   { name: "Triple low-e",              U: 0.9, g: 0.50 },
    polycarb: { name: "Polycarbonate twin-wall",   U: 3.0, g: 0.70 },
  };

  /* Internal thermal mass (water drums, stone bed, PCM packs). */
  const STORE = {
    none:  { name: "None" },
    water: { name: "Water containers", c: 4186 },
    stone: { name: "Stone / rock bed", c: 840 },
    pcm:   { name: "PCM packs",        c: 2000, L: 180000, Tm: 18, dT: 4 },
  };

  /* Layer order everywhere: outermost first, room side last.
     For the floor, "outermost" is the ground side. */
  const L = (mat, t) => ({ mat, t });

  const PRESETS = {
    prefab: {
      name: "Prefab PUF sandwich box",
      L: 6, W: 4, H: 2.5, orient: 180,
      wall:  [L("steel", 0.0005), L("puf", 0.06), L("steel", 0.0005)],
      roof:  [L("steel", 0.0005), L("puf", 0.08), L("steel", 0.0005)],
      floor: [L("steel", 0.0005), L("puf", 0.05), L("plywood", 0.018)],
      win: { front: 1.5, right: 0, back: 0, left: 0 },
      glazing: "double", shutter: false, berm: false,
      store: { type: "none", mass: 0 },
      absorptance: 0.6,
    },
    passive: {
      name: "Insulated mud-brick passive solar room",
      L: 6, W: 4, H: 2.5, orient: 180,
      wall:  [L("mudbrick", 0.15), L("straw", 0.10), L("mudbrick", 0.15), L("mudplast", 0.02)],
      roof:  [L("rammed", 0.10), L("straw", 0.15), L("timber", 0.025)],
      floor: [L("rammed", 0.10), L("xps", 0.05), L("timber", 0.025)],
      win: { front: 4.8, right: 0, back: 0, left: 0 },
      glazing: "double", shutter: true, berm: false,
      store: { type: "water", mass: 400 },
      absorptance: 0.7,
    },
  };

  g.TS.MATERIALS = M;
  g.TS.GLAZING = GLAZING;
  g.TS.STORE = STORE;
  g.TS.PRESETS = PRESETS;
})(typeof window !== "undefined" ? window : globalThis);
