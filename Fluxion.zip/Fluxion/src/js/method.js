(function (g) {
  g.TS = g.TS || {};
  g.TS.METHOD_HTML = `
<h2>What the app answers</h2>
<table>
<tr><th>Output</th><th>Where it appears</th></tr>
<tr><td>1. Inside temperature from user inputs</td><td>Design tab: hourly curve with and without heating, night minimum, hours in the 17 ± 3 °C band, kerosene still needed</td></tr>
<tr><td>2. Thermal energy from solar radiation</td><td>Design tab, Output 2: sun on every surface, heat entering through glass and through sunlit walls and roof, share of heating covered by the sun</td></tr>
<tr><td>3. Heat flow against the indoor–outdoor difference, for a chosen period</td><td>Design tab, Output 3: kWh through each wall, roof, floor, windows and air leakage for the whole day, the night, daylight or any hours you choose, over time or against ΔT</td></tr>
</table>
<p>Comparative analysis of materials, size, shape, orientation and thermal storage under the same weather is on the Compare tab. The link to the ANSYS model is on the ANSYS tab.</p>

<h2>Two kinds of user</h2>
<p><b>Field check</b> is for people who know the place, the shelter and the headcount, but not U-values or albedo: district officers, NDRF teams, unit quartermasters. It asks five questions and works out every other input from them, listing each derived value with its source. <b>Designer</b> exposes every input for engineers. Both use the same engine.</p>
<p>The <b>Defence</b> and <b>Disaster relief</b> profiles change the targets and units, not the physics:</p>
<table>
<tr><th></th><th>Defence</th><th>Disaster relief</th></tr>
<tr><td>Heated to</td><td>14 °C, lower edge of 17 ± 3 °C</td><td>18 °C, WHO Housing and Health Guidelines (2018)</td></tr>
<tr><td>Safe floor</td><td>14 °C</td><td>11 °C, lower limit used by Thapa et al. for Nepal earthquake shelters</td></tr>
<tr><td>Space per person</td><td>3.5 m², Sphere minimum</td><td>4.5 m², Sphere, cold climates</td></tr>
<tr><td>Fuels</td><td>Kerosene</td><td>Kerosene, LPG, firewood</td></tr>
</table>
<h3>How Field check derives what the user cannot know</h3>
<ul>
<li>Ground temperature: the site's annual mean air temperature, the standard estimate for ground below frost depth.</li>
<li>Albedo: snow (0.6) when the month's mean is below 0 °C, otherwise bare ground (0.2).</li>
<li>Air leakage, layer conductivities, ground temperature: typical values for the shelter type, then varied, because none of them can be seen from outside.</li>
</ul>
<h3>Confidence</h3>
<p>The shelter is re-run 120 times with air leakage (lognormal, 90 % of draws within ×÷ the type's factor), conductivities (normal, ±15–20 % at 90 %) and ground temperature (±2 K, one standard deviation) drawn by Latin hypercube sampling. The answer is the share of runs whose coldest night hour stays above the safe floor, with its standard error √(p(1−p)/n). Day-to-day weather spread joins the sampling when <code>tools/fetch_nasa_daily.py</code> has produced NASA POWER daily statistics for the site; until then the storm test covers cold spells.</p>
<h3>Storm test</h3>
<p>Two normal design days, then three days with no sun, temperature lowered by a chosen amount (8 K by default) and the day's warming halved, and wind doubled. Thermal mass that carries a shelter through one cold night runs out over several sunless days; this scenario shows when. It is a stress scenario, not a probability.</p>
<h3>People and air</h3>
<p>Capacity is floor area ÷ space per person. For the people entered, the air changes needed to keep CO₂ at 1000 ppm are n·G / (580 ppm · V), with G = 0.0052 L/s per person scaled for air density; if the shelter leaks less than that, the app gives the fuel cost of opening a vent that far. When one heater cannot hold the target, it reports how many are needed from the peak hourly demand.</p>
<h3>Live sensors</h3>
<p>Readings arrive over Bluetooth Low Energy (standard Environmental Sensing service for temperature and humidity, a custom service for CO and CO₂), from a logged CSV, or from a labelled simulator. Carbon monoxide is checked against WHO indoor guideline values averaged over 15 min (100 mg/m³), 1 h (35) and 8 h (10), converted from ppm at the site's air pressure. Tonight's forecast is corrected by the gap between measured and predicted temperature, fading with the shelter's time constant.</p>

<h2>Airflow, CO₂ and heaters</h2>
<p>Outdoor air entering the shelter is computed every hour from a zonal airflow network, not CFD: the room is one well-mixed node and the flow through cracks and vents responds to the indoor–outdoor temperature difference (stack effect) and wind. Leakage follows the ASHRAE enhanced model Q = A<sub>L</sub>√(C<sub>s</sub>|ΔT| + C<sub>w</sub>v²) with one-storey coefficients; the leakage area is set so that the shelter type's typical air-change rate holds at 20 K and 3 m/s. Purpose vents use the orifice equation with C<sub>d</sub> = 0.61, low and high openings in series for the stack effect, and a pressure-coefficient difference of 0.8 (opposite walls) or 0.1 (one wall) for wind. The thermal and airflow solutions are iterated until the hourly air changes stop moving (two to four passes). Indoor CO₂ comes from a mass balance in 6-minute steps, including combustion CO₂ (2.52 kg per litre of kerosene) when the heater has no flue. CFD would add the pattern of air inside the room; none of the answers here depend on it, and ANSYS is where that level of detail belongs.</p>
<h2>Trombe wall</h2>
<p>A dark mass wall behind glass on the sunny facade, modelled as an unvented element: the sun absorbed on the mass surface (glass g-value, incidence modifier, absorptance 0.95) raises its equivalent outside temperature; the glass and air gap form its outer resistance; the mass counts towards stored heat by the same 10 cm rule as the other walls.</p>
<h2>Design checks</h2>
<ul>
<li><b>Snow:</b> IS 875 (Part 4):1987 roof shape coefficient μ = 0.8 up to 30°, falling linearly to 0 at 60°; load = μ × ground snow load (depth × density × g). With a rated roof capacity the app finds the smallest pitch that keeps within it.</li>
<li><b>Frozen ground:</b> mean annual air temperature at the site as a screening indicator (below about −2 °C permafrost is likely). The heated floor's flux into the ground is shown, and the fix is a raised floor on skids with a ventilated gap, which the model then treats as facing outside air.</li>
<li><b>Glazing:</b> the sunny-side window area that minimises fuel at this site, found by re-running the model; not a fixed code percentage.</li>
<li><b>Air:</b> CO₂ against 1000 ppm (comfort) and 5000 ppm (8-hour limit), with the vent size that restores 1000 ppm on a typical night.</li>
<li><b>Codes:</b> ECBC 2017 is not applied because it covers commercial buildings with 100 kW or more connected load. The checks used are Sphere, WHO and IS 875.</li>
</ul>
<h2>Recommendation, frugality and sensitivity</h2>
<p>The recommender keeps the floor plan and headcount and searches insulation material and thickness, sunny-side window area, glazing, orientation, night shutter, Trombe wall and water storage by coordinate descent. It minimises (1 − w)·fuel/fuel<sub>start</sub> + w·burden, where burden is the area-weighted share of materials that must be brought in and need specialist upkeep (ratings listed in <code>optimise.js</code>), and rejects designs whose heater cannot hold the target. Each recommended change is reported with its value on its own, measured by undoing it in the final design. Sensitivity moves one input at a time across a stated range; a share is that input's swing over the sum of all swings, so it depends on the ranges, which are shown.</p>
<p>The plain-language summary is assembled from these computed numbers. A language model is not used: an offline model large enough to write well needs gigabytes and a GPU that field tablets lack, and it can state numbers the engine never produced. Every figure in the summary can be traced to the engine.</p>
<h2>Site data</h2>
<p>New sites are fetched once while online: NASA POWER monthly climatology (including mean daily maximum and minimum, which replace the default 12 K day–night range) and SRTM 90 m elevation through OpenTopoData. The terrain horizon is the highest elevation angle in 16 directions out to 20 km, with Earth curvature and standard refraction. Packs are stored on the device and can be exported and imported as files.</p>
<h2>Mission flow</h2>
<p>Three inputs (purpose, location, occupants; plus disaster type for relief) set everything else. The shelter type follows the purpose and disaster; its size follows the occupants at 3.5 m² per person (4.5 m² for cold-climate relief, Sphere) with units of up to 40 m², or as many family tents as needed. The recommender then searches only what can be built and carried for the mission (factory insulation up to 200 mm and no stone Trombe wall for airlifted military shelters; a liner of up to 30 mm and no glass for tents), and the result is verified against an extreme case: the month's normal minimum lowered by 6.5 K, the IMD severe-cold-wave departure, for three days without sun and with doubled wind. If one heater cannot hold the safe floor, insulation is increased step by step. Every material stays selectable.</p>
<p>The ANSYS check runs the design in ANSYS through the team's bridge (contract v1.0) and puts ANSYS's coldest and warmest indoor air beside the app's own model for the same inputs. The app's numbers are not adjusted to match. A mock bridge returns the stored real base-case run, so its row compares that case, not the current design.</p>
<h2>3D twin</h2>
<p>Three.js view of the design. Materials: outer layer of each surface. Inner-surface temperature: one value per surface from the zone model at the chosen hour, coloured relative to the other surfaces; corner and thermal-bridge detail needs the ANSYS temperature field. Airflow: particles scaled to the computed air changes, in low and out high; a picture of the airflow model's result, not CFD.</p>
<h2>Weather alert and forecast run</h2>
<p>Pre-deployment sync caches a 14-day hourly forecast (past 7 and next 7 days) from Open-Meteo, which serves global weather-model output. The alert applies the India Meteorological Department's cold-wave departure criteria to the forecast: <b>SEVERE</b> when a forecast daily minimum is 6.5 K or more below the month's normal minimum (NASA POWER, lapse-corrected), <b>WATCH</b> at 4.5 K or more below normal or wind above 15 m/s. Verify the thresholds against IMD's current definitions for hill stations. The whole forecast is also run through the shelter model hour by hour, so the alert reports the indoor temperature and fuel for each forecast night. Forecast cloud cover raises the night-sky emissivity by (1 + 0.34 C²), the team-specified factor; published coefficients range roughly 0.2 to 0.35. A trained neural-network predictor was not used: there is no labelled blizzard data to train or test one on, and any probability it showed would be unverifiable.</p>
<h2>Condensation, hoarfrost and skin temperature</h2>
<p>Indoor humidity comes from an hourly water-vapour balance (45 g/h per resting person; an unflued kerosene heater adds 1.09 kg of water per litre burnt, from C<sub>12</sub>H<sub>26</sub> stoichiometry). Each inner surface temperature θ<sub>si</sub> = θ<sub>air</sub> − U R<sub>si</sub>(θ<sub>air</sub> − θ<sub>out,eq</sub>) is compared with the indoor dew point (Magnus, over water or ice); below 0 °C the deposit is frost. Inside the construction a simplified Glaser check (ISO 13788) at the coldest hour compares the vapour-pressure line through the layers' vapour resistances (μ·d, ISO 10456 values; fabrics, felt and bamboo estimated) with saturation, and flags a plane only where more than 1 g/m² would collect per day. The outer skin temperature θ<sub>so</sub> = θ<sub>eq</sub> + U R<sub>se</sub>(θ<sub>air</sub> − θ<sub>eq</sub>) is reported as its contrast with outside air; no claim is made about detection by any particular sensor.</p>
<h2>Pareto optimiser</h2>
<p>125 designs (insulation thickness 25–200 mm × sunny-side window-to-wall ratio 0–0.4 × water storage 0–1200 kg) are run; designs whose heater cannot hold the target are dropped; non-dominated sorting keeps the designs no other design beats on both fuel and cost (when every unit rate is entered) or transported mass. The suggestion is the knee, the front point nearest the normalised ideal, re-run with the coupled airflow model and shown against the baseline.</p>
<h2>Logistics</h2>
<p>Masses and quantities come from the design (glazing 10–30 kg/m² by type; water for storage is filled on site and not transported). Unit rates, vehicle payloads and assembly man-hours per m² are entered by the user and stored on the device: no helicopter payload, schedule rate or labour norm is assumed.</p>
<h2>ANSYS APDL starter script</h2>
<p>For each design the app writes a Mechanical APDL script (SOLID90 transient thermal; uniform shell, effective air body, glass block; outside faces driven by the app's hourly sol-air temperatures; 48 h). It has not been run in ANSYS from this environment and must be checked once against the team's Workbench model, which remains the reference.</p>
<h2>Report</h2>
<p>The PDF report is built on the device with jsPDF: summary, inputs, plan, elevation, sections and a 3-D view drawn from the design, Outputs 1 to 3, checks, sensitivity, recommendation, a bill of quantities (quantities only; local rates are entered in the CSV) and method notes.</p>

<h2>Thermal model</h2>
<p>The shelter is one zone, solved hour by hour with the simple hourly method of EN ISO 13790:2008 (Annex C). Three temperatures are tracked: room air θ<sub>air</sub>, inner surfaces θ<sub>s</sub> and the heat-storing mass θ<sub>m</sub>. They are joined by five conductances:</p>
<div class="eq">H<sub>ve</sub> = ρ<sub>air</sub>(z) c<sub>p</sub> n V / 3600; &nbsp; H<sub>tr,w</sub> = Σ U<sub>w</sub>A<sub>w</sub>; &nbsp; H<sub>tr,is</sub> = 3.45 A<sub>t</sub>; &nbsp; H<sub>tr,ms</sub> = 9.1 A<sub>m</sub>; &nbsp; 1/H<sub>tr,em</sub> = 1/H<sub>tr,op</sub> − 1/H<sub>tr,ms</sub></div>
<p>The mass temperature is stepped with the Crank–Nicolson scheme of ISO 13790 C.2, then θ<sub>s</sub> and θ<sub>air</sub> follow from the node balances. Comfort is judged on the operative temperature θ<sub>op</sub> = 0.3 θ<sub>air</sub> + 0.7 θ<sub>s</sub>. The design day is repeated until the result repeats itself to 10<sup>−4</sup> K, so the answer does not depend on a starting temperature.</p>
<p>Two runs are made for every design: one with no heating (the passive performance) and one with a kerosene heater that holds the chosen operative temperature, up to the heater's maximum burn rate (ISO 13790 C.4 procedure, applied to θ<sub>op</sub>). Comfort hours come from the first run, fuel from the second, so the two can never contradict each other.</p>

<h3>Envelope</h3>
<p>U = 1 / (R<sub>si</sub> + Σ d/k + R<sub>se</sub>). Inside resistances 0.13 (walls), 0.10 (roof), 0.17 (floor) m²·K/W after ISO 6946; still air gaps use R = 0.18. Outside, R<sub>se</sub> = 1/(h<sub>c</sub> + h<sub>r</sub>) with h<sub>c</sub> = (4 + 4v)(ρ/ρ<sub>0</sub>)<sup>0.8</sup>: thinner air at altitude carries less heat away. The floor sees the ground temperature through an extra 0.5 m²·K/W; an earth-bermed back wall sees it through 1.0 m²·K/W.</p>
<p>Sun and sky act on walls and roof through the sol-air temperature:</p>
<div class="eq">θ<sub>sa</sub> = θ<sub>e</sub> + R<sub>se</sub> [ α I − F<sub>sky</sub> h<sub>r</sub> (θ<sub>e</sub> − θ<sub>sky</sub>) ] &nbsp;&nbsp; (F<sub>sky</sub> = 1 roof, 0.5 walls)</div>
<p>Heat storage follows ISO 13786 and ISO 13790 §12.3.1.2: each element counts its layers from the room side up to 10 cm, the first insulation layer, or its mid-plane, whichever comes first; C<sub>m</sub> = Σ κ<sub>j</sub>A<sub>j</sub> and A<sub>m</sub> = C<sub>m</sub>² / Σ A<sub>j</sub>κ<sub>j</sub>². Water containers, a rock bed or PCM packs add to C<sub>m</sub>; PCM adds its latent heat L/ΔT across its melting range.</p>
<p>Glazing gain is A<sub>w</sub> · 0.8 (frame) · g · (I<sub>beam</sub>·IAM + 0.9 I<sub>diffuse</sub>), with the ASHRAE incidence-angle modifier. A night shutter adds 0.4 m²·K/W and closes from sunset to sunrise.</p>

<h3>Weather and sun</h3>
<p>Monthly climate comes from NASA POWER for the 0.5° grid cell. Its temperature is for the cell's mean elevation, which in the Himalaya can be a kilometre above the site, so it is moved to the site altitude at 6.5 K/km. The design day runs from the mean minus half the day–night range at sunrise to the mean plus half at 14:00. Hourly measured data can replace the design day.</p>
<p>Daily solar on the ground is split into hours with Collares-Pereira and Rabl, into beam and diffuse with Erbs, and turned onto each wall with an isotropic sky plus ground reflection (snow albedo 0.6 by default). The sun position uses Cooper's declination and Spencer's equation of time at Indian Standard Time. Beam light is blocked when the sun is below the terrain horizon you enter.</p>
<p>The sky temperature uses the Berdahl–Martin clear-sky emissivity with its pressure correction, ε = 0.711 + 0.56(T<sub>dp</sub>/100) + 0.73(T<sub>dp</sub>/100)² + 0.013 cos(2πh/24) + 0.00012(P − 1000). At Leh's 660 hPa this makes the night sky about 30 K colder than the air, which is why roofs lose so much heat after sunset there.</p>

<h3>Fuel and air</h3>
<p>Kerosene still needed = heat from the heater ÷ (energy per litre × heater efficiency). Defaults: 9.58 kWh/L (net calorific value 43.8 MJ/kg, IPCC 2006, at about 0.79 kg/L), 60 % efficiency and 0.7 L/h maximum burn. All three are inputs. Indoor CO₂ is the steady state from occupants (0.0052 L/s per person, scaled for air density) at the chosen air-change rate; the heater is assumed flued.</p>

<h2>Checks built into every run</h2>
<ul>
<li>Energy balance: gains − losses − change in stored heat over the simulated span is shown under <i>Envelope and model check</i>. It closes to rounding error (about 10<sup>−13</sup> %), which shows the heat-flow breakdown in Output 3 adds up exactly.</li>
<li>The hourly solar split returns exactly the daily total entered.</li>
<li>Automated tests (<code>node tests/run_tests.js</code>): energy balance, solar conservation, heater limit, fuel arithmetic, physical trends (more insulation, less fuel; north-facing glass, more fuel), and the ANSYS journal and CSV readers on mock and on the team's real Workbench exports.</li>
</ul>

<h2>How it relates to ANSYS</h2>
<p>This model is fast enough to run hundreds of designs in a second, which ANSYS cannot. ANSYS solves the same shelter in full 3-D conduction and is the reference. The ANSYS tab writes the Workbench journal for any design and reads the results back, so the difference between the two is measured, not assumed. Export <i>ANSYS boundary tables</i> to give the ANSYS model the same hourly air, sky and sun as the app.</p>

<h2>Limits</h2>
<ul>
<li>One well-mixed zone; temperature differences between rooms or floor and ceiling are not modelled.</li>
<li>Heating only. Hot-climate sites run, but overheating is reported, not cooled.</li>
<li>Tents are modelled as boxes of the same floor area and height; the double fly is two fabric layers with a still air gap. Published calibrated tent models reach about 2 °C hourly error; this simpler model has not yet been compared with those measurements.</li>
<li>Fuel efficiencies other than kerosene, and the LPG and firewood burn rates, are assumptions to be replaced with tested values.</li>
<li>Ground under the floor is held at the ground temperature you enter; ISO 13370 ground modelling is not included.</li>
<li>No moisture model: condensation and frost inside walls are not predicted.</li>
<li>Clear-sky emissivity at night, which is the cold case; cloud cover would reduce the night loss.</li>
<li>Material values are typical figures. Use supplier data where you have it; every layer property is editable.</li>
</ul>

<h2>Sources</h2>
<ul>
<li>EN ISO 13790:2008, Energy performance of buildings: calculation of energy use for space heating and cooling, Annex C.</li>
<li>ISO 6946:2017 (surface and air-gap resistances); ISO 13786:2017 (dynamic thermal characteristics); ISO 10456:2007 and CIBSE Guide A (material properties).</li>
<li>M. Collares-Pereira, A. Rabl, Solar Energy 22 (1979) 155–164.</li>
<li>D.G. Erbs, S.A. Klein, J.A. Duffie, Solar Energy 28 (1982) 293–302.</li>
<li>J.A. Duffie, W.A. Beckman, Solar Engineering of Thermal Processes, 4th ed., Wiley, 2013.</li>
<li>P. Berdahl, M. Martin, Emissivity of clear skies, Solar Energy 32 (1984) 663–664; M. Martin, P. Berdahl, Solar Energy 33 (1984) 321–336 (hourly and pressure corrections).</li>
<li>A.K. Persily, L. de Jonge, Indoor Air 27 (2017) 868–879 (CO₂ generation rates).</li>
<li>IPCC 2006 Guidelines for National Greenhouse Gas Inventories, Vol. 2, Table 1.2 (kerosene net calorific value).</li>
<li>NASA POWER climatology API, power.larc.nasa.gov; SRTM 90 m via OpenTopoData, api.opentopodata.org.</li>
<li>ASHRAE Handbook, Fundamentals, Ventilation and Infiltration chapter (enhanced leakage model, orifice flow).</li>
<li>IS 875 (Part 4):1987, Code of practice for design loads: snow loads.</li>
<li>Sphere Association, The Sphere Handbook, 2018, Shelter and Settlement Standard 3 (living space).</li>
<li>WHO Housing and Health Guidelines, 2018 (18 °C minimum indoor temperature in cold seasons); WHO Guidelines for Indoor Air Quality: Selected Pollutants, 2010 (carbon monoxide).</li>
<li>Thapa et al., winter thermal performance of temporary shelters after the 2015 Nepal earthquake (as cited in Tan &amp; Tan, Buildings 11 (2021) 655).</li>
<li>C. Cornaro et al., Energy and Buildings 88 (2015) 122–134; UNHCR/IFRC family tent model calibrated at BBRI, Brussels (project reference set).</li>
<li>LEDeG and GERES passive solar building guidance for Ladakh (south glazing about 20 % of floor area, glass transmittance 0.80).</li>
</ul>`;
})(typeof window !== "undefined" ? window : globalThis);
