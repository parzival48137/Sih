/* Site data packs. Fetched once while online (before deployment), then the
   app runs offline from the cached pack; packs export and import as JSON so a
   unit can carry them on a USB stick.
   Sources:
   - NASA POWER climatology (power.larc.nasa.gov), community RE: monthly
     T2M, T2M_MAX, T2M_MIN, ALLSKY_SFC_SW_DWN, RH2M, WS10M for the 0.5 deg cell
   - Elevation through the Open-Meteo elevation API (Copernicus GLO-90 DEM,
     90 m, derived from TanDEM-X; 100 points per call)
   Terrain horizon: 16 directions x 7 distances (0.5-20 km); elevation angle
   atan((z - z0 - 2 m - d^2 / 2R') / d), R' = Earth radius / (1 - 0.13) for
   standard refraction; the horizon is the highest angle in each direction. */
(function (g) {
  "use strict";
  const TS = g.TS;
  const KEY = "thermashelter.sites.v1";
  const R_E = 6371000, K_REF = 0.13, DIST = [500, 1000, 2000, 4000, 7000, 12000, 20000], NDIR = 16;
  const POWER = "https://power.larc.nasa.gov/api/temporal/climatology/point";
  const TOPO = "https://api.open-meteo.com/v1/elevation";
  const MONTHS = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  function parsePower(json) {
    const p = json.properties.parameter, c = json.geometry.coordinates;
    const arr = k => MONTHS.map(m => p[k][m]);
    return { cell: { lon: +c[0].toFixed(3), lat: +c[1].toFixed(3), elev: Math.round(c[2]) },
      T2M: arr("T2M"), TMAX: p.T2M_MAX ? arr("T2M_MAX") : null, TMIN: p.T2M_MIN ? arr("T2M_MIN") : null,
      GHI: arr("ALLSKY_SFC_SW_DWN"), RH: arr("RH2M"), WS: arr("WS10M") };
  }
  async function fetchClimate(lat, lon, fetchFn) {
    const f = fetchFn || g.fetch.bind(g);
    const url = `${POWER}?parameters=T2M,T2M_MAX,T2M_MIN,ALLSKY_SFC_SW_DWN,RH2M,WS10M&community=RE&longitude=${lon}&latitude=${lat}&format=JSON`;
    const r = await f(url); if (!r.ok) throw new Error("NASA POWER answered " + r.status);
    return parsePower(await r.json());
  }
  /* destination point at distance d (m) and bearing b (deg) */
  function dest(lat, lon, b, d) {
    const p1 = lat * Math.PI / 180, l1 = lon * Math.PI / 180, br = b * Math.PI / 180, a = d / R_E;
    const p2 = Math.asin(Math.sin(p1) * Math.cos(a) + Math.cos(p1) * Math.sin(a) * Math.cos(br));
    const l2 = l1 + Math.atan2(Math.sin(br) * Math.sin(a) * Math.cos(p1), Math.cos(a) - Math.sin(p1) * Math.sin(p2));
    return [p2 * 180 / Math.PI, l2 * 180 / Math.PI];
  }
  function horizonPoints(lat, lon) {
    const pts = [[lat, lon]];
    for (let i = 0; i < NDIR; i++) for (const d of DIST) pts.push(dest(lat, lon, i * 360 / NDIR, d));
    return pts;
  }
  async function fetchElevations(pts, fetchFn) {
    const f = fetchFn || g.fetch.bind(g), out = [];
    for (let i = 0; i < pts.length; i += 100) {
      if (i) await sleep(400);
      const ch = pts.slice(i, i + 100);
      const r = await f(`${TOPO}?latitude=${ch.map(p => p[0].toFixed(5)).join(",")}&longitude=${ch.map(p => p[1].toFixed(5)).join(",")}`);
      if (!r.ok) throw new Error("Open-Meteo elevation answered " + r.status);
      const j = await r.json(); if (!Array.isArray(j.elevation)) throw new Error("Open-Meteo elevation: " + (j.reason || "unexpected reply"));
      out.push(...j.elevation);
    }
    return out;
  }
  /* elevations: [z0, then NDIR x DIST in order] -> {z0, horizon[16], profiles} */
  function horizonFrom(z) {
    const z0 = z[0], Reff = R_E / (1 - K_REF), horizon = [], profiles = [];
    for (let i = 0; i < NDIR; i++) {
      let best = 0; const prof = [];
      DIST.forEach((d, j) => { const zz = z[1 + i * DIST.length + j]; prof.push(zz);
        const ang = Math.atan((zz - z0 - 2 - d * d / (2 * Reff)) / d) * 180 / Math.PI; if (ang > best) best = ang; });
      horizon.push(+best.toFixed(1)); profiles.push(prof);
    }
    return { z0, horizon, profiles, dist: DIST };
  }
  async function buildPack(name, lat, lon, fetchFn, onStep) {
    onStep && onStep("Fetching NASA POWER climatology…");
    const clim = await fetchClimate(lat, lon, fetchFn);
    onStep && onStep("Fetching SRTM elevation and terrain (2 requests)…");
    const terr = horizonFrom(await fetchElevations(horizonPoints(lat, lon), fetchFn));
    return Object.assign({ id: "site-" + Date.now().toString(36), name, lat: +(+lat).toFixed(4), lon: +(+lon).toFixed(4), alt: Math.round(terr.z0),
      horizon: terr.horizon, terrain: terr, source: { power: "NASA POWER climatology, community RE", dem: "Copernicus GLO-90 via Open-Meteo", fetched: new Date().toISOString().slice(0, 10) } }, clim);
  }

  /* ---------------------------------------------------------- storage */
  function load() { try { const a = JSON.parse(localStorage.getItem(KEY) || "[]"); return Array.isArray(a) ? a : []; } catch (e) { return []; } }
  function persist(list) { try { localStorage.setItem(KEY, JSON.stringify(list)); } catch (e) {} }
  function install(rec) {
    const list = load().filter(s => s.id !== rec.id); list.push(rec); persist(list);
    const i = TS.SITES.findIndex(s => s.id === rec.id); if (i >= 0) TS.SITES[i] = rec; else TS.SITES.push(rec);
  }
  function remove(id) { persist(load().filter(s => s.id !== id)); const i = TS.SITES.findIndex(s => s.id === id); if (i >= 0 && TS.SITES[i].source) TS.SITES.splice(i, 1); }
  function exportPack() { return JSON.stringify({ format: "thermashelter-site-pack", version: 1, sites: load() }, null, 1); }
  function importPack(text) {
    const o = JSON.parse(text); if (o.format !== "thermashelter-site-pack") throw new Error("Not a Fluxion site pack.");
    o.sites.forEach(s => { if (!s.T2M || s.T2M.length !== 12 || !s.cell) throw new Error("Site " + s.name + " is incomplete."); install(s); });
    return o.sites.length;
  }
  if (typeof localStorage !== "undefined") load().forEach(s => { if (!TS.SITES.some(x => x.id === s.id)) TS.SITES.push(s); });

  TS.sitedata = { fetchClimate, parsePower, fetchElevations, horizonPoints, horizonFrom, buildPack, install, remove, load, exportPack, importPack, dest, DIST, NDIR };
  if (typeof module !== "undefined") module.exports = TS;
})(typeof window !== "undefined" ? window : globalThis);
