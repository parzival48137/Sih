/* Airflow: how much outdoor air actually enters the shelter each hour.
   This is a zonal airflow network, not CFD: the room is one well-mixed node,
   and flow through cracks and vents is driven by indoor-outdoor temperature
   difference (stack effect) and wind. That is the level of detail the CO2 and
   fuel answers need; CFD would add the air pattern inside the room, which
   they do not depend on.

   Leakage (cracks, fabric, door seals), ASHRAE Fundamentals enhanced model:
       Q_L = A_L * sqrt(Cs*|dT| + Cw*v^2)     [L/s, A_L in cm2]
       Cs = 0.000145 (one storey), Cw = 0.000246 (shielding class 2, one storey)
   A_L is fixed from the shelter type's typical air-change rate at a reference
   condition (dT = 20 K, v = 3 m/s), so hourly air changes then follow physics.
   Purpose-made vents, a low and a high opening of area A separated by height h:
       stack  Q_s = Cd * A_eff * sqrt(2 g h |dT| / T_in),  1/A_eff^2 = 1/A_lo^2 + 1/A_hi^2
       wind   Q_w = Cd * A_w * v * sqrt(dCp),  dCp = 0.8 cross, 0.1 single-sided
   Combined as Q = sqrt(Q_L^2 + Q_s^2 + Q_w^2). Cd = 0.61. */
(function (g) {
  "use strict";
  const TS = g.TS;
  const CS = 0.000145, CW = 0.000246, CD = 0.61, G = 9.81, REF_DT = 20, REF_V = 3;
  const CO2_KG_PER_UNIT = { kerosene: 2.52, lpg: 3.0, wood: 1.75 }; // per L or kg burnt (stoichiometric)

  function volume(d) { return TS.engine.geom(d).V; }
  /* leakage area (cm2) that reproduces the type's air changes at reference conditions */
  function leakArea(d) { const Q = d.ach * volume(d) / 3.6; return Q / Math.sqrt(CS * REF_DT + CW * REF_V * REF_V); }

  function hourlyACH(d, tin, tout, wind) {
    const V = volume(d), AL = leakArea(d), v = d.vents || {};
    const lo = (v.low || 0) / 1e4, hi = (v.high || 0) / 1e4, h = v.h || Math.max(0.5, d.H - 0.6);
    const Aeff = lo > 0 && hi > 0 ? 1 / Math.sqrt(1 / (lo * lo) + 1 / (hi * hi)) : 0;
    const dCp = v.cross ? 0.8 : 0.1;
    return tin.map((ti, i) => {
      const dT = Math.abs(ti - tout[i]), w = wind[i];
      const QL = AL * Math.sqrt(CS * dT + CW * w * w) / 1000;                 // m3/s
      const Qs = CD * Aeff * Math.sqrt(2 * G * h * dT / (ti + 273.15));
      const Qw = CD * (lo + hi) / 2 * w * Math.sqrt(dCp);
      return Math.sqrt(QL * QL + Qs * Qs + Qw * Qw) * 3600 / V;
    });
  }

  /* Run the thermal engine with air changes that respond to each hour's
     temperatures and wind (fixed-point iteration, converges in 2-4 passes). */
  function simulate(d0, site, ops, fuelKey) {
    const d = Object.assign({}, d0);
    let r = TS.engine.simulate(d, site, ops), it = 0, prev = null;
    for (; it < 5; it++) {
      const ach = hourlyACH(d0, r.heated.air, r.amb, r.wind);
      if (prev && ach.every((a, i) => Math.abs(a - prev[i]) < 0.01)) break;
      d.achH = ach; prev = ach;
      r = TS.engine.simulate(d, site, ops);
    }
    r.airflow = { iterations: it + 1, achMean: mean(r.ach), achMin: Math.min(...r.ach), achMax: Math.max(...r.ach), leakArea: leakArea(d0) };
    r.co2 = co2Series(d0, r, fuelKey, ops);
    return r;
  }

  /* Indoor CO2 hour by hour from a mass balance with 6-minute steps:
     V dC/dt = G_people + G_stove(unflued) - Q (C - C_out) */
  function co2Series(d, r, fuelKey, ops) {
    const V = volume(d), rho = r.net.rhoAir, out = 420;
    const Gp = d.people * 0.0052 / 1000 * (1.2 / rho);              // m3/s at site density
    const stoveCO2 = d.unflued && fuelKey ? CO2_KG_PER_UNIT[fuelKey] : 0;
    const rhoCO2 = 1.84 * rho / 1.2;                                 // kg/m3 at site pressure
    let C = out + 400; const series = [];
    for (let rep = 0; rep < 3; rep++) for (let i = 0; i < r.N; i++) {
      const occ = (r.hours[i] >= 18 || r.hours[i] < 8) ? d.people : Math.ceil(d.people / 2);
      const fuelPerS = r.heated.phi[i] / 1000 / (ops.kwhPerL * ops.eta) / 3600;     // L/s or kg/s
      const G = Gp * occ / Math.max(d.people, 1) + stoveCO2 * fuelPerS / rhoCO2;     // m3/s
      const Q = r.ach[i] * V / 3600;
      for (let k = 0; k < 10; k++) C += 360 * (G * 1e6 - Q * (C - out)) / V;
      if (rep === 2) series.push(C);
    }
    return { ppm: series, max: Math.max(...series), mean: mean(series), unflued: !!d.unflued };
  }

  /* Vent area (cm2 each, low + high) giving `achNeed` on the night-time
     median indoor-outdoor difference, on top of leakage. */
  function ventFor(d, achNeed, dT, wind) {
    const V = volume(d), QL = leakArea(d) * Math.sqrt(CS * dT + CW * wind * wind) / 1000, Qn = achNeed * V / 3600;
    if (Qn <= QL) return 0;
    const Qs = Math.sqrt(Qn * Qn - QL * QL), h = (d.vents && d.vents.h) || Math.max(0.5, d.H - 0.6);
    const Aeff = Qs / (CD * Math.sqrt(2 * G * h * Math.max(dT, 1) / 288));
    return Math.ceil(Aeff * Math.SQRT2 * 1e4 / 10) * 10;   // equal low and high openings
  }
  function mean(a) { return a.reduce((s, v) => s + v, 0) / a.length; }

  TS.airflow = { simulate, hourlyACH, leakArea, co2Series, ventFor, CO2_KG_PER_UNIT };
  if (typeof module !== "undefined") module.exports = TS;
})(typeof window !== "undefined" ? window : globalThis);
