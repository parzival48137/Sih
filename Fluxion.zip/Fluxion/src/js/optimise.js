/* Recommends a design: "the most efficient combination of materials, shape,
   size". Keeps the user's floor plan and headcount, searches the
   envelope, glazing, orientation and thermal storage by coordinate descent,
   and records every accepted change so the result explains itself.

   Objective, with frugality weight w in [0, 1]:
       J = (1 - w) * fuel / fuel_start + w * burden  (+ 10 if the stove cannot hold the target)
   burden in [0, 1]: area-weighted share of materials that must be brought in
   (not locally sourceable in Ladakh-type regions) and that need specialist
   upkeep. Ratings are the team's judgement, listed in LOCAL below. */
(function (g) {
  "use strict";
  const TS = g.TS;
  const clone = o => JSON.parse(JSON.stringify(o));

  /* local: can be sourced or made in the region; upkeep: 0 none, 1 some care, 2 specialist */
  const LOCAL = {
    straw: [1, 0, "local straw or sawdust; keep dry"], felt: [1, 0, "local wool felt"], mudbrick: [1, 0, "made on site"],
    rammed: [1, 0, "made on site"], stone: [1, 0, "local stone"], mudplast: [1, 0, "local"], timber: [1, 0, "regional timber"],
    eps: [0, 1, "factory boards, UV and fire care"], xps: [0, 1, "factory boards"], puf: [0, 1, "factory panels, fire care"],
    rockwool: [0, 1, "factory slabs, keep dry"], aerogel: [0, 2, "imported blanket, specialist handling"], vip: [0, 2, "imported panels, puncture ruins them"],
    steel: [0, 1, "factory sheet"], plywood: [0, 1, "factory board"], concrete: [0, 1, "cement transported in"], brick: [0, 0, "kiln brick"],
  };
  const GLZ = { single: [1, 0], polycarb: [0, 1], double: [0, 1], lowe: [0, 2], triple: [0, 2] };

  function burden(d) {
    let num = 0, den = 0;
    for (const el of ["wall", "roof", "floor"]) for (const l of d[el]) {
      const p = TS.engine.layerProps(l, TS.MATERIALS), a = LOCAL[l.mat] || [0, 1];
      const w = Math.max(0.02, l.t) * (el === "roof" || el === "floor" ? d.L * d.W : 2 * (d.L + d.W) * d.H);
      num += w * ((1 - a[0]) * 0.6 + a[1] / 2 * 0.4); den += w;
    }
    const glass = Object.values(d.win).reduce((s, v) => s + v, 0), gz = GLZ[d.glazing] || [0, 1];
    num += glass * 0.1 * ((1 - gz[0]) * 0.6 + gz[1] / 2 * 0.4); den += glass * 0.1;
    if (d.trombe && d.trombe.area > 0) { num += 0; den += d.trombe.area * 0.1; }
    return den > 0 ? num / den : 0;
  }

  /* put insulation of material m and thickness t into walls and roof:
     replace the existing insulation layer, or add one outside the mass */
  function setIns(d, m, t) {
    if (!(LOCAL[m] || [0])[0]) t = Math.min(t, 0.2);   // brought-in insulation capped at 200 mm
    for (const el of ["wall", "roof"]) {
      const ls = d[el], i = TS.ansys.insulationIndex(ls), cls = TS.MATERIALS[ls[i].mat].cls;
      if (cls === "ins") ls[i] = { mat: m, t };
      else ls.splice(Math.min(1, ls.length - 1), 0, { mat: m, t });
    }
    return d;
  }
  function insOf(d) { const l = d.wall[TS.ansys.insulationIndex(d.wall)]; return TS.MATERIALS[l.mat].cls === "ins" ? l : null; }

  function evaluate(d, site, ops) {
    const r = TS.engine.simulate(d, site, Object.assign({}, ops, { withSolarFraction: false }));
    return { fuel: r.summary.fuel_L, nightMin: r.summary.passive.nightMin, unmet: r.summary.unmetHours, burden: burden(d) };
  }

  const VARS = (d0) => {
    const Af = d0.L * d0.W, ins = insOf(d0);
    return [
      { key: "ins", label: "Insulation material", opts: ["straw", "felt", "eps", "xps", "puf", "rockwool", "aerogel"],
        set: (d, v) => setIns(d, v, (insOf(d) || { t: 0.1 }).t), get: d => (insOf(d) || {}).mat || "none", fmt: v => TS.MATERIALS[v] ? TS.MATERIALS[v].name : v },
      { key: "insT", label: "Insulation thickness", opts: [0.05, 0.1, 0.15, 0.2, 0.3],
        set: (d, v) => setIns(d, (insOf(d) || { mat: "straw" }).mat, v), get: d => (insOf(d) || {}).t || 0, fmt: v => Math.round(v * 1000) + " mm" },
      { key: "orient", label: "Orientation", opts: [180, 150, 210, 120, 240], set: (d, v) => { d.orient = v; return d; }, get: d => d.orient, fmt: v => `${TS.engine.compass(v)} (${v}°)` },
      { key: "glass", label: "Sunny-side window", opts: [0, 0.1, 0.15, 0.2, 0.25, 0.3].map(f => +(f * Af).toFixed(2)),
        set: (d, v) => { d.win.front = v; return d; }, get: d => d.win.front || 0, fmt: v => v.toFixed(1) + " m²" },
      { key: "glazing", label: "Glazing", opts: ["single", "double", "lowe", "triple"], set: (d, v) => { d.glazing = v; return d; }, get: d => d.glazing, fmt: v => TS.GLAZING[v].name },
      { key: "shutter", label: "Night shutter", opts: [false, true], set: (d, v) => { d.shutter = v; return d; }, get: d => !!d.shutter, fmt: v => (v ? "yes" : "no") },
      { key: "trombe", label: "Trombe wall (stone, 300 mm)", opts: [0, 0.3, 0.6].map(f => +(f * Math.max(0, d0.L * d0.H - (d0.win.front || 0))).toFixed(1)),
        set: (d, v) => { d.trombe = v > 0 ? { area: v, mat: "stone", t: 0.3 } : null; return d; }, get: d => (d.trombe && d.trombe.area) || 0, fmt: v => (v > 0 ? v.toFixed(1) + " m²" : "none") },
      { key: "store", label: "Water containers", opts: [0, 300, 600],
        set: (d, v) => { d.store = v > 0 ? { type: "water", mass: v } : { type: "none", mass: 0 }; return d; }, get: d => (d.store && d.store.type === "water" ? d.store.mass : 0), fmt: v => (v > 0 ? v + " kg" : "none") },
    ];
  };

  function score(e, base, w) { return (1 - w) * e.fuel / Math.max(base.fuel, 0.05) + w * e.burden + (e.unmet > 0 ? 10 : 0); }

  /* opts: { allowIns: [materials], maxT: m, noTrombe, noGlazing } keep the
     search inside what can actually be built and carried for the mission */
  function optimise(d0, site, ops, w, forbid, opts) {
    opts = opts || {};
    const vars = VARS(d0).map(v => {
      if (v.key === "ins") return Object.assign({}, v, { opts: v.opts.filter(o => !(forbid && forbid(o)) && (!opts.allowIns || opts.allowIns.includes(o))) });
      if (v.key === "insT" && opts.maxT) return Object.assign({}, v, { opts: v.opts.filter(t => t <= opts.maxT + 1e-9).concat(v.opts.some(t => t <= opts.maxT) ? [] : [opts.maxT]) });
      return v;
    }).filter(v => !(v.key === "trombe" && (opts.noTrombe || (forbid && forbid("stone")))) && !((v.key === "glass" || v.key === "glazing" || v.key === "shutter") && opts.noGlazing));
    const base = evaluate(d0, site, ops);
    let cur = clone(d0), curE = base, curJ = score(base, base, w);
    const steps = []; let evals = 1;
    for (let pass = 0; pass < 3; pass++) {
      let improved = false;
      for (const v of vars) {
        let best = null;
        for (const o of v.opts) {
          if (o === v.get(cur)) continue;
          const d = v.set(clone(cur), o), e = evaluate(d, site, ops); evals++;
          const J = score(e, base, w);
          if (J < curJ - 1e-4 && (!best || J < best.J)) best = { o, d, e, J };
        }
        if (best) {
          steps.push({ label: v.label, from: v.fmt(v.get(cur)), to: v.fmt(best.o), dFuel: best.e.fuel - curE.fuel, dNight: best.e.nightMin - curE.nightMin, dBurden: best.e.burden - curE.burden });
          cur = best.d; curE = best.e; curJ = best.J; improved = true;
        }
      }
      if (!improved) break;
    }
    // Report the net changes, each with what it is worth on its own in the final design
    const net = [];
    for (const v of vars) {
      const a = v.get(d0), b = v.get(cur);
      if (JSON.stringify(a) === JSON.stringify(b)) continue;
      const without = evaluate(v.set(clone(cur), a), site, ops); evals++;
      net.push({ label: v.label, from: v.fmt(a), to: v.fmt(b), dFuel: curE.fuel - without.fuel, dNight: curE.nightMin - without.nightMin, dBurden: curE.burden - without.burden });
    }
    net.sort((x, y) => x.dFuel - y.dFuel);
    return { design: cur, start: base, end: curE, steps: net, path: steps, evals, w };
  }

  /* One-at-a-time sensitivity over stated ranges around the current design.
     share = swing of the metric for one variable / sum of all swings. */
  function sensitivity(d0, site, ops, metric) {
    const m = metric || "fuel";
    const val = d => evaluate(d, site, ops)[m === "fuel" ? "fuel" : "nightMin"];
    const ins = insOf(d0), Af = d0.L * d0.W, o = d0.orient;
    const tests = [
      { label: "Orientation", range: "±90° from current", ds: [-90, -45, 45, 90].map(k => Object.assign(clone(d0), { orient: (o + k + 360) % 360 })) },
      { label: "Insulation thickness", range: ins ? "half to double" : "none to 100 mm",
        ds: ins ? [0.5, 2].map(k => setIns(clone(d0), ins.mat, Math.max(0.01, ins.t * k))) : [setIns(clone(d0), "eps", 0.1)] },
      { label: "Sunny-side window", range: "none to double (max 35 % of floor)", ds: [0, 0.5, 1.5, 2].map(k => { const d = clone(d0); d.win.front = Math.min(0.35 * Af, (d0.win.front || 0.1 * Af) * k); return d; }) },
      { label: "Glazing type", range: "single to triple", ds: ["single", "triple"].map(gz => Object.assign(clone(d0), { glazing: gz })) },
      { label: "Air leakage", range: "half to double", ds: [0.5, 2].map(k => Object.assign(clone(d0), { ach: d0.ach * k })) },
      { label: "Thermal mass", range: "none to 600 kg water", ds: [0, 600].map(v => Object.assign(clone(d0), { store: v ? { type: "water", mass: v } : { type: "none", mass: 0 } })) },
      { label: "Trombe wall", range: "none to half the sunny wall", ds: [0, 0.5].map(f => Object.assign(clone(d0), { trombe: f ? { area: +(f * (d0.L * d0.H - (d0.win.front || 0))).toFixed(1), mat: "stone", t: 0.3 } : null })) },
    ];
    const v0 = val(d0);
    const rows = tests.map(t => { const vs = [v0].concat(t.ds.map(val)); return { label: t.label, range: t.range, lo: Math.min(...vs), hi: Math.max(...vs), swing: Math.max(...vs) - Math.min(...vs) }; });
    const tot = rows.reduce((s, r) => s + r.swing, 0) || 1;
    rows.forEach(r => (r.share = r.swing / tot));
    return { metric: m, base: v0, rows: rows.sort((a, b) => b.swing - a.swing) };
  }

  /* Plain-language summary built from the computed numbers (no language model:
     every figure in it comes from the engine and can be traced). */
  function explain(ctx) {
    const { opt, sens, siteName, month, unit, checks } = ctx;
    const f1 = v => (+v).toFixed(1).replace(/^-/, "−");
    const top = sens.rows.slice(0, 2);
    let s = `For this shelter at ${siteName} in ${month}, ${top[0].label.toLowerCase()} has the biggest effect on ${sens.metric === "fuel" ? "fuel use" : "the coldest night temperature"} (${Math.round(top[0].share * 100)} % of the total swing across the ranges tested), followed by ${top[1].label.toLowerCase()} (${Math.round(top[1].share * 100)} %). `;
    if (opt && opt.steps.length) {
      s += `The recommended design makes ${opt.steps.length} change${opt.steps.length > 1 ? "s" : ""}: ` + opt.steps.map(st => `${st.label.toLowerCase()} from ${st.from} to ${st.to}`).join("; ") + ". ";
      s += `Together they take fuel from ${f1(opt.start.fuel)} to ${f1(opt.end.fuel)} ${unit} a day and the coldest unheated hour from ${f1(opt.start.nightMin)} to ${f1(opt.end.nightMin)} °C. `;
      if (opt.w > 0.5) s += "Because frugality is weighted heavily, it prefers materials that can be found and repaired locally, accepting some extra fuel. ";
    } else if (opt) s += "No change in the options searched improves on the current design at this frugality setting. ";
    const bad = (checks || []).filter(c => c.level === "fail" || c.level === "warn");
    if (bad.length) s += "Still to fix: " + bad.map(c => c.title.toLowerCase()).join("; ") + ".";
    return s;
  }

  /* 125-point grid: insulation thickness x sunny-side window-to-wall ratio x
     water thermal mass. Objectives: fuel (L/day) and cost (if every needed
     rate is entered) or else transported mass (kg). Non-dominated sorting
     gives the Pareto front; the knee (closest to the normalised ideal point)
     is the suggested candidate, re-simulated with the full airflow model. */
  const GRID = { insT: [0.025, 0.05, 0.1, 0.15, 0.2], wwr: [0, 0.1, 0.2, 0.3, 0.4], water: [0, 300, 600, 900, 1200] };
  function pareto(d0, site, ops, costFn) {
    const ins = insOf(d0) || { mat: "eps" }, pts = [];
    for (const t of GRID.insT) for (const r of GRID.wwr) for (const m of GRID.water) {
      const d = setIns(clone(d0), ins.mat, t);
      d.win.front = +(r * d.L * d.H).toFixed(2);
      d.store = m > 0 ? { type: "water", mass: m } : { type: "none", mass: 0 };
      const e = evaluate(d, site, ops), c = costFn(d);
      pts.push({ insT: t, wwr: r, water: m, d, fuel: e.fuel, unmet: e.unmet, nightMin: e.nightMin, cost: c.cost, mass: c.mass, costComplete: c.complete });
    }
    const useCost = pts.every(p => p.costComplete);
    const y = p => (useCost ? p.cost : p.mass);
    const ok = pts.filter(p => p.unmet === 0);
    const front = ok.filter(p => !ok.some(q => q !== p && q.fuel <= p.fuel && y(q) <= y(p) && (q.fuel < p.fuel || y(q) < y(p)))).sort((a, b) => a.fuel - b.fuel);
    const fx = [Math.min(...front.map(p => p.fuel)), Math.max(...front.map(p => p.fuel))], fy = [Math.min(...front.map(y)), Math.max(...front.map(y))];
    const nz = (v, r) => (r[1] - r[0] > 1e-9 ? (v - r[0]) / (r[1] - r[0]) : 0);
    const knee = front.reduce((b, p) => { const dd = Math.hypot(nz(p.fuel, fx), nz(y(p), fy)); return !b || dd < b.dd ? { p, dd } : b; }, null);
    return { pts, front, knee: knee && knee.p, objective: useCost ? "cost" : "mass", feasible: ok.length };
  }

  TS.optimise = { optimise, sensitivity, explain, burden, setIns, LOCAL, pareto, GRID, insOf };
  if (typeof module !== "undefined") module.exports = TS;
})(typeof window !== "undefined" ? window : globalThis);
