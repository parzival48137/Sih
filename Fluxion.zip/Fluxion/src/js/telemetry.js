/* Live sensors. One interface, several sources:
     Simulator      - synthetic readings, always labelled "Simulated"
     CSV replay     - replays a logger file (t_s, T, RH, CO, CO2)
     Web Bluetooth  - Chrome on Windows/Android/desktop, standard GATT
   Native adapters with the same message format live in native/ (Tauri Rust,
   Capacitor). Every source calls onReading({t, T, RH, CO, CO2, src}).
   GATT contract (firmware side must match):
     Environmental Sensing 0x181A: Temperature 0x2A6E sint16 0.01 degC,
                                   Humidity 0x2A6F uint16 0.01 %
     Fluxion gas service 8f1d0001-...: CO ppm uint16 (…0002), CO2 ppm uint16 (…0003) */
(function () {
  "use strict";
  const TS = window.TS, C = TS.charts;
  const $ = id => document.getElementById(id);
  const GATT = {
    ess: 0x181a, temp: 0x2a6e, rh: 0x2a6f,
    gas: "8f1d0001-6c2b-4b8e-9a3f-5e0c1d2a7b10",
    co: "8f1d0002-6c2b-4b8e-9a3f-5e0c1d2a7b10",
    co2: "8f1d0003-6c2b-4b8e-9a3f-5e0c1d2a7b10",
  };

  /* ---------------------------------------------------------- sources */
  function Simulator(onReading) {
    let t = 0, timer = null, fault = 0;
    const last = () => TS.fieldLast;
    return {
      label: "Simulated",
      start() {
        timer = setInterval(() => {
          t += 60; // one reading = one minute of shelter time
          const L = last(), hr = (new Date().getHours() + t / 3600) % 24;
          const base = L ? L.r.heated.op[Math.floor(hr)] : 12;
          const co2 = L ? L.r.summary.co2_ppm : 1500;
          if (fault > 0) fault = Math.min(fault + 6, 260);
          onReading({ t, T: base + 0.25 * Math.sin(t / 900) + (Math.random() - 0.5) * 0.15, RH: 45 + 3 * Math.sin(t / 2000),
            CO: 2 + Math.random() + fault, CO2: co2 * (0.97 + 0.06 * Math.random()), src: "Simulated" });
        }, 1000);
      },
      stop() { clearInterval(timer); },
      fault() { fault = fault ? 0 : 1; return !!fault; },
    };
  }
  function CsvReplay(text, onReading) {
    const rows = TS.ansys.parseCSV(text), head = rows[0].map(h => h.trim().toLowerCase());
    const col = re => head.findIndex(h => re.test(h));
    const it = col(/^t(_s|ime)?/), iT = col(/^(t|temp)/), iRH = col(/rh|hum/), iCO = col(/^co$|co_ppm|carbon mon/), iC2 = col(/co2/);
    if (iT < 0) throw new Error("Need a temperature column (T or temp).");
    const data = rows.slice(1).map((r, k) => ({ t: it >= 0 && it !== iT ? +r[it] : k * 60, T: +r[iT], RH: iRH >= 0 ? +r[iRH] : null,
      CO: iCO >= 0 ? +r[iCO] : null, CO2: iC2 >= 0 ? +r[iC2] : null, src: "Replay" })).filter(d => isFinite(d.T));
    let i = 0, timer = null;
    return { label: "Replay", start() { timer = setInterval(() => { if (i >= data.length) return clearInterval(timer); onReading(data[i++]); }, 250); }, stop() { clearInterval(timer); } };
  }
  function WebBle(onReading, onStatus) {
    let dev = null; const cur = { T: null, RH: null, CO: null, CO2: null }; let t0 = Date.now();
    const push = () => onReading(Object.assign({ t: (Date.now() - t0) / 1000, src: "Bluetooth" }, cur));
    async function sub(service, ch, parse) {
      try {
        const c = await service.getCharacteristic(ch);
        c.addEventListener("characteristicvaluechanged", e => { parse(e.target.value); push(); });
        await c.startNotifications();
      } catch (e) { onStatus("Characteristic " + ch + " not available: " + e.message); }
    }
    return {
      label: "Bluetooth",
      async start() {
        if (!navigator.bluetooth) throw new Error("This browser has no Web Bluetooth. Use Chrome, or the Windows or Android app.");
        dev = await navigator.bluetooth.requestDevice({ filters: [{ services: [GATT.ess] }], optionalServices: [GATT.gas] });
        dev.addEventListener("gattserverdisconnected", () => onStatus("Sensor disconnected."));
        const srv = await dev.gatt.connect();
        onStatus("Connected to " + (dev.name || "sensor"));
        const ess = await srv.getPrimaryService(GATT.ess);
        await sub(ess, GATT.temp, v => (cur.T = v.getInt16(0, true) / 100));
        await sub(ess, GATT.rh, v => (cur.RH = v.getUint16(0, true) / 100));
        try { const gas = await srv.getPrimaryService(GATT.gas);
          await sub(gas, GATT.co, v => (cur.CO = v.getUint16(0, true)));
          await sub(gas, GATT.co2, v => (cur.CO2 = v.getUint16(0, true)));
        } catch (e) { onStatus("No gas service on this device; showing temperature and humidity only."); }
      },
      stop() { if (dev && dev.gatt.connected) dev.gatt.disconnect(); },
    };
  }

  /* Tauri desktop: Rust btleplug backend (native/tauri_ble.rs) emits "telemetry" events */
  function TauriBle(onReading, onStatus) {
    let un = null;
    return {
      label: "Bluetooth",
      async start() {
        const T = window.__TAURI__;
        if (!T || !T.core) throw new Error("Desktop Bluetooth needs the Windows app built with native/tauri_ble.rs.");
        un = await T.event.listen("telemetry", e => onReading(Object.assign({ src: "Bluetooth" }, e.payload)));
        await T.core.invoke("ble_start"); onStatus("Scanning for a Fluxion sensor…");
      },
      stop() { if (un) un(); if (window.__TAURI__) window.__TAURI__.core.invoke("ble_stop").catch(() => {}); },
    };
  }

  /* ---------------------------------------------------------- alarms */
  /* WHO indoor air quality guidelines for CO (2010), mg/m3 averaged over the window */
  const WHO_CO = [{ min: 15, mg: 100 }, { min: 60, mg: 35 }, { min: 480, mg: 10 }];
  function ppmToMg(ppm, alt) { const P = TS.engine.pressurePa(alt || 0); return ppm * 1e-6 * P / (8.314 * 293.15) * 28.01 * 1000; }

  /* ---------------------------------------------------------- UI */
  let src = null, buf = [];
  function status(s) { $("liveStatus").textContent = s; }
  function onReading(d) {
    buf.push(d); if (buf.length > 600) buf.shift();
    const alt = TS.fieldLast ? TS.fieldLast.m.site.alt : 0;
    const tile = (id, v, dg, u) => ($(id).innerHTML = v == null || !isFinite(v) ? "–" : `${(+v).toFixed(dg).replace(/^-/, "−")}<small>${u}</small>`);
    tile("lvT", d.T, 1, " °C"); tile("lvRH", d.RH, 0, " %"); tile("lvCO", d.CO, 0, " ppm"); tile("lvCO2", d.CO2, 0, " ppm");
    $("liveSrc").textContent = d.src === "Simulated" ? "Simulated readings, not a real sensor" : d.src === "Replay" ? "Replaying a logged file" : "Live from Bluetooth sensor";
    $("liveSrc").className = "srcbadge " + d.src.toLowerCase();
    // CO alarm: running means over WHO windows (one reading = one minute for simulator/replay)
    let alarm = null;
    for (const w of WHO_CO) {
      const win = buf.slice(-w.min).filter(x => x.CO != null);
      if (win.length < w.min) continue;   // only claim a window average once the window is full
      const mg = ppmToMg(win.reduce((s, x) => s + x.CO, 0) / win.length, alt);
      if (mg > w.mg) { alarm = `Carbon monoxide ${mg.toFixed(0)} mg/m³ averaged over ${w.min} min, above the WHO limit of ${w.mg}. Open the vent, check the heater flue, move people out if anyone has headache or dizziness.`; break; }
    }
    $("liveAlarm").hidden = !alarm; if (alarm) $("liveAlarm").textContent = alarm;
    // Nowcast: bias-correct tonight's minimum with the measured temperature
    const L = TS.fieldLast;
    if (L && d.T != null && isFinite(d.T)) {
      const h = new Date().getHours(), r = L.r, run = TS.fieldUI.answers().stove ? r.heated : r.passive;
      const pred = run.op[h], bias = d.T - pred;
      const idx = r.night.map((n, i) => (n ? i : -1)).filter(i => i >= 0);
      const iMin = idx.reduce((b, i) => (run.op[i] < run.op[b] ? i : b), idx[0] || 0);
      const dt = ((iMin - h) + 24) % 24, tau = Math.max(1, r.net.tauH);
      const corr = run.op[iMin] + bias * Math.exp(-dt / tau);
      $("liveNow").innerHTML = `The model expected <b>${pred.toFixed(1)} °C</b> now; the sensor reads <b>${(+d.T).toFixed(1)} °C</b>. ` +
        `Corrected forecast for the coldest hour (${String(iMin).padStart(2, "0")}:00): <b>${corr.toFixed(1).replace(/^-/, "−")} °C</b>. ` +
        `The difference fades with the shelter's ${tau.toFixed(0)} h time constant. Shelter: ${L.m.T.name}, ${L.m.rec.name}.`;
    }
    if (buf.length % 3 === 0) draw();
  }
  function draw() {
    const x = buf.map((_, i) => i), T = buf.map(b => b.T), CO = buf.map(b => b.CO);
    C.line($("liveChart"), { x, height: 220, unit: "", tipDigits: 1, yLabel: "°C and CO ppm", xFmt: v => `${Math.round(v)} min`,
      xTicks: x.filter(v => v % 30 === 0), series: [{ name: "Temperature °C", y: T, cls: "pas", width: 2 }, { name: "CO ppm", y: CO, cls: "c2", width: 1.6 }] });
    const lg = document.createElement("div"); lg.className = "legend";
    lg.innerHTML = '<span class="lg" style="--c:#8C2131">Temperature, °C</span><span class="lg" style="--c:#D99A1E">Carbon monoxide, ppm</span>';
    $("liveChart").appendChild(lg);
  }
  async function connect() {
    disconnect(); buf = [];
    const kind = $("liveKind").value;
    try {
      if (kind === "sim") { src = Simulator(onReading); src.start(); status("Simulator running: one reading per second, each one minute of shelter time."); }
      else if (kind === "ble") { src = window.__TAURI__ ? TauriBle(onReading, status) : WebBle(onReading, status); await src.start(); }
      else if (kind === "csv") {
        const f = $("liveFile").files[0]; if (!f) { status("Choose a logger CSV first."); return; }
        src = CsvReplay(TS.ansys.decode(new Uint8Array(await f.arrayBuffer())), onReading); src.start(); status("Replaying " + f.name);
      }
      $("liveFault").hidden = kind !== "sim";
    } catch (e) { status("Could not connect: " + e.message); src = null; }
  }
  function disconnect() { if (src) src.stop(); src = null; }
  function render() {
    if (!TS.fieldLast && TS.fieldUI) TS.fieldUI.render();
    $("liveFile").hidden = $("liveKind").value !== "csv";
  }
  $("liveKind").addEventListener("change", render);
  $("liveGo").addEventListener("click", connect);
  $("liveStop").addEventListener("click", () => { disconnect(); status("Stopped."); });
  $("liveFault").addEventListener("click", () => { if (src && src.fault) $("liveFault").textContent = src.fault() ? "Clear heater fault" : "Simulate a heater fault"; });
  TS.liveUI = { render, GATT, ppmToMg };
})();
