/* Fluxion engine.
   Hourly thermal model of a single-zone shelter, following the simple hourly
   method of EN ISO 13790:2008 (5R1C network, Annex C) with:
   - solar geometry (Cooper declination, Spencer equation of time),
   - daily-to-hourly irradiance split (Collares-Pereira & Rabl; Erbs diffuse),
   - isotropic sky transposition with ground albedo, horizon mask,
   - Berdahl-Martin clear-sky emissivity with pressure (altitude) correction,
   - sol-air temperature for opaque elements,
   - ISO 13786 / 13790 effective thermal mass (10 cm / insulation rule),
   - operative-temperature heater control with a capacity limit (ISO 13790 C.4).
   Units: SI, temperatures in deg C, powers in W, energies reported in kWh. */
(function (g) {
  g.TS = g.TS || {};
  const D2R = Math.PI / 180, R2D = 180 / Math.PI;
  const SIGMA = 5.670374e-8, CP_AIR = 1006, R_AIR = 287.05, GSC = 1367;

  /* ---------------------------------------------------------------- solar */
  function declination(n) { return 23.45 * Math.sin(D2R * 360 * (284 + n) / 365); }
  function eqTimeMin(n) {
    const B = D2R * 360 * (n - 1) / 365;
    return 229.2 * (0.000075 + 0.001868 * Math.cos(B) - 0.032077 * Math.sin(B)
      - 0.014615 * Math.cos(2 * B) - 0.04089 * Math.sin(2 * B));
  }
  function sunsetHourAngle(lat, dec) {
    const x = -Math.tan(lat * D2R) * Math.tan(dec * D2R);
    return Math.acos(Math.max(-1, Math.min(1, x))) * R2D;
  }
  /* daily extraterrestrial irradiation on a horizontal plane [kWh/m2] */
  function H0day(lat, n) {
    const dec = declination(n), ws = sunsetHourAngle(lat, dec);
    const f = 1 + 0.033 * Math.cos(D2R * 360 * n / 365);
    const v = (24 * 3600 / Math.PI) * GSC * f * (Math.cos(lat * D2R) * Math.cos(dec * D2R) * Math.sin(ws * D2R)
      + Math.PI * ws / 180 * Math.sin(lat * D2R) * Math.sin(dec * D2R));
    return v / 3.6e6;
  }
  /* sun position for clock hour t (IST, decimal) */
  function sunPos(lat, lon, n, t, tzMeridian) {
    const dec = declination(n);
    const lst = t + (4 * (lon - tzMeridian) + eqTimeMin(n)) / 60;
    const w = 15 * (lst - 12);
    const cz = Math.sin(lat * D2R) * Math.sin(dec * D2R) + Math.cos(lat * D2R) * Math.cos(dec * D2R) * Math.cos(w * D2R);
    const zen = Math.acos(Math.max(-1, Math.min(1, cz))) * R2D;
    let az = 180;
    const sz = Math.sin(zen * D2R);
    if (sz > 1e-6) {
      const ca = (Math.sin(dec * D2R) - Math.sin(lat * D2R) * cz) / (Math.cos(lat * D2R) * sz);
      az = Math.acos(Math.max(-1, Math.min(1, ca))) * R2D; // from north, morning side
      if (w > 0) az = 360 - az;
    }
    return { zen, alt: 90 - zen, az, w, cz };
  }
  function erbsDailyDiffuseFraction(KT, ws) {
    if (ws <= 81.4) {
      if (KT < 0.715) return 1 - 0.2727 * KT + 2.4495 * KT * KT - 11.9514 * KT ** 3 + 9.3879 * KT ** 4;
      return 0.143;
    }
    if (KT < 0.722) return 1 + 0.2832 * KT - 2.5557 * KT * KT + 0.8448 * KT ** 3;
    return 0.175;
  }
  function erbsHourly(kt) {
    if (kt <= 0.22) return 1 - 0.09 * kt;
    if (kt <= 0.8) return 0.9511 - 0.1604 * kt + 4.388 * kt * kt - 16.638 * kt ** 3 + 12.336 * kt ** 4;
    return 0.165;
  }
  function horizonAt(h, az) {
    if (!h || !h.length) return 0;
    const n = h.length, step = 360 / n, x = ((az % 360) + 360) % 360 / step;
    const i = Math.floor(x) % n, j = (i + 1) % n, f = x - Math.floor(x);
    return h[i] * (1 - f) + h[j] * f;
  }

  /* Hourly global/diffuse/beam on the horizontal for one design day,
     from the daily total H [kWh/m2/day]. Values at hour midpoints. */
  function designDaySolar(site, n) {
    const out = [];
    const dec = declination(n), ws = sunsetHourAngle(site.lat, dec);
    const wsr = ws * D2R;
    const H = site.H, H0 = H0day(site.lat, n), KT = Math.min(0.85, H / Math.max(H0, 1e-6));
    const Hd = H * erbsDailyDiffuseFraction(KT, ws);
    const a = 0.409 + 0.5016 * Math.sin(wsr - Math.PI / 3), b = 0.6609 - 0.4767 * Math.sin(wsr - Math.PI / 3);
    const den = Math.sin(wsr) - wsr * Math.cos(wsr);
    let rt = [], rd = [], sp = [];
    for (let h = 0; h < 24; h++) {
      const p = sunPos(site.lat, site.lon, n, h + 0.5, site.tzMeridian);
      sp.push(p);
      const cw = Math.cos(p.w * D2R), cws = Math.cos(wsr);
      const base = (Math.PI / 24) * (cw - cws) / den;
      rt.push(Math.max(0, base * (a + b * cw)));
      rd.push(Math.max(0, base));
    }
    const st = rt.reduce((s, v) => s + v, 0) || 1, sd = rd.reduce((s, v) => s + v, 0) || 1;
    for (let h = 0; h < 24; h++) {
      const ghi = 1000 * H * rt[h] / st;           // W/m2 mean over the hour
      let dhi = Math.min(ghi, 1000 * Hd * rd[h] / sd);
      out.push(beamFromSplit(site, sp[h], ghi, dhi));
    }
    return { hours: out, H0, KT, Hd };
  }
  function beamFromSplit(site, p, ghi, dhi) {
    let bh = Math.max(0, ghi - dhi), dni = 0;
    if (p.alt > 0.5 && bh > 0) {
      dni = bh / Math.max(p.cz, 0.087);
      if (p.alt < horizonAt(site.horizon, p.az)) { dhi += 0; dni = 0; ghi = dhi; bh = 0; }
    } else { dhi = ghi; bh = 0; }
    return { ghi, dhi, dni, alt: p.alt, az: p.az, zen: p.zen };
  }
  /* Incident on a vertical facade with outward normal azimuth gam (deg from N) */
  function onVertical(s, gam, albedo) {
    let ct = 0;
    if (s.alt > 0 && s.dni > 0) ct = Math.max(0, Math.sin(s.zen * D2R) * Math.cos((s.az - gam) * D2R));
    const beam = s.dni * ct, diff = 0.5 * s.dhi, refl = 0.5 * albedo * s.ghi;
    return { total: beam + diff + refl, beam, diffuse: diff + refl, cosInc: ct };
  }
  /* ASHRAE incidence-angle modifier for glazing beam transmission */
  function iam(cosInc) { if (cosInc <= 0.05) return 0; return Math.max(0, 1 - 0.1 * (1 / cosInc - 1)); }

  /* --------------------------------------------------------- atmosphere */
  function pressurePa(alt) { return 101325 * Math.pow(1 - 2.25577e-5 * alt, 5.25588); }
  function airDensity(alt, T) { return pressurePa(alt) / (R_AIR * (T + 273.15)); }
  function dewPoint(T, RH) {
    const a = 17.625, b = 243.04, r = Math.max(1, Math.min(100, RH)) / 100;
    const al = Math.log(r) + a * T / (b + T);
    return b * al / (a - al);
  }
  /* cloud: fraction 0-1 (from forecast data); clear-sky emissivity is raised
     by (1 + 0.34 C^2), the team-specified cloud factor (literature range for
     the coefficient is roughly 0.2-0.35). Design days assume clear sky. */
  function skyTemp(T, Tdp, hour, alt, cloud) {
    const x = Tdp / 100, P = pressurePa(alt) / 100;
    let e = 0.711 + 0.56 * x + 0.73 * x * x + 0.013 * Math.cos(2 * Math.PI * hour / 24) + 0.00012 * (P - 1000);
    e = Math.max(0.4, Math.min(1, e));
    if (cloud > 0) e = Math.min(1, e * (1 + 0.34 * cloud * cloud));
    return Math.pow(e, 0.25) * (T + 273.15) - 273.15;
  }
  /* design-day ambient: cosine segments, min at sunrise, max at 14:00 */
  function ambientProfile(Tmin, Tmax, sunrise) {
    const T = [];
    for (let h = 0; h < 24; h++) {
      const t = h + 0.5;
      let v;
      if (t >= sunrise && t <= 14) v = Tmin + (Tmax - Tmin) * (1 - Math.cos(Math.PI * (t - sunrise) / (14 - sunrise))) / 2;
      else {
        const span = 24 - 14 + sunrise, x = t > 14 ? t - 14 : t + 24 - 14;
        v = Tmax - (Tmax - Tmin) * (1 - Math.cos(Math.PI * x / span)) / 2;
      }
      T.push(v);
    }
    return T;
  }

  /* ----------------------------------------------------------- envelope */
  const RSI = { wall: 0.13, roof: 0.10, floor: 0.17 };
  function layerProps(l, M) {
    const m = M[l.mat] || M.custom;
    return {
      t: l.t, k: l.k != null ? l.k : m.k, rho: l.rho != null ? l.rho : m.rho,
      c: l.c != null ? l.c : m.c, R: m.R, cls: m.cls, name: m.name,
    };
  }
  function layerR(p) { return p.R != null ? p.R : p.t / Math.max(p.k, 1e-6); }
  function constructionR(layers, M) { return layers.reduce((s, l) => s + layerR(layerProps(l, M)), 0); }
  /* ISO 13790 12.3.1.2 / ISO 13786: areal heat capacity from the room side,
     up to 0.10 m, the first insulation layer, or the element mid-plane. */
  function arealCapacity(layers, M) {
    const ps = layers.map(l => layerProps(l, M)).reverse();
    const total = ps.reduce((s, p) => s + p.t, 0), lim = Math.min(0.10, total / 2);
    let d = 0, k = 0;
    for (const p of ps) {
      if (p.cls === "ins" || p.cls === "gap") break;
      const take = Math.min(p.t, lim - d);
      if (take <= 0) break;
      k += p.rho * p.c * take; d += take;
    }
    return k;
  }

  /* --------------------------------------------------------------- model */
  function facadeList(d) {
    const o = d.orient;
    return [
      { key: "front", az: o, w: d.L },
      { key: "right", az: o + 90, w: d.W },
      { key: "back",  az: o + 180, w: d.L },
      { key: "left",  az: o + 270, w: d.W },
    ].map(f => ({ ...f, az: ((f.az % 360) + 360) % 360, gross: f.w * d.H }));
  }
  const COMPASS = ["N","NNE","NE","ENE","E","ESE","SE","SSE","S","SSW","SW","WSW","W","WNW","NW","NNW"];
  function compass(az) { return COMPASS[Math.round(((az % 360) + 360) % 360 / 22.5) % 16]; }

  /* Envelope geometry for the supported shapes.
     box:   L x W x H rectangle, roof pitched by d.pitch.
     dome:  hemisphere of diameter L; half the shell is treated as roof (sky
            facing), the other half split over the four orientations.
     vault: half-cylinder of span W and length L (Quonset / pod); half the
            curved shell is roof, a quarter each faces front and back; the
            semicircular ends face left and right. */
  function geom(d) {
    const sh = d.shape || "box";
    if (sh === "dome") {
      const r = d.L / 2, Af = Math.PI * r * r, env = 2 * Math.PI * r * r;
      return { shape: sh, Af, V: 2 / 3 * Math.PI * r ** 3, roof: env / 2, fac: { front: env / 8, right: env / 8, back: env / 8, left: env / 8 }, H: r };
    }
    if (sh === "vault") {
      const r = d.W / 2, Af = d.L * d.W, curved = Math.PI * r * d.L, end = Math.PI * r * r / 2;
      return { shape: sh, Af, V: Math.PI * r * r * d.L / 2, roof: curved / 2, fac: { front: curved / 4, back: curved / 4, right: end, left: end }, H: r };
    }
    const Af = d.L * d.W, pitch = Math.max(0, Math.min(60, d.pitch || 0)) * Math.PI / 180;
    return { shape: "box", Af, V: Af * d.H, roof: Af / Math.cos(pitch), fac: { front: d.L * d.H, right: d.W * d.H, back: d.L * d.H, left: d.W * d.H }, H: d.H };
  }

  /* Build the static network for a design + site. */
  function buildNetwork(d, site, ops) {
    const M = g.TS.MATERIALS, GZ = g.TS.GLAZING[d.glazing] || g.TS.GLAZING.double;
    const G = geom(d), Af = G.Af, V = G.V;
    const fac = facadeList(d);
    fac.forEach(f => (f.gross = G.fac[f.key]));
    const winKeys = d.win || {};
    const Rwall = constructionR(d.wall, M), Rroof = constructionR(d.roof, M), Rfloor = constructionR(d.floor, M);
    const kWall = arealCapacity(d.wall, M), kRoof = arealCapacity(d.roof, M), kFloor = arealCapacity(d.floor, M);
    const Rground = ops.Rground != null ? ops.Rground : 0.5, Rberm = 1.0;
    const els = [];
    for (const f of fac) {
      const Aw = Math.min(Math.max(0, winKeys[f.key] || 0), 0.9 * f.gross);
      f.Aw = Aw; f.Aop = f.gross - Aw; f.label = compass(f.az);
      const bermed = d.berm && f.key === "back";
      els.push({ id: "wall_" + f.key, kind: bermed ? "berm" : "wall", A: f.Aop, Rmat: Rwall,
        rsi: RSI.wall, kappa: kWall, az: f.az, fsky: 0.5, label: "Wall " + f.label, facade: f.key });
    }
    // Trombe wall: mass wall behind glass on the front facade (unvented)
    const tr = d.trombe;
    if (tr && tr.area > 0) {
      const front = els.find(e => e.id === "wall_front");
      const A = Math.min(tr.area, front.A);
      front.A -= A;
      const lay = [{ mat: tr.mat || "stone", t: tr.t || 0.3 }];
      els.push({ id: "trombe", kind: "trombe", A, Rmat: constructionR(lay, M), rsi: RSI.wall, kappa: arealCapacity(lay, M),
        facade: "front", label: "Trombe wall" });
    }
    const Aroof = G.roof;
    els.push({ id: "roof", kind: "roof", A: Aroof, Rmat: Rroof, rsi: RSI.roof, kappa: kRoof, fsky: 1, label: "Roof" });
    els.push({ id: "floor", kind: "floor", A: Af, Rmat: Rfloor, rsi: RSI.floor, kappa: kFloor, label: "Floor", raised: d.floorMode === "raised" });

    // effective internal mass
    let Cm = 0, sumAk2 = 0, Aint = 0;
    for (const e of els) { Cm += e.kappa * e.A; sumAk2 += e.A * e.kappa * e.kappa; Aint += e.A; }
    const st = d.store || { type: "none" }, SD = g.TS.STORE[st.type];
    let store = null;
    if (st.type !== "none" && st.mass > 0 && SD) {
      const Ax = Math.max(0.5, 0.008 * st.mass);
      store = { mass: st.mass, c: SD.c, L: SD.L || 0, Tm: st.Tm != null ? st.Tm : SD.Tm, dT: SD.dT || 4, A: Ax, pcm: st.type === "pcm" };
      const Cx = st.mass * SD.c, kx = Cx / Ax;
      Cm += Cx; sumAk2 += Ax * kx * kx;
    }
    Cm = Math.max(Cm, 20000 * Af); // floor: furniture and fittings, ISO "very light" lower bound order
    const Atot = fac.reduce((a, f) => a + f.gross, 0) + Af + Aroof;
    let Am = sumAk2 > 0 ? (Cm * Cm) / sumAk2 : 2.5 * Af;
    Am = Math.min(Am, 0.95 * Atot);

    return { d, site, ops, GZ, Af, V, fac, els, Cm, Am, Atot, store,
      U: { wall: 1 / (RSI.wall + Rwall + 0.04), roof: 1 / (RSI.roof + Rroof + 0.04), floor: 1 / (RSI.floor + Rfloor + Rground),
           glazing: GZ.U },
      R: { wall: Rwall, roof: Rroof, floor: Rfloor }, kappa: { wall: kWall, roof: kRoof, floor: kFloor },
      Rground, Rberm };
  }

  /* Prepare hourly boundary conditions for the simulated span. */
  function boundary(net) {
    const { site, d, ops } = net;
    const n = site.doy, scale = ops.solarScale != null ? ops.solarScale : 1;
    const dec = declination(n), ws = sunsetHourAngle(site.lat, dec);
    const corr = (4 * (site.lon - site.tzMeridian) + eqTimeMin(n)) / 60;
    const sunrise = 12 - ws / 15 - corr, sunset = 12 + ws / 15 - corr;
    let hours = [];
    let meta = { sunrise, sunset };
    if (site.hourly && site.hourly.length >= 24) {
      const H0 = site.hourly;
      for (let i = 0; i < H0.length; i++) {
        const hr = i % 24;
        const p = sunPos(site.lat, site.lon, n + Math.floor(i / 24), hr + 0.5, site.tzMeridian);
        const ghi = Math.max(0, H0[i].GHI || 0);
        const g0 = p.cz > 0 ? GSC * (1 + 0.033 * Math.cos(D2R * 360 * n / 365)) * p.cz : 0;
        const kt = g0 > 10 ? Math.min(1, ghi / g0) : 1;
        const dhi = ghi * (g0 > 10 ? erbsHourly(kt) : 1);
        const s = beamFromSplit(site, p, ghi, dhi);
        hours.push({ T: H0[i].T, ws: H0[i].ws != null ? H0[i].ws : site.wind, hr, cloud: H0[i].cloud || 0, rh: H0[i].RH, ...s });
      }
      meta.mode = "hourly";
    } else {
      const sol = designDaySolar(site, n);
      const T = ambientProfile(site.Tmin, site.Tmax, sunrise);
      for (let h = 0; h < 24; h++) hours.push({ T: T[h], ws: site.wind, hr: h, ...sol.hours[h] });
      meta.mode = "design-day"; meta.H0 = sol.H0; meta.KT = sol.KT;
    }
    const Tmean = hours.reduce((s, x) => s + x.T, 0) / hours.length;
    const Tdp = dewPoint(Tmean, site.RH);
    const rho = airDensity(site.alt, Tmean), rho0 = 1.225;
    for (const x of hours) {
      x.ghi *= scale; x.dhi *= scale; x.dni *= scale;
      x.Tsky = skyTemp(x.T, Tdp, x.hr, site.alt, x.cloud || 0);
      const Tm = (x.T + x.Tsky) / 2 + 273.15;
      x.hr_ = 4 * 0.9 * SIGMA * Tm * Tm * Tm;
      const hc = ops.hOut != null ? ops.hOut : (4 + 4 * x.ws) * Math.pow(rho / rho0, 0.8);
      x.he = hc + x.hr_;
      x.night = !(x.alt > 0);
      x.facade = {};
      for (const f of net.fac) x.facade[f.key] = onVertical(x, f.az, site.albedo);
    }
    meta.Tdp = Tdp; meta.rho = rho; meta.P = pressurePa(site.alt);
    return { hours, meta };
  }

  /* One hour of the 5R1C Crank-Nicolson update. Returns node temperatures. */
  function step(net, x, thPrev, PhiHC, Cm) {
    const { d, ops, GZ, Af, Atot, Am } = net;
    const Hve = x.Hve, Hms = 9.1 * Am, His = 3.45 * Atot;
    const Hw = x.Hw, Hop = x.Hop;
    const Hem = 1 / Math.max(1 / Hop - 1 / Hms, 1e-9);
    const Phi_int = x.Phi_int;
    const Phi_sol = x.Phi_solw - x.Phi_rw;
    const Phi_ia = 0.5 * Phi_int + PhiHC;
    const base = 0.5 * Phi_int + Phi_sol;
    let fm = Am / Atot, fst = 1 - Am / Atot - Hw / (9.1 * Atot);
    if (fst < 0) { fm += fst; fst = 0; }
    const Phi_m = fm * base, Phi_st = fst * base;
    const H1 = 1 / (1 / Hve + 1 / His), H2 = H1 + Hw, H3 = 1 / (1 / H2 + 1 / Hms);
    const te = x.T, tsup = x.T, tem = x.Tem;
    const Phi_mtot = Phi_m + Hem * tem + H3 * (Phi_st + Hw * te + H1 * (Phi_ia / Hve + tsup)) / H2;
    const C = Cm / 3600;
    const tmT = (thPrev * (C - 0.5 * (H3 + Hem)) + Phi_mtot) / (C + 0.5 * (H3 + Hem));
    const tm = 0.5 * (tmT + thPrev);
    const ts = (Hms * tm + Phi_st + Hw * te + H1 * (tsup + Phi_ia / Hve)) / (Hms + Hw + H1);
    const tair = (His * ts + Hve * tsup + Phi_ia) / (His + Hve);
    const top = 0.3 * tair + 0.7 * ts;
    // ISO 13790 C.3 sends this share of radiant gains straight back out through the glazing
    const lostW = (1 - fm - fst) * base;
    return { tmT, tm, ts, tair, top, Hem, Hw, Hve, lostW };
  }

  function prepareHour(net, x, hourIdx) {
    const { d, ops, GZ, fac, els, Af, V, site } = net;
    const shutterOn = d.shutter && x.night;
    const Uw = shutterOn ? 1 / (1 / GZ.U + (ops.shutterR != null ? ops.shutterR : 0.4)) : GZ.U;
    const FF = 0.8;
    let Hw = 0, Phi_solw = 0, Phi_rw = 0;
    const solW = {};
    for (const f of fac) {
      Hw += Uw * f.Aw;
      const I = x.facade[f.key];
      let shade = 0;
      if (f.key === "front" && d.overhang && d.overhang.P > 0 && x.alt > 0 && I.cosInc > 0) {
        const wh = Math.min(1.2, 0.8 * (d.H || 2.5)), tanO = Math.tan(x.alt * D2R) / Math.max(0.05, Math.cos((x.az - f.az) * D2R));
        shade = Math.max(0, Math.min(1, (d.overhang.P * tanO - (d.overhang.g || 0.3)) / wh));
      }
      const tr = shutterOn ? 0 : f.Aw * FF * GZ.g * (I.beam * (1 - shade) * iam(I.cosInc) + 0.9 * I.diffuse);
      solW[f.key] = tr; Phi_solw += tr;
      Phi_rw += (1 / x.he) * Uw * f.Aw * x.hr_ * 0.5 * (x.T - x.Tsky);
    }
    // opaque elements: sol-air or ground temperature
    let Hop = 0, num = 0;
    const opq = [];
    for (const e of els) {
      let U, th;
      if (e.kind === "floor" && e.raised) { U = 1 / (e.rsi + e.Rmat + 0.1); th = x.T; }      // ventilated crawl space / skids
      else if (e.kind === "floor") { U = 1 / (e.rsi + e.Rmat + net.Rground); th = site.Tground; }
      else if (e.kind === "trombe") {
        const night = d.shutter && x.night;
        const Rout = 1 / GZ.U + (night ? (ops.shutterR != null ? ops.shutterR : 0.4) : 0);
        const I = x.facade.front;
        const q = night ? 0 : 0.95 * GZ.g * 0.95 * (I.beam * iam(I.cosInc) + 0.9 * I.diffuse); // absorbed on dark mass surface, W/m2
        U = 1 / (e.rsi + e.Rmat + Rout); th = x.T + q * Rout;
        e._Iin = q * Rout * U * e.A;
      }
      else if (e.kind === "berm") { U = 1 / (e.rsi + e.Rmat + net.Rberm); th = site.Tground; }
      else {
        U = 1 / (e.rsi + e.Rmat + 1 / x.he);
        const I = e.kind === "roof" ? x.ghi : x.facade[e.facade].total;
        th = x.T + (d.absorptance * I - e.fsky * x.hr_ * (x.T - x.Tsky)) / x.he;
        e._Iin = d.absorptance * I / x.he * U * e.A;  // inward share of absorbed solar [W]
      }
      if (d.tb > 0 && (e.kind === "wall" || e.kind === "roof")) U += d.tb;   // thermal-bridge allowance, ISO 13790 / ISO 14683 style
      const H = U * e.A;
      opq.push({ id: e.id, H, th, U, Iin: e._Iin || 0, rsi: e.rsi, rse: (e.kind === "floor" && !e.raised) || e.kind === "berm" ? null : (e.kind === "trombe" ? null : 1 / x.he), kind: e.kind });
      Hop += H; num += H * th;
      e._Iin = 0;
    }
    const occ = (x.hr >= 18 || x.hr < 8) ? d.people : Math.ceil(d.people / 2);
    x.Phi_int = occ * d.wPerson + d.equipW;
    const nat = d.achH && d.achH.length ? d.achH[hourIdx % d.achH.length] : d.ach;
    const mech = d.mech && d.mech.ach > 0 ? d.mech : null;
    x.achNat = nat;
    x.ach = nat + (mech ? mech.ach : 0);                                   // total outdoor air (CO2, moisture)
    x.Hve = net.rhoAir * CP_AIR * (nat + (mech ? mech.ach * (1 - (mech.eff || 0)) : 0)) * V / 3600;   // heat recovered from the mechanical share
    x.Hw = Hw; x.Hop = Hop; x.Tem = num / Hop; x.opq = opq;
    x.Phi_solw = Phi_solw; x.Phi_rw = Phi_rw; x.solW = solW; x.Uw = Uw;
  }

  function capacityAt(net, tm) {
    let C = net.Cm;
    const s = net.store;
    if (s && s.pcm) {
      const lo = s.Tm - s.dT / 2, hi = s.Tm + s.dT / 2;
      if (tm >= lo && tm <= hi) C += s.mass * s.L / s.dT;
    }
    return C;
  }

  /* Run the network; mode "free" (passive) or "heated". */
  function run(net, bc, mode) {
    const { ops, Af } = net;
    const hrs = bc.hours, N = hrs.length;
    const PhiMax = mode === "heated" ? (ops.burnMax * ops.kwhPerL * ops.eta * 1000) : 0;
    const set = ops.setpoint;
    let tm = (hrs.reduce((s, x) => s + x.T, 0) / N) + 5;
    const periodic = bc.meta.mode === "design-day";
    const spin = periodic ? 40 : 10;
    const res = { air: [], op: [], s: [], m: [], phi: [], unmet: [], paths: [] };
    let lastDay = null;
    let tmStart = null, storeJ = 0;
    for (let day = 0; day < spin + 1; day++) {
      const record = day === spin;
      if (record) tmStart = tm;
      const span = periodic || record ? N : 24;
      const dayVals = [];
      for (let i = 0; i < span; i++) {
        const x = hrs[i];
        const C = capacityAt(net, tm);
        let r = step(net, x, tm, 0, C), phi = 0, unmet = false;
        if (mode === "heated" && r.top < set) {
          const p10 = 10 * Af, r10 = step(net, x, tm, p10, C);
          const need = p10 * (set - r.top) / Math.max(r10.top - r.top, 1e-9);
          phi = Math.min(need, PhiMax);
          unmet = need > PhiMax + 1e-6;
          r = step(net, x, tm, phi, C);
        }
        if (record) storeJ += C * (r.tmT - tm);
        tm = r.tmT;
        dayVals.push(r.top);
        if (record) {
          res.air.push(r.tair); res.op.push(r.top); res.s.push(r.ts); res.m.push(r.tm);
          res.phi.push(phi); res.unmet.push(unmet);
          const p = { glazing: x.Hw * (r.ts - x.T) + x.Phi_rw + r.lostW, vent: x.Hve * (r.tair - x.T) };
          const k = r.Hem / x.Hop;
          for (const o of x.opq) p[o.id] = o.H * k * (r.tm - o.th);
          res.paths.push(p);
        }
      }
      if (periodic && !record && lastDay && day > 8) {
        let dmax = 0;
        for (let i = 0; i < N; i++) dmax = Math.max(dmax, Math.abs(dayVals[i] - lastDay[i]));
        if (dmax < 1e-4) day = spin - 1;
      }
      lastDay = dayVals;
    }
    // energy balance over the recorded span: gains - losses = storage change
    let gains = 0, losses = 0;
    for (let i = 0; i < N; i++) {
      const x = hrs[i];
      gains += x.Phi_int + x.Phi_solw + res.phi[i];
      for (const k in res.paths[i]) losses += res.paths[i][k];
    }
    res.storage_kWh = storeJ / 3.6e6;
    res.balanceErrPct = 100 * (gains - losses - storeJ / 3600) / Math.max(Math.abs(gains), 1);
    return res;
  }

  function sum(a) { return a.reduce((s, v) => s + v, 0); }

  function simulate(design, siteIn, opsIn) {
    const ops = Object.assign({ setpoint: 14, burnMax: 0.7, eta: 0.6, kwhPerL: 9.58, band: [14, 20], solarScale: 1, hOut: null, Rground: 0.5, shutterR: 0.4 }, opsIn || {});
    const site = Object.assign({ tzMeridian: 82.5, albedo: 0.6, Tground: 0, RH: 50, wind: 2.5, horizon: [0,0,0,0,0,0,0,0] }, siteIn);
    const d = Object.assign({ people: 4, wPerson: 75, equipW: 0, ach: 0.5, absorptance: 0.6, shutter: false, berm: false }, design);
    const net = buildNetwork(d, site, ops);
    const bc = boundary(net);
    net.rhoAir = bc.meta.rho;
    for (let i = 0; i < bc.hours.length; i++) prepareHour(net, bc.hours[i], i);

    const passive = run(net, bc, "free");
    const heated = run(net, bc, "heated");
    const N = bc.hours.length, days = N / 24;

    // solar accounting (Output 2)
    const facades = net.fac.map(f => {
      let inc = 0, tr = 0;
      for (const x of bc.hours) { inc += x.facade[f.key].total * f.gross; tr += x.solW[f.key]; }
      const opIn = sum(bc.hours.map(x => (x.opq.find(o => o.id === "wall_" + f.key) || {}).Iin || 0));
      return { key: f.key, label: f.label, az: f.az, gross: f.gross, Aw: f.Aw,
        incident_kWh: inc / 1000 / days, incidentPerM2_kWh: inc / 1000 / days / f.gross,
        transmitted_kWh: tr / 1000 / days, opaqueIn_kWh: opIn / 1000 / days,
        bermed: d.berm && f.key === "back" };
    });
    const roofInc = sum(bc.hours.map(x => x.ghi)) * net.Af / 1000 / days;
    const roofIn = sum(bc.hours.map(x => (x.opq.find(o => o.id === "roof") || {}).Iin || 0)) / 1000 / days;
    const solarTransmitted = sum(facades.map(f => f.transmitted_kWh));
    const trombeIn = sum(bc.hours.map(x => (x.opq.find(o => o.id === "trombe") || {}).Iin || 0)) / 1000 / days;
    const solarOpaque = sum(facades.map(f => f.opaqueIn_kWh)) + roofIn + trombeIn;

    // comfort, fuel
    const [b0, b1] = ops.band;
    const TOL = 0.05; // K: a heater holding exactly the band floor counts as in band
    const inBand = a => a.filter(v => v >= b0 - TOL && v <= b1 + TOL).length;
    const nightIdx = bc.hours.map((x, i) => (x.night ? i : -1)).filter(i => i >= 0);
    const Qheat_kWh = sum(heated.phi) / 1000 / days;
    const fuel = Qheat_kWh / (ops.kwhPerL * ops.eta);
    const heaterHours = heated.phi.filter(v => v > 1).length / days;

    // solar fraction: same design with sun removed
    let solarFraction = null;
    if (ops.withSolarFraction !== false) {
      const noSun = simulate(design, siteIn, Object.assign({}, opsIn, { solarScale: 0, withSolarFraction: false }));
      const Qn = noSun.summary.heat_kWh;
      solarFraction = Qn > 0.01 ? Math.max(0, 1 - Qheat_kWh / Qn) : null;
    }

    // CO2 steady state from occupants (sedentary ~0.0052 L/s per person at
    // sea-level density; volume flow scales with 1/rho at altitude)
    const rho0 = 1.2;
    const Gco2 = d.people * 0.0052 * (rho0 / net.rhoAir);   // L/s
    const Q = d.ach * net.V / 3.6;                            // L/s
    const co2 = 420 + 1e6 * (Gco2 / 1000) / Math.max(Q / 1000, 1e-6);
    const achFor1000 = (Gco2 / ((1000 - 420) / 1e6)) * 3.6 / net.V;

    const bands = (arr) => ({
      min: Math.min(...arr), max: Math.max(...arr), mean: sum(arr) / arr.length,
      nightMin: nightIdx.length ? Math.min(...nightIdx.map(i => arr[i])) : Math.min(...arr),
      inBandPct: 100 * inBand(arr) / arr.length, belowPct: 100 * arr.filter(v => v < b0 - TOL).length / arr.length,
    });

    return {
      N, days, hours: bc.hours.map(x => x.hr), meta: bc.meta, net: {
        Af: net.Af, V: net.V, Cm: net.Cm, Am: net.Am, Atot: net.Atot, U: net.U, R: net.R, kappa: net.kappa,
        Hop: bc.hours[0].Hop, Hve: bc.hours[0].Hve, HwDay: Math.max(...bc.hours.map(x => x.Hw)),
        tauH: net.Cm / 3600 / (bc.hours[0].Hop + bc.hours[0].Hve + Math.max(...bc.hours.map(x => x.Hw))),
        els: net.els.map(e => ({ id: e.id, label: e.label, A: e.A, kind: e.kind })),
        fac: net.fac, rhoAir: net.rhoAir,
      },
      facIrr: bc.hours.map(x => { const o = {}; for (const f of net.fac) o[f.key] = x.facade[f.key].total; return o; }),
      ach: bc.hours.map(x => x.ach), wind: bc.hours.map(x => x.ws), cloud: bc.hours.map(x => x.cloud || 0),
      rhOut: bc.hours.map(x => (x.rh != null ? x.rh : site.RH)),
      elems: bc.hours.map(x => x.opq.map(o => ({ id: o.id, th: o.th, U: o.U, rsi: o.rsi, rse: o.rse, kind: o.kind }))),
      layers: { wall: d.wall, roof: d.roof, floor: d.floor },
      amb: bc.hours.map(x => x.T), sky: bc.hours.map(x => x.Tsky), ghi: bc.hours.map(x => x.ghi),
      sunAlt: bc.hours.map(x => x.alt), sunAz: bc.hours.map(x => x.az), night: bc.hours.map(x => x.night),
      passive, heated,
      solar: { facades, roofIncident_kWh: roofInc, roofIn_kWh: roofIn,
        transmitted_kWh: solarTransmitted, opaqueIn_kWh: solarOpaque, trombeIn_kWh: trombeIn, fraction: solarFraction },
      summary: {
        passive: bands(passive.op), heated: bands(heated.op),
        heat_kWh: Qheat_kWh, fuel_L: fuel, heaterHours,
        unmetHours: heated.unmet.filter(Boolean).length / days,
        heaterMax_kW: ops.burnMax * ops.kwhPerL * ops.eta,
        co2_ppm: co2, achFor1000,
      },
      ops, site, design: d,
    };
  }

  /* Path-wise heat flow over an hour window [a, b) of the recorded span. */
  function pathTotals(runRes, a, b) {
    const t = {};
    for (let i = a; i < b; i++) for (const k in runRes.paths[i]) t[k] = (t[k] || 0) + runRes.paths[i][k] / 1000;
    return t; // kWh
  }

  /* Design-day site from a NASA POWER climatology record. The grid-cell
     T2M is moved to the site altitude with the standard lapse rate
     (6.5 K/km); Tmin/Tmax = mean -/+ half the diurnal range. */
  const MID_DOY = [15, 46, 74, 105, 135, 166, 196, 227, 258, 288, 319, 349];
  function siteFrom(rec, month, o) {
    o = o || {};
    const alt = o.alt != null ? o.alt : rec.alt;
    const lapse = 6.5 * (rec.cell.elev - alt) / 1000;
    const Tmean = rec.T2M[month] + lapse + (o.Toffset || 0);
    const amp = o.range != null ? o.range : (rec.TMAX ? rec.TMAX[month] - rec.TMIN[month] : 12);
    return {
      id: rec.id, name: rec.name, lat: rec.lat, lon: rec.lon, alt, doy: MID_DOY[month], month,
      Tmean, Tmin: Tmean - amp / 2, Tmax: Tmean + amp / 2, lapse,
      H: o.H != null ? o.H : rec.GHI[month], RH: rec.RH[month], wind: o.wind != null ? o.wind : rec.WS[month],
      albedo: o.albedo != null ? o.albedo : 0.6, Tground: o.Tground != null ? o.Tground : 0,
      horizon: o.horizon || rec.horizon || [0, 0, 0, 0, 0, 0, 0, 0], tzMeridian: 82.5,
    };
  }

  g.TS.engine = { simulate, siteFrom, MID_DOY, geom, pathTotals, sunPos, H0day, declination, compass, airDensity, pressurePa, skyTemp,
    dewPoint, constructionR, arealCapacity, layerProps, layerR, RSI };
  if (typeof module !== "undefined") module.exports = g.TS;
})(typeof window !== "undefined" ? window : globalThis);
