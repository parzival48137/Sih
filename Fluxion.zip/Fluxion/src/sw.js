/* Offline cache for the installable web version. Bump VERSION on release. */
const VERSION = "ts-2.0.0";
const FILES = ["./", "index.html", "css/app.css", "fonts/archivo.woff2", "manifest.webmanifest", "icons/icon.svg", "icons/icon-192.png",
  "js/sites.js", "js/materials.js", "js/engine.js", "js/ansys.js", "js/charts.js", "js/method.js", "js/field.js", "js/fieldui.js", "js/telemetry.js", "js/airflow.js", "js/checks.js", "js/optimise.js", "js/sitedata.js", "js/report.js", "js/bridge.js", "js/uiplus.js", "js/stages.js", "js/weather.js", "js/moisture.js", "js/logistics.js", "js/apdl.js", "vendor/jspdf.umd.min.js", "js/app.js"];
self.addEventListener("install", e => e.waitUntil(caches.open(VERSION).then(c => c.addAll(FILES)).then(() => self.skipWaiting())));
self.addEventListener("activate", e => e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== VERSION).map(k => caches.delete(k)))).then(() => self.clients.claim())));
self.addEventListener("fetch", e => { if (e.request.method === "GET") e.respondWith(caches.match(e.request).then(r => r || fetch(e.request))); });
