@echo off
rem Use this one with: right-click > Run as administrator
title Fluxion ANSYS Bridge (manual admin)
cd /d "%~dp0"
echo Folder: %cd%
python --version >nul 2>&1
if %errorlevel% equ 0 (
  python ansys_bridge.py
) else (
  py -3 ansys_bridge.py
)
echo.
echo The bridge stopped. Read any message above, then press a key to close.
pause
