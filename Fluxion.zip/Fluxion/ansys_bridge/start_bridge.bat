@echo off
rem Fluxion ANSYS Bridge - restarts itself as Administrator (RunWB2.exe needs it)
net session >nul 2>&1
if %errorlevel% neq 0 (
  echo Asking Windows for Administrator rights...
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
title Fluxion ANSYS Bridge (Administrator)
cd /d "%~dp0"
echo Folder: %cd%
python --version >nul 2>&1
if %errorlevel% equ 0 (
  python ansys_bridge.py
) else (
  py -3 --version >nul 2>&1
  if errorlevel 1 (
    echo.
    echo Python 3 is needed for the ANSYS connection and was not found.
    echo Install it once from https://www.python.org/downloads/  ^(tick "Add python.exe to PATH"^),
    echo then press "Start ANSYS connection" in Fluxion again.
    start "" https://www.python.org/downloads/
  ) else (
    py -3 ansys_bridge.py
  )
)
echo.
echo The bridge stopped. Read any message above, then press a key to close.
pause
