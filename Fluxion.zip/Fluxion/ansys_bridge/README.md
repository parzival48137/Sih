# Fluxion ANSYS Bridge

Connects the app to the parametric ANSYS Workbench model. The app sends a design, the bridge
runs ANSYS in the background (no GUI), and the results come back into the app's **ANSYS Verify** tab.

```
App (ANSYS Verify tab) --POST /run--> ansys_bridge.py --run.wbjn--> RunWB2.exe -B -R --> ANSYS
App <-- /status, /result ------------ ansys_bridge.py <--results.csv-------------------'
```

## Requirements
- Windows PC with ANSYS 18.2 Workbench (the one with `D:\SIH26\Analysis\Shelter_General.wbpj`)
- Python 3.8+ (standard library only, no pip install)

## Setup (once)
1. Put this folder anywhere, e.g. `D:\SIH26\ansys_bridge\`.
2. Open `ansys_bridge.py` in Notepad and check the three paths at the top:
   `RUNWB2`, `PROJECT`, `WORK_DIR`.

## Use
1. **Close Workbench** (batch mode cannot open a project that is already open).
2. Double-click `start_bridge.bat`. Keep the black window open. It should say `OK` for RunWB2 and Project.
3. Open the app → **ANSYS Verify** tab → status shows "Connected to ANSYS".
4. Set the design → **Run ANSYS on this design**. A run takes about 3–10 minutes.

Each run is saved in `WORK_DIR\<job id>\` (`run.wbjn`, `results.csv`, `ansys_log.txt`) for traceability.

## Without ANSYS (app development)
Double-click `start_bridge_mock.bat`. The bridge answers within seconds with the real base-case result
(5 × 4 × 2.8 m PUF shelter: night −8.8 °C, day 65.2 °C), marked as "mock" in the app.

## Inputs → Workbench parameters
| App input | Workbench |
|---|---|
| RHO_INS, K_INS, CP_INS | P1, P2, P3 |
| L, W, H | P7, P8, P9 |
| T_INS | P13, P14, P15, P23 |
| L−2T, W−2T, H−2T | P16, P17, P18 |
| (L−WIN_W)/2, sill 0.9 m | P19, P21 |
| WIN_W, WIN_H | P22, P24 |

Outputs are read by name: T_AIR_MAX, T_AIR_MIN, Rx_Wall/Roof/Floor/Window _max/_min.
If you rename or add parameters in Workbench, update `derive()` / `OUTPUT_NAMES` in `ansys_bridge.py`.

## API
| Method | Path | Returns |
|---|---|---|
| GET | /health | bridge, ANSYS and project status |
| POST | /run | `{job_id}` (body: JSON inputs; missing ones use defaults) |
| GET | /status/{id} | `queued` / `running` / `done` / `error`, elapsed time |
| GET | /result/{id} | outputs, inputs, derived values |
| GET | /jobs | last 20 jobs |

Invalid designs (window does not fit, values out of range) are rejected with a clear message
before ANSYS starts. Only one ANSYS run executes at a time; extra requests wait in the queue.

## Troubleshooting
- **"ANSYS finished but wrote no results"**: Workbench was open, or the project path is wrong.
  Open `ansys_log.txt` in the job folder.
- **App says "Bridge not running"**: start `start_bridge.bat`; check the URL in the tab is `http://127.0.0.1:8765`.
- **Port in use**: change `PORT` in `ansys_bridge.py` and the URL in the app.
