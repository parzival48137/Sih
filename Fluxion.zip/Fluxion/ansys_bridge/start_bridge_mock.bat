@echo off
title Fluxion ANSYS Bridge (MOCK)
cd /d "%~dp0"
python ansys_bridge.py --mock
pause
