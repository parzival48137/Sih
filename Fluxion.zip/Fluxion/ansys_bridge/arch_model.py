"""Fluxion arch shelter model (Shelter_Arch.wbpj), built from scratch by script for every run.

Geometry (MAPDL batch -> IGES): half-cylinder shell of span W (outer radius W/2), length L, thickness
T_INS, split into 6 strips of 30 deg; flat end walls inside the shell (south one with the window on a
0.9 m sill), floor slab under everything, AIR body. Axis along Z (z = 0 south end, z = L north end),
+Y up, +X east.

Boundary conditions follow the box model (Shelter_General, ansys_case_v1.0.json):
- sun: the box's absorbed tables split into direct, diffuse and snow-reflected light (reproduces the
  box's east / west walls within 2 W/m2), then put on each strip at its own tilt, averaged over the strip;
- outside air: a strip with sky view (1 + sin phi)/2 mixes the box wall (h 15, -5.9 + 5.4 cos) and roof
  (h 18.5, -10.84 + 4.38 cos) conditions linearly: vertical strip = wall, horizontal = roof;
- end walls: south / north wall tables, h 15 to the wall ambient; window: h 15, sun 0.8 x south into the air;
- floor underside: ground (h 2 to 0 C) or raised (h 15 to the wall ambient);
- occupants and leakage as contract 1.1; -6 C start, 48 h.
The exposed edges of the shell and floor (0.1 m strips) are left adiabatic. The app's same-case solver is
src/js/archcase.js and uses the case data written by `python arch_model.py --js`.
"""
import json
import math
import os
import subprocess
import sys

def _mapdl():
    import re
    ks = sorted((k for k in os.environ if re.fullmatch(r"AWP_ROOT\d+", k)), key=lambda k: int(k[8:]))
    root = os.environ.get("TS_ANSYS_ROOT") or (os.environ[ks[-1]] if ks else r"C:\Program Files\ANSYS Inc\v182")
    ver = os.path.basename(root.rstrip("\\"))[1:]
    return os.path.join(root, "ansys", "bin", "winx64", "ANSYS%s.exe" % ver)


MAPDL = _mapdl()
SILL = 0.9
NSEC = 6
H_WALL, H_ROOF = 15.0, 18.5
WALL_A, WALL_B = -5.9, 5.4
ROOF_A, ROOF_B = -10.84, 4.38
COS = "cos(360*(time-54000)/86400)"

DEFAULTS = {"L": 6.0, "W": 4.5, "T_INS": 0.10, "K_INS": 0.025, "RHO_INS": 40.0, "CP_INS": 1500.0,
            "WIN_W": 1.2, "WIN_H": 1.0, "Q_INT": 0.0, "ACH": 0.0, "FLOOR": 0.0}
RANGES = {"L": (2.0, 30.0), "W": (2.0, 12.0), "T_INS": (0.02, 0.5), "K_INS": (0.005, 5.0),
          "RHO_INS": (5.0, 3000.0), "CP_INS": (100.0, 5000.0), "WIN_W": (0.2, 6.0), "WIN_H": (0.2, 3.0),
          "Q_INT": (0.0, 5000.0), "ACH": (0.0, 10.0), "FLOOR": (0.0, 1.0)}

# ---------------------------------------------------------------- sun (from the box model's tables)
BOX = {   # absorbed W/m2 (x 0.6), clock hours 0..23, ansys_case_v1.0.json
    "ROOF": [0]*8 + [41.4, 180.0, 302.2, 389.5, 434.5, 433.8, 387.4, 298.9, 175.7, 37.4] + [0]*6,
    "SOUTH": [0]*8 + [217.0, 452.5, 599.5, 690.0, 735.3, 734.4, 687.5, 595.1, 446.1, 205.8] + [0]*6,
    "NORTH": [0]*8 + [13.3, 57.9, 97.2, 128.0, 144.2, 143.9, 127.2, 96.1, 56.5, 12.0] + [0]*6,
}
LAT, LON, DOY, ABS = 34.16, 77.58, 15, 0.6


def sun_vec(h):
    """Unit vector (east, north, up) to the sun at clock hour h (IST), 15 Jan, Leh."""
    B = 2 * math.pi * (DOY - 81) / 364
    eot = 9.87 * math.sin(2 * B) - 7.53 * math.cos(B) - 1.5 * math.sin(B)
    dec = math.radians(23.45 * math.sin(math.radians(360 * (284 + DOY) / 365)))
    H = math.radians(15 * (h + (4 * (LON - 82.5) + eot) / 60 - 12)); p = math.radians(LAT)
    return (-math.cos(dec) * math.sin(H),
            math.sin(dec) * math.cos(p) - math.cos(dec) * math.sin(p) * math.cos(H),
            math.sin(p) * math.sin(dec) + math.cos(p) * math.cos(dec) * math.cos(H))


def sky_parts():
    """Per clock hour: direct normal, diffuse horizontal, ground reflectance x global, from the box tables."""
    out = []
    for h in range(24):
        e, n, u = sun_vec(h); g = BOX["ROOF"][h] / ABS
        if g <= 0 or u <= 0.01:
            out.append((0.0, 0.0, 0.0)); continue
        sv, nv = BOX["SOUTH"][h] / ABS, BOX["NORTH"][h] / ABS
        dni = (sv - nv) / (max(0, -n) - max(0, n))
        dhi = g - dni * u
        rg = 2 * (nv - max(0, n) * dni - dhi / 2)      # reflectance x global
        out.append((dni, dhi, rg))
    return out


def strip_tables():
    """Absorbed W/m2 per arch strip (k = 0 east-low .. 5 west-low), clock hours 0..23, strip-averaged."""
    parts, tabs = sky_parts(), []
    for k in range(NSEC):
        row = []
        for h in range(24):
            e, n, u = sun_vec(h); dni, dhi, rg = parts[h]; s = 0.0
            for j in range(20):
                phi = math.radians(30 * k + 30 * (j + 0.5) / 20)
                c, sp = math.cos(phi), math.sin(phi)
                s += dni * max(0.0, c * e + sp * u) + dhi * (1 + sp) / 2 + rg * (1 - sp) / 2
            row.append(round(ABS * s / 20, 2))
        tabs.append(row)
    return tabs


def strip_air():
    """Per strip: film coefficient and outside-air formula (mix of box wall and roof by sky view)."""
    out = []
    for k in range(NSEC):
        a1, a2 = math.radians(30 * k), math.radians(30 * (k + 1))
        s = (math.cos(a1) - math.cos(a2)) / (a2 - a1)            # strip average of sin(phi)
        h = H_WALL + s * (H_ROOF - H_WALL)
        a = (H_WALL * WALL_A + s * (H_ROOF * ROOF_A - H_WALL * WALL_A)) / h
        b = (H_WALL * WALL_B + s * (H_ROOF * ROOF_B - H_WALL * WALL_B)) / h
        out.append({"sin": round(s, 6), "h": round(h, 4), "a": round(a, 4), "b": round(b, 4)})
    return out


STRIPS, STRIP_AIR = strip_tables(), strip_air()


# ---------------------------------------------------------------- inputs
def validate(raw):
    inp, errs = {}, []
    for k, d in DEFAULTS.items():
        try: v = float(raw.get(k, d))
        except (TypeError, ValueError): errs.append(f"{k}: not a number"); continue
        lo, hi = RANGES[k]
        if not lo <= v <= hi: errs.append(f"{k} = {v} is outside {lo}-{hi}")
        inp[k] = v
    if errs: return inp, errs
    inp["FLOOR"] = 1.0 if inp["FLOOR"] >= 0.5 else 0.0
    ri = inp["W"] / 2 - inp["T_INS"]
    if ri < 1.0 or inp["L"] - 2 * inp["T_INS"] < 1.0:
        errs.append("insulation too thick for this arch")
    top = SILL + inp["WIN_H"]
    if top > ri - 0.05 or inp["WIN_W"] / 2 > math.sqrt(max(0.0, ri ** 2 - top ** 2)) - 0.05:
        errs.append("window does not fit in the south end wall (sill 0.9 m)")
    return inp, errs


def air_volume(inp):
    ri = inp["W"] / 2 - inp["T_INS"]
    return math.pi / 2 * ri ** 2 * (inp["L"] - 2 * inp["T_INS"])


# ---------------------------------------------------------------- geometry
def geometry_apdl(inp):
    L, Ro, T = inp["L"], inp["W"] / 2, inp["T_INS"]
    s = [f"L={L}", f"Ro={Ro}", f"T={T}", f"WW={inp['WIN_W']}", f"WH={inp['WIN_H']}", f"SILL={SILL}", "Ri=Ro-T", "/prep7"]
    for k in range(NSEC):
        s.append(f"cyl4,0,0,Ri,{30*k},Ro,{30*(k+1)},L")           # strips 1..6
    s += ["cyl4,0,0,0,0,Ri,180,T",                                   # 7 south end
          "wpoff,0,0,L-T", "cyl4,0,0,0,0,Ri,180,T", "wpcsys,-1",      # 8 north end
          "wpoff,0,0,T", "cyl4,0,0,0,0,Ri,180,L-2*T", "wpcsys,-1",    # 9 air
          "block,-WW/2,WW/2,SILL,SILL+WH,0,T",                         # 10 window
          "block,-Ro,Ro,-T,0,0,L",                                     # 11 floor
          "vsbv,7,10,,,KEEP", "allsel", "igesout,arch_geom,igs,,0", "finish"]
    return "\n".join(s) + "\n"


def build_geometry(inp, work):
    os.makedirs(work, exist_ok=True)
    for f in ("arch_geom.igs",):
        p = os.path.join(work, f)
        if os.path.exists(p): os.remove(p)
    open(os.path.join(work, "arch_geom.inp"), "w").write(geometry_apdl(inp))
    subprocess.run([MAPDL, "-b", "-np", "1", "-j", "archgeom", "-i", "arch_geom.inp", "-o", "arch_geom.out"],
                   cwd=work, check=False, timeout=600)
    igs = os.path.join(work, "arch_geom.igs")
    if not os.path.exists(igs): raise RuntimeError("MAPDL did not write the arch geometry")
    for f in os.listdir(work):
        if f.startswith("archgeom") and os.path.splitext(f)[1] in (".db", ".dbb", ".err", ".log", ".stat"):
            try: os.remove(os.path.join(work, f))
            except OSError: pass
    return igs


# ---------------------------------------------------------------- loads into APDL snippets
def amb(t, a=WALL_A, b=WALL_B):
    return a + b * math.cos(2 * math.pi * (t - 54000) / 86400)


def leak_apdl(inp):
    ach = inp["ACH"]
    if ach <= 0: return "! Fluxion: no air leakage (ACH = 0)\n"
    g = 0.87 * 1005.0 * air_volume(inp) * ach / 3600.0
    L = ["! Fluxion: air leakage %.3g 1/h -> %.4f W/K to outside air" % (ach, g),
         "fini", "/prep7",
         "*get,_ts_nmax,node,0,num,maxd", "_ts_namb=_ts_nmax+1", "n,_ts_namb,-50,-50,-50",
         "_ts_et=900", "et,_ts_et,34", "_ts_r=900", "r,_ts_r,1.0", "_ts_m=900",   # fixed IDs: Mechanical adds its own after this snippet
         "cmsel,s,AIR", "nsle,s", "*get,_ts_nn,node,0,count",
         "mp,hf,_ts_m,%.6f/_ts_nn" % g,
         "type,_ts_et", "real,_ts_r", "mat,_ts_m",
         "*get,_ts_nd,node,0,num,min",
         "*do,_ts_i,1,_ts_nn", "e,_ts_nd,_ts_namb", "*get,_ts_nd,node,_ts_nd,nxth", "*enddo",
         "allsel,all", "fini", "/solu", "*dim,_ts_tamb,table,49,1,1,time"]
    for i in range(49):
        L += ["_ts_tamb(%d,0,1)=%d" % (i + 1, i * 3600), "_ts_tamb(%d,1,1)=%.4f" % (i + 1, amb(i * 3600))]
    L += ["d,_ts_namb,temp,%_ts_tamb%", "allsel,all"]
    return "\n".join(L) + "\n"


def post_apdl(out_path):
    """At every result set: the volume-weighted average of the AIR temperature (comparable with the app's
    well-mixed air) and the hottest AIR node (warm pocket under the roof). Extremes for t >= 3600 s
    (whole run; no stored result at t = 0) and t >= 86400 s (day 2)."""
    p = out_path.replace("\\", "/")
    return "\n".join([
        "! Fluxion arch: air temperature (average and hottest point), whole run and day 2",
        "set,last", "*get,_ts_ns,active,0,set,nset",
        "_ts_lo=1e30", "_ts_hi=-1e30", "_ts_lo2=1e30", "_ts_hi2=-1e30", "_ts_pk=-1e30", "_ts_pk2=-1e30", "_ts_cnt=0",
        "allsel,all", "*get,_ts_nmx,node,0,num,maxd",
        "*del,_ts_tn,,nopr", "*dim,_ts_tn,array,_ts_nmx",
        # volume weight per AIR node: each element's volume shared over its distinct corner nodes
        "*del,_ts_w,,nopr", "*dim,_ts_w,array,_ts_nmx", "*del,_ts_c,,nopr", "*dim,_ts_c,array,8",
        "cmsel,s,AIR", "*get,_ts_ne,elem,0,count", "*get,_ts_e,elem,0,num,min",
        "*do,_ts_i,1,_ts_ne",
        "*get,_ts_v,elem,_ts_e,volu",
        "*do,_ts_j,1,8", "*get,_ts_c(_ts_j),elem,_ts_e,node,_ts_j", "*enddo",
        "_ts_nd=0",
        "*do,_ts_j,1,8", "_ts_dup=0", "*do,_ts_m,1,_ts_j-1", "*if,_ts_c(_ts_m),eq,_ts_c(_ts_j),then", "_ts_dup=1", "*endif", "*enddo",
        "*if,_ts_dup,eq,0,then", "_ts_nd=_ts_nd+1", "*endif", "*enddo",
        "*do,_ts_j,1,8", "_ts_dup=0", "*do,_ts_m,1,_ts_j-1", "*if,_ts_c(_ts_m),eq,_ts_c(_ts_j),then", "_ts_dup=1", "*endif", "*enddo",
        "*if,_ts_dup,eq,0,then", "_ts_n=_ts_c(_ts_j)", "_ts_w(_ts_n)=_ts_w(_ts_n)+_ts_v/_ts_nd", "*endif", "*enddo",
        "_ts_e=elnext(_ts_e)", "*enddo",
        "*vscfun,_ts_wsum,sum,_ts_w", "*del,_ts_wt,,nopr", "*dim,_ts_wt,array,_ts_nmx",
        "cmsel,s,AIR", "nsle,s",
        "*do,_ts_k,1,_ts_ns",
        "set,,,,,,,_ts_k", "*get,_ts_t,active,0,set,time",
        "*if,_ts_t,ge,3599,then",
        "*vget,_ts_tn,node,1,temp", "*voper,_ts_wt,_ts_tn,mult,_ts_w", "*vscfun,_ts_av,sum,_ts_wt", "_ts_av=_ts_av/_ts_wsum",
        "nsort,temp,,0", "*get,_ts_mx,sort,0,max", "_ts_cnt=_ts_cnt+1",
        "_ts_lo=min(_ts_lo,_ts_av)", "_ts_hi=max(_ts_hi,_ts_av)", "_ts_pk=max(_ts_pk,_ts_mx)",
        "*if,_ts_t,ge,86399,then", "_ts_lo2=min(_ts_lo2,_ts_av)", "_ts_hi2=max(_ts_hi2,_ts_av)", "_ts_pk2=max(_ts_pk2,_ts_mx)", "*endif",
        "*endif", "*enddo",
        "allsel,all",
        "*cfopen,%s,txt" % p,
        "*vwrite,_ts_lo,_ts_hi,_ts_lo2,_ts_hi2,_ts_pk,_ts_pk2,_ts_wsum,_ts_cnt", "(7(F14.5,1X),F8.0)",
        "*cfclos", ""])

def heatgen(inp):
    """Occupants and equipment into the air, W/m3 (constant)."""
    return [round(inp["Q_INT"] / air_volume(inp), 5) for h in range(49)]


def floor_sun(inp):
    """Window sun, W per hour 0..48: 0.8 x south irradiance x window area. It lands on the floor."""
    area = inp["WIN_W"] * inp["WIN_H"]
    return [round(0.8 * BOX["SOUTH"][h % 24] / ABS * area, 3) for h in range(49)]


# ---------------------------------------------------------------- Workbench journal
JOURNAL = r'''# encoding: utf-8
# Release 18.2 -- Fluxion arch model, job {job}
SetScriptVersion(Version="18.2.109")
log = open(r"{log}", "w")
try:
    tpl = GetTemplate(TemplateName="Transient Thermal", Solver="ANSYS")
    s = tpl.CreateSystem()
    s.DisplayText = "Arch shelter"
    eng = s.GetContainer(ComponentName="Engineering Data")
    MATS = {mats}
    for name, (k, rho, cp) in MATS.items():
        m = eng.CreateMaterial(Name=name)
        p = m.CreateProperty(Name="Density"); p.SetData(Index=-1, Variables=["Density"], Values=[["%s [kg m^-3]" % rho]])
        p = m.CreateProperty(Name="Thermal Conductivity", Behavior="Isotropic")
        p.SetData(Index=-1, Variables=["Thermal Conductivity"], Values=[["%s [W m^-1 C^-1]" % k]])
        p = m.CreateProperty(Name="Specific Heat")
        val, done, errs = [["%s [J kg^-1 C^-1]" % cp]], False, []
        for kw in [dict(), dict(SheetName="Specific Heat"), dict(SheetName="Specific Heat", SheetQualifiers={{"Definition": "Constant Pressure", "Behavior": ""}}),
                   dict(SheetName="Specific Heat", SheetQualifiers={{"Definition": "", "Behavior": ""}})]:
            try:
                p.SetData(Index=-1, Variables=["Specific Heat"], Values=val, **kw); done = True; log.write("cp set with %s\n" % kw); break
            except Exception as e:
                errs.append(str(e))
        if not done: raise Exception("specific heat: " + " | ".join(errs))
    log.write("materials %s\n" % ", ".join(MATS.keys()))
    s.GetContainer(ComponentName="Geometry").SetFile(FilePath=r"{igs}")
    s.GetComponent(Name="Geometry").Update(AllDependencies=True)
    s.GetComponent(Name="Model").Refresh()
    model = s.GetContainer(ComponentName="Model")
    model.Edit(Interactive=False)
    model.SendCommand(Language="Python", Command=MECH)
    model.Exit()
    log.write("mechanical done\n")
    Save(FilePath=r"{project}", Overwrite=True)
    log.write("saved\n")
    # the outputs are in air.txt; the 0.5 GB result file is not kept (the set-up stays, re-solve to see fields)
    import os
    rth = r"{project}"[:-5] + r"_files\dp0\SYS\MECH\file.rth"
    if os.path.exists(rth):
        os.remove(rth); log.write("result file removed\n")
except Exception as e:
    import traceback
    log.write("FAILED " + traceback.format_exc())
log.close()
'''

MECH = r'''
f = open(r"{mlog}", "w")
def say(t):
    f.write(t + "\n"); f.flush()
try:
    import math
    m = ExtAPI.DataModel.Project.Model
    a = m.Analyses[0]
    L, T, WW, WH = {L}, {T}, {WW}, {WH}
    bodies = m.Geometry.GetChildren(DataModelObjectCategory.Body, True)
    info = []
    for b in bodies:
        g = b.GetGeoBody(); c = list(g.Centroid)
        info.append((b, g, c, g.Volume))
    air = max(info, key=lambda x: x[3])
    floor = [x for x in info if x[2][1] < 0][0]
    win = [x for x in info if x is not air and x[2][2] < T and abs(x[3] - WW * WH * T) < 1e-3 * WW * WH * T + 1e-6][0]
    south = [x for x in info if x[2][2] < T and x is not win and x is not floor][0]
    north = [x for x in info if x[2][2] > L - T and x is not floor][0]
    used = [air, floor, win, south, north]
    strips = sorted([x for x in info if not [u for u in used if u is x]], key=lambda x: math.atan2(x[2][1], x[2][0]))
    if len(strips) != {nsec}: raise Exception("expected {nsec} strips, found %d" % len(strips))
    say("bodies ok: air %.3f m3, %d strips" % (air[3], len(strips)))
    def sel(ids):
        s_ = ExtAPI.SelectionManager.CreateSelectionInfo(SelectionTypeEnum.GeometryEntities); s_.Ids = ids; return s_
    def ns(name, ids):
        n = m.AddNamedSelection(); n.Name = name; n.Location = sel(ids); return n
    # materials
    def setmat(b, name):   # 18.2: Assignment; newer releases: Material
        try: b.Assignment = name
        except Exception: b.Material = name
    for x in strips + [south, north, floor]: setmat(x[0], "TS_shell")
    setmat(win[0], "TS_glass"); setmat(air[0], "TS_air")
    # material values straight to the solver for each body (matid = that body's material number)
    def props(x, k, rho, cp):
        c_ = x[0].AddCommandSnippet(); c_.Name = "TS_mat"
        c_.Input = "mp,kxx,matid,%s\nmp,dens,matid,%s\nmp,c,matid,%s\n" % (k, rho, cp)
    for x in strips + [south, north, floor]: props(x, {K}, {RHO}, {CP})
    props(win, 0.53, 200, 840); props(air, 10, 0.87, 1005)
    say("materials assigned")
    # mesh: thin solids finer, air coarser
    msh = m.Mesh
    msh.ElementSize = Quantity({esize}, "m")
    sz = msh.AddSizing(); sz.Location = sel([air[1].Id]); sz.ElementSize = Quantity({esize_air}, "m")
    # faces
    def face(x, test):
        fs = [fc for fc in x[1].Faces if test(list(fc.Centroid))]
        return max(fs, key=lambda fc: fc.Area)
    outer = [face(x, lambda c: 0.01 < c[2] < L - 0.01) for x in strips]
    s_out = face(south, lambda c: abs(c[2]) < 1e-4)
    n_out = face(north, lambda c: abs(c[2] - L) < 1e-4)
    w_out = face(win, lambda c: abs(c[2]) < 1e-4)
    f_bot = face(floor, lambda c: abs(c[1] + T) < 1e-4)
    f_top = face(floor, lambda c: abs(c[1]) < 1e-4)
    ns("AIR", [air[1].Id])
    for k, fc in enumerate(outer): ns("STRIP%d_OUT" % (k + 1), [fc.Id])
    ns("SOUTH_OUT", [s_out.Id]); ns("NORTH_OUT", [n_out.Id]); ns("WINDOW_OUT", [w_out.Id]); ns("FLOOR_BOTTOM", [f_bot.Id])
    say("faces: strips %s m2, south %.3f, north %.3f, window %.3f, floor %.3f" % (
        ", ".join(["%.3f" % fc.Area for fc in outer]), s_out.Area, n_out.Area, w_out.Area, f_bot.Area))
    # analysis settings
    st = a.AnalysisSettings
    st.StepEndTime = Quantity(172800, "s")
    st.AutomaticTimeStepping = AutomaticTimeStepping.On
    st.DefineBy = TimeStepDefineByType.Time
    st.InitialTimeStep = Quantity(600, "s"); st.MinimumTimeStep = Quantity(60, "s"); st.MaximumTimeStep = Quantity(1800, "s")
    try:
        st.StoreResultsAt = TimePointsOptions.EquallySpacedPoints; st.StoreResulsAtValue = 48
        say("results stored at 48 points")
    except Exception as e:
        say("store-results setting unchanged: %s" % e)
    a.InitialConditions[0].InitialTemperatureValue = Quantity(-6, "C")
    TIMES = [Quantity(3600 * i, "s") for i in range(49)]
    def conv(name, fc, h, formula):
        c = a.AddConvection(); c.Name = name; c.Location = sel([fc.Id])
        c.FilmCoefficient.Output.DiscreteValues = [Quantity(h, "W m^-1 m^-1 C^-1")]
        c.AmbientTemperature.Output.DefinitionType = VariableDefinitionType.Formula
        c.AmbientTemperature.Output.Formula = formula
    def flux(name, fc, vals):
        q = a.AddHeatFlux(); q.Name = name; q.Location = sel([fc.Id])
        q.Magnitude.Inputs[0].DiscreteValues = TIMES
        q.Magnitude.Output.DiscreteValues = [Quantity(v, "W m^-1 m^-1") for v in vals]
    AIRS, SUNS = {airs}, {suns}
    for k, fc in enumerate(outer):
        h, fa, fb = AIRS[k]
        conv("Conv_Strip%d" % (k + 1), fc, h, "%s+%s*{cos}" % (fa, fb))
        flux("Solar_Strip%d" % (k + 1), fc, SUNS[k])
    WALL = "{wall}"
    conv("Conv_South", s_out, 15.0, WALL); flux("Solar_South", s_out, {south})
    conv("Conv_North", n_out, 15.0, WALL); flux("Solar_North", n_out, {north})
    conv("Conv_Window", w_out, 15.0, WALL)
    if {raised}: conv("Conv_Floor", f_bot, 15.0, WALL)
    else:
        c = a.AddConvection(); c.Name = "Conv_Floor"; c.Location = sel([f_bot.Id])
        c.FilmCoefficient.Output.DiscreteValues = [Quantity(2.0, "W m^-1 m^-1 C^-1")]
        c.AmbientTemperature.Output.DiscreteValues = [Quantity(0.0, "C")]
    # window sun lands on the floor (spread over its top face), not in the air
    flux("Solar_Window_on_Floor", f_top, [w / f_top.Area for w in {floorsun}])
    g = a.AddInternalHeatGeneration(); g.Name = "People_and_Equipment"; g.Location = sel([air[1].Id])
    g.Magnitude.Inputs[0].DiscreteValues = TIMES
    g.Magnitude.Output.DiscreteValues = [Quantity(v, "W m^-1 m^-1 m^-1") for v in {gen}]
    say("loads set")
    sn = a.AddCommandSnippet(); sn.Name = "TS_leakage"; sn.Input = {leak}
    sp = a.Solution.AddCommandSnippet(); sp.Name = "TS_post"; sp.Input = {post}
    say("snippets set; solving")
    a.Solution.Solve(True)
    say("solve state %s" % str(a.Solution.Status))
except Exception as e:
    import traceback
    f.write("FAILED " + traceback.format_exc())
f.close()
'''


def build_journal(inp, job, out_dir, project, esize=0.2, esize_air=0.6):
    igs = os.path.join(out_dir, "arch_geom.igs")
    mats = {"TS_shell": (inp["K_INS"], inp["RHO_INS"], inp["CP_INS"]), "TS_glass": (0.53, 200, 840), "TS_air": (10, 0.87, 1005)}
    mech = MECH.format(
        mlog=os.path.join(out_dir, "mech_log.txt"), K=inp["K_INS"], RHO=inp["RHO_INS"], CP=inp["CP_INS"], L=inp["L"], T=inp["T_INS"], WW=inp["WIN_W"], WH=inp["WIN_H"],
        nsec=NSEC, esize=min(esize, max(2 * inp["T_INS"], 0.08)), esize_air=esize_air,
        airs=repr([(x["h"], x["a"], x["b"]) for x in STRIP_AIR]),
        suns=repr([[t[h % 24] for h in range(49)] for t in STRIPS]),
        cos=COS, wall="%s+%s*%s" % (WALL_A, WALL_B, COS),
        south=repr([BOX["SOUTH"][h % 24] for h in range(49)]), north=repr([BOX["NORTH"][h % 24] for h in range(49)]),
        raised=bool(inp["FLOOR"]), gen=repr(heatgen(inp)), floorsun=repr(floor_sun(inp)),
        leak=repr(leak_apdl(inp)), post=repr(post_apdl(os.path.join(out_dir, "air"))))
    j = JOURNAL.format(job=job, log=os.path.join(out_dir, "wb_log.txt"), mats=repr(mats), igs=igs, project=project)
    return j.replace("    model.SendCommand(Language=\"Python\", Command=MECH)",
                     "    MECH = " + repr(mech) + "\n    model.SendCommand(Language=\"Python\", Command=MECH)")


def read_outputs(out_dir):
    p = os.path.join(out_dir, "air.txt")
    if not os.path.exists(p): return None
    v = open(p).read().split()
    # T_AIR_* = average air temperature (as the app's mixed air); T_AIR_PEAK_* = hottest air point
    return {"T_AIR_MIN": float(v[0]), "T_AIR_MAX": float(v[1]), "T_AIR_MIN_DAY2": float(v[2]),
            "T_AIR_MAX_DAY2": float(v[3]), "T_AIR_PEAK": float(v[4]), "T_AIR_PEAK_DAY2": float(v[5]), "air_volume_check": float(v[6]), "sets": int(float(v[7]))}


def case_js():
    """Case data for src/js/archcase.js (the app's same-case solver)."""
    return json.dumps({"strips": STRIPS, "air": STRIP_AIR, "south": BOX["SOUTH"], "north": BOX["NORTH"]})


if __name__ == "__main__":
    if "--js" in sys.argv:
        print(case_js())
