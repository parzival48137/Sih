"""
Fluxion ANSYS Bridge
=======================================================
Runs on the same Windows PC as ANSYS Workbench. The app (PWA / desktop) sends
shelter inputs over localhost; the bridge writes a Workbench journal, runs
ANSYS in batch mode (no GUI), reads the results CSV and returns JSON.

    App --POST /run--> Bridge --journal--> RunWB2.exe -B -R --> ANSYS
    App <--/status, /result-- Bridge <--results.csv--------------'

Pure Python standard library: no pip install needed.
Start:  python ansys_bridge.py          (real ANSYS)
        python ansys_bridge.py --mock   (no ANSYS: returns sample results, for app development)

Endpoints (all JSON, CORS-enabled, bound to 127.0.0.1 only):
    GET  /health            -> bridge, ANSYS and project status
    POST /run               -> {"job_id": ...}   body = shelter inputs (see DEFAULTS)
    GET  /status/<job_id>   -> {"state": queued|running|done|error, "elapsed_s": ...}
    GET  /result/<job_id>   -> {"outputs": {...}, "inputs": {...}, "derived": {...}}
    GET  /jobs              -> list of recent jobs
"""

import csv
import json
import math
import os
import re
import subprocess
import sys
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import arch_model  # noqa: E402

# ----------------------------------------------------------------------------
# CONFIG - edit these three paths if your install / folder differs
# ----------------------------------------------------------------------------
# Found automatically: the newest ANSYS (AWP_ROOTxxx, set by every ANSYS install) and the models shipped
# in ../ansys_models next to the app. Override with environment variables if needed.
HERE = os.path.dirname(os.path.abspath(__file__))
MODELS = os.path.join(os.path.dirname(HERE), "ansys_models")


def _ansys_root():
    roots = sorted((k for k in os.environ if re.fullmatch(r"AWP_ROOT\d+", k)), key=lambda k: int(k[8:]))
    return os.environ[roots[-1]] if roots else r"C:\Program Files\ANSYS Inc\v182"


ANSYS_ROOT = os.environ.get("TS_ANSYS_ROOT", _ansys_root())
RUNWB2 = os.path.join(ANSYS_ROOT, "Framework", "bin", "Win64", "RunWB2.exe")
_shipped = os.path.join(MODELS, "Shelter_General.wbpj")
PROJECT = os.environ.get("TS_PROJECT", _shipped if os.path.exists(_shipped) else r"D:\SIH26\Analysis\Shelter_General.wbpj")
ARCH_PROJECT = os.path.join(os.path.dirname(PROJECT), "Shelter_Arch.wbpj")     # rebuilt by script on every arch run
WORK_DIR = os.environ.get("BRIDGE_WORK_DIR", os.path.join(os.path.dirname(PROJECT), "bridge_jobs"))

HOST, PORT = "127.0.0.1", 8765
# 1.0.1 (4 Oct 2026): the window sun (Solar_Window) is set for each run from WIN_W x WIN_H.
# 1.1   (4 Oct 2026): new inputs Q_INT (W into the air), ACH (air leakage, 1/h) and FLOOR
#       (0 ground / 1 raised); all 0 gives exactly the 1.0.1 case.
# Keep in step with CONTRACT in bridge.js.
# 1.2   (4 Oct 2026): MODEL = "arch" runs the arch shelter project (Shelter_Arch.wbpj, built by arch_model.py);
#       W is then the span, H is not used. Box runs are unchanged.
# 1.3   (4 Oct 2026): arch window sun on the floor; arch T_AIR_* = volume-average air, T_AIR_PEAK = hottest point.
# 1.4   (4 Oct 2026): box model T_AIR_* = volume-average air too (was the hottest node); T_AIR_PEAK = hottest point.
CONTRACT_VERSION = "1.4"
AIR_RHO, AIR_CP = 0.87, 1005.0      # the model's effective air (ansys_case_v1.0.json)
AMB_WALL = "-5.9+5.4*cos(360*(time-54000)/86400)"
TIMEOUT_S = 45 * 60          # kill a stuck ANSYS run after 45 min
SILL_M = 0.9                 # window sill height (fixed in the general model)
MOCK = "--mock" in sys.argv

# Default inputs (the validated base case: 5 x 4 x 2.8 m PUF shelter)
DEFAULTS = {
    "L": 5.0, "W": 4.0, "H": 2.8,            # m
    "T_INS": 0.10,                            # m  insulation (shell) thickness
    "K_INS": 0.025, "RHO_INS": 40.0, "CP_INS": 1500.0,
    "WIN_W": 1.5, "WIN_H": 1.2,               # m  south window
    # contract 1.1 (all 0 = the v1.0 case)
    "Q_INT": 0.0,                             # W  heat from occupants and equipment, into the air
    "ACH": 0.0,                               # 1/h air leakage to outside air
    "FLOOR": 0.0,                             # 0 = on the ground (h 2 to 0 C), 1 = raised (h 15 to outside air)
}

# Plausible ranges (min, max). Outside these the run is refused.
RANGES = {
    "L": (2.0, 20.0), "W": (2.0, 15.0), "H": (2.0, 6.0),
    "T_INS": (0.02, 0.5),
    "K_INS": (0.005, 5.0), "RHO_INS": (5.0, 3000.0), "CP_INS": (100.0, 5000.0),
    "WIN_W": (0.2, 10.0), "WIN_H": (0.2, 4.0),
    "Q_INT": (0.0, 5000.0), "ACH": (0.0, 10.0), "FLOOR": (0.0, 1.0),
}

# Workbench output parameters (DisplayText as named in the Parameter Set)
OUTPUT_NAMES = {
    "T_AIR_MAX": "C", "T_AIR_MIN": "C",
    "Rx_Wall_max": "W", "Rx_Wall_min": "W",
    "Rx_Roof_max": "W", "Rx_Roof_min": "W",
    "Rx_Floor_max": "W", "Rx_Floor_min": "W",
    "Rx_Window_max": "W", "Rx_Window_min": "W",
}
EXTRA_OUTPUTS = {"T_AIR_MIN_DAY2": "C", "T_AIR_MAX_DAY2": "C"}   # contract 1.1, from the TS_day2 snippet

# Sample result from the real batch test (2 Oct 2026, base case) for --mock mode
MOCK_OUTPUTS = {
    "T_AIR_MAX": 65.1807, "T_AIR_MIN": -8.8092,
    "Rx_Wall_max": 37.07, "Rx_Wall_min": -15930.85,
    "Rx_Roof_max": -35.47, "Rx_Roof_min": -10589.0,
    "Rx_Floor_max": 84.26, "Rx_Floor_min": -344.71,
    "Rx_Window_max": 2.18, "Rx_Window_min": -433.89,
}

JOURNAL_TEMPLATE = '''# encoding: utf-8
# Release 18.2  -- generated by Fluxion ANSYS Bridge, job {job_id}
SetScriptVersion(Version="18.2.109")
Open(FilePath="{project}")
dp = Parameters.GetDesignPoint(Name="0")
inputs = {{
{inputs_block}
}}
for name, expr in inputs.items():
    dp.SetParameterExpression(Parameter=Parameters.GetParameter(Name=name), Expression=expr)
# window sun for THIS design (W/m3 of the AIR body): 0.8 x south irradiance x window area / air volume
MECH = r"""
f = open(r"{window_log}", "w")
try:
    a = ExtAPI.DataModel.Project.Model.Analyses[0]
    g = [c for c in a.Children if c.Name == "Solar_Window"][0]
    vals = {window_values}
    n = len(g.Magnitude.Output.DiscreteValues)
    if n != len(vals):
        raise Exception("Solar_Window has %d points, expected %d" % (n, len(vals)))
    g.Magnitude.Output.DiscreteValues = [Quantity(v, "W m^-1 m^-1 m^-1") for v in vals]
    back = [x.Value for x in g.Magnitude.Output.DiscreteValues]
    worst = max([abs(back[i] - vals[i]) for i in range(n)])
    msg = "OK %d points, peak %.4f W/m3, max readback error %.2e" % (n, max(back), worst)
    # floor: 1 = raised (h 15 to outside air, as the walls), 0 = on the ground (h 2 to 0 C)
    c = [x for x in a.Children if x.Name == "Conv_Floor"][0]
    if {floor_raised}:
        c.FilmCoefficient.Output.DiscreteValues = [Quantity(15.0, "W m^-1 m^-1 C^-1")]
        c.AmbientTemperature.Output.DefinitionType = VariableDefinitionType.Formula
        c.AmbientTemperature.Output.Formula = "{amb_wall}"
        okf = str(c.AmbientTemperature.Output.Formula) == "{amb_wall}"
    else:
        c.FilmCoefficient.Output.DiscreteValues = [Quantity(2.0, "W m^-1 m^-1 C^-1")]
        c.AmbientTemperature.Output.DefinitionType = VariableDefinitionType.Discrete
        c.AmbientTemperature.Output.DiscreteValues = [Quantity(0.0, "C")]
        okf = abs(c.AmbientTemperature.Output.DiscreteValues[0].Value) < 1e-9
    hb = c.FilmCoefficient.Output.DiscreteValues[0].Value
    if not okf: raise Exception("floor ambient not set")
    msg += "; floor %s h %.1f" % ("raised" if {floor_raised} else "ground", hb)
    # air leakage: APDL Commands object, created once, text set every run
    leak = {leak_apdl}
    sn = [x for x in a.Children if x.Name == "TS_leakage"]
    if sn: sn = sn[0]
    else:
        sn = a.AddCommandSnippet(); sn.Name = "TS_leakage"
    sn.Input = leak
    if str(sn.Input).strip() != leak.strip(): raise Exception("leakage snippet text not stored")
    msg += "; leakage snippet %d lines" % len(leak.strip().splitlines())
    # day-2 air temperature extremes: post-processing Commands object under Solution
    day2 = {day2_apdl}
    sp = [x for x in a.Solution.Children if x.Name == "TS_day2"]
    if sp: sp = sp[0]
    else:
        sp = a.Solution.AddCommandSnippet(); sp.Name = "TS_day2"
    sp.Input = day2
    if str(sp.Input).strip() != day2.strip(): raise Exception("day-2 snippet text not stored")
    msg += "; day-2 snippet set"
    f.write(msg + "\\n")
except Exception as e:
    import traceback
    f.write("FAILED " + traceback.format_exc())
f.close()
"""
system1 = GetSystem(Name="SYS")
model = system1.GetContainer(ComponentName="Model")
model.Edit(Interactive=False)
model.SendCommand(Language="Python", Command=MECH)
model.Exit()
UpdateAllDesignPoints(DesignPoints=[dp])
f = open(r"{results_csv}", "w")
f.write("id,name,value\\n")
for p in Parameters.GetAllParameters():
    f.write('%s,"%s","%s"\\n' % (p.Name, p.DisplayText, p.Value))
f.close()
Save(Overwrite=True)
'''

# ----------------------------------------------------------------------------
# Validation + derived geometry
# ----------------------------------------------------------------------------
def validate(raw):
    """Merge with defaults, type-check, range-check, geometric checks.
    Returns (inputs, errors)."""
    inp, errors = {}, []
    if "FLOOR" in raw:
        try: raw = dict(raw, FLOOR=1.0 if float(raw["FLOOR"]) >= 0.5 else 0.0)
        except (TypeError, ValueError): pass
    for key, default in DEFAULTS.items():
        val = raw.get(key, default)
        try:
            val = float(val)
        except (TypeError, ValueError):
            errors.append(f"{key}: not a number ({val!r})")
            continue
        if val != val or val in (float("inf"), float("-inf")):
            errors.append(f"{key}: not a finite number")
            continue
        lo, hi = RANGES[key]
        if not lo <= val <= hi:
            errors.append(f"{key} = {val} is outside the allowed range {lo}-{hi}")
        inp[key] = val
    if errors:
        return inp, errors

    L, W, H, T = inp["L"], inp["W"], inp["H"], inp["T_INS"]
    if L - 2 * T < 1.0 or W - 2 * T < 1.0 or H - 2 * T < 1.5:
        errors.append("Insulation too thick for this shelter size (inner room would be < 1 m wide or < 1.5 m high)")
    if inp["WIN_W"] > L - 2 * T - 0.1:
        errors.append(f"Window width {inp['WIN_W']} m does not fit in the south wall (max {L - 2*T - 0.1:.2f} m)")
    if SILL_M + inp["WIN_H"] > H - T - 0.05:
        errors.append(f"Window height {inp['WIN_H']} m does not fit (sill {SILL_M} m; max {H - T - 0.05 - SILL_M:.2f} m)")
    return inp, errors


def derive(inp):
    """Map user inputs to the Workbench parameter IDs (P-numbers)."""
    L, W, H, T = inp["L"], inp["W"], inp["H"], inp["T_INS"]
    d = {
        "L_IN": L - 2 * T, "W_IN": W - 2 * T, "H_IN": H - 2 * T,
        "WIN_X": (L - inp["WIN_W"]) / 2, "SILL": SILL_M,
    }
    p = {
        "P1": (inp["RHO_INS"], "kg m^-3"),
        "P2": (inp["K_INS"], "W m^-1 C^-1"),
        "P3": (inp["CP_INS"], "J kg^-1 C^-1"),
        "P7": (L, "m"), "P8": (W, "m"), "P9": (H, "m"),
        "P13": (T, "m"), "P14": (T, "m"), "P15": (T, "m"),
        "P16": (d["L_IN"], "m"), "P17": (d["W_IN"], "m"), "P18": (d["H_IN"], "m"),
        "P19": (d["WIN_X"], "m"), "P21": (d["SILL"], "m"),
        "P22": (inp["WIN_W"], "m"), "P23": (T, "m"), "P24": (inp["WIN_H"], "m"),
    }
    return d, p


# Absorbed south-wall flux (W/m2, already x 0.6) at clock hours 0..23, from ansys_case_v1.0.json.
# The model's Solar_Window table has 49 hourly points over the 48 h run.
SOUTH_ABS = [0, 0, 0, 0, 0, 0, 0, 0, 217.0, 452.5, 599.5, 690.0, 735.3, 734.4, 687.5, 595.1, 446.1, 205.8, 0, 0, 0, 0, 0, 0]
TAU_WIN, ABS_OPAQUE = 0.8, 0.6


def air_volume(inp):
    L, W, H, T = inp["L"], inp["W"], inp["H"], inp["T_INS"]
    return (L - 2 * T) * (W - 2 * T) * (H - 2 * T)


def window_gain(inp):
    """W/m3 for the AIR body at each hour 0..48: (0.8 x south irradiance x window area + Q_INT) / air volume.
    For the base case (Q_INT 0) this reproduces the table built on 2 Oct (peak 37.2 W/m3)."""
    vol, area, q = air_volume(inp), inp["WIN_W"] * inp["WIN_H"], inp.get("Q_INT", 0.0)
    return [round((TAU_WIN * SOUTH_ABS[h % 24] / ABS_OPAQUE * area + q) / vol, 4) for h in range(49)]


def leak_apdl(inp):
    """APDL for the Commands object 'TS_leakage': a LINK34 convection link from every AIR node to one
    outside-air node held at the wall ambient function; total conductance rho cp V ACH / 3600 (W/K)."""
    ach = inp.get("ACH", 0.0)
    if ach <= 0:
        return "! Fluxion: no air leakage (ACH = 0)\n"
    g = AIR_RHO * AIR_CP * air_volume(inp) * ach / 3600.0
    amb = lambda t: -5.9 + 5.4 * math.cos(2 * math.pi * (t - 54000) / 86400)
    L = ["! Fluxion contract 1.1: air leakage %.3g 1/h -> %.4f W/K to outside air" % (ach, g),
         "fini", "/prep7",
         "*get,_ts_nmax,node,0,num,maxd", "_ts_namb=_ts_nmax+1", "n,_ts_namb,-50,-50,-50",
         "*get,_ts_tmax,etyp,0,num,max", "_ts_et=_ts_tmax+1", "et,_ts_et,34",
         "*get,_ts_rmax,rcon,0,num,max", "_ts_r=_ts_rmax+1", "r,_ts_r,1.0",
         "*get,_ts_mmax,mat,0,num,max", "_ts_m=_ts_mmax+1",
         "cmsel,s,AIR", "nsle,s", "*get,_ts_nn,node,0,count",
         "mp,hf,_ts_m,%.6f/_ts_nn" % g,
         "type,_ts_et", "real,_ts_r", "mat,_ts_m",
         "*get,_ts_nd,node,0,num,min",
         "*do,_ts_i,1,_ts_nn", "e,_ts_nd,_ts_namb", "*get,_ts_nd,node,_ts_nd,nxth", "*enddo",
         "allsel,all", "fini", "/solu",
         "*dim,_ts_tamb,table,49,1,1,time"]
    for i in range(49):
        L.append("_ts_tamb(%d,0,1)=%d" % (i + 1, i * 3600))
        L.append("_ts_tamb(%d,1,1)=%.4f" % (i + 1, amb(i * 3600)))
    L += ["d,_ts_namb,temp,%_ts_tamb%", "allsel,all"]
    return "\n".join(L) + "\n"


def lastday_apdl(out_path):
    """APDL for the post-processing Commands object 'TS_day2': for every result set at t >= 86400 s,
    the maximum AIR node temperature (as the 'Temperature Air' probe, spatial maximum); writes the
    minimum and maximum of those values over day 2 to out_path.txt."""
    p = out_path.replace("\\", "/")
    return "\n".join([
        "! Fluxion contract 1.1: air temperature extremes over day 2 (t >= 86400 s)",
        "set,last", "*get,_ts_ns,active,0,set,nset",
        "_ts_lo=1e30", "_ts_hi=-1e30", "_ts_cnt=0",
        "cmsel,s,AIR", "nsle,s",
        "*do,_ts_k,1,_ts_ns",
        "set,,,,,,,_ts_k", "*get,_ts_t,active,0,set,time",
        "*if,_ts_t,ge,86399,then",
        "nsort,temp,,0", "*get,_ts_mx,sort,0,max", "_ts_cnt=_ts_cnt+1",
        "*if,_ts_mx,lt,_ts_lo,then", "_ts_lo=_ts_mx", "*endif",
        "*if,_ts_mx,gt,_ts_hi,then", "_ts_hi=_ts_mx", "*endif",
        "*endif", "*enddo",
        "allsel,all",
        "*cfopen,%s,txt" % p,
        "*vwrite,_ts_lo,_ts_hi,_ts_cnt", "(F14.5,1X,F14.5,1X,F8.0)",
        "*cfclos", ""])


def build_journal(job_id, params, results_csv, inp=None, window_log="", day2_base=None):
    lines = [f' "{pid}": "{val:.6g} [{unit}]",' for pid, (val, unit) in params.items()]
    return JOURNAL_TEMPLATE.format(
        job_id=job_id,
        project=PROJECT.replace("\\", "/"),
        inputs_block="\n".join(lines),
        results_csv=results_csv,
        window_values=repr(window_gain(inp or DEFAULTS)),
        window_log=window_log,
        floor_raised=1 if (inp or DEFAULTS).get("FLOOR", 0) >= 0.5 else 0,
        amb_wall=AMB_WALL,
        leak_apdl=repr(leak_apdl(inp or DEFAULTS)),
        # 1.4: the same post step as the arch model: volume-average air (whole run, day 2) + hottest point -> air.txt
        day2_apdl=repr(arch_model.post_apdl(day2_base or os.path.join(os.path.dirname(results_csv), "air"))),
    )


def parse_results(path):
    """Read 'id,name,value' CSV written by the journal -> {name: float}."""
    outputs, raw = {}, {}
    with open(path, newline="", encoding="utf-8", errors="replace") as f:
        for row in csv.DictReader(f):
            name, value = row.get("name", ""), row.get("value", "")
            raw[row.get("id", "")] = {"name": name, "value": value}
            m = re.match(r"\s*([-+0-9.eE]+)", value or "")
            if name in OUTPUT_NAMES and m:
                outputs[name] = float(m.group(1))
    return outputs, raw


# ----------------------------------------------------------------------------
# Job runner (one ANSYS run at a time: Workbench cannot open a project twice)
# ----------------------------------------------------------------------------
JOBS = {}
JOBS_LOCK = threading.Lock()
ANSYS_LOCK = threading.Lock()


def run_job(job_id):
    job = JOBS[job_id]
    job_dir = os.path.join(WORK_DIR, job_id)
    os.makedirs(job_dir, exist_ok=True)
    results_csv = os.path.join(job_dir, "results.csv")
    journal_path = os.path.join(job_dir, "run.wbjn")
    log_path = os.path.join(job_dir, "ansys_log.txt")
    window_log = os.path.join(job_dir, "window_set.txt")

    with ANSYS_LOCK:                                   # wait for previous run
        job["state"], job["started"] = "running", time.time()
        try:
            if MOCK:
                time.sleep(6)
                job["outputs"] = dict(MOCK_OUTPUTS)
                job["mock"] = True
            elif job.get("model") == "arch":
                arch_model.build_geometry(job["inputs"], job_dir)
                with open(journal_path, "w", encoding="utf-8") as f:
                    f.write(arch_model.build_journal(job["inputs"], job_id, job_dir, ARCH_PROJECT))
                with open(log_path, "w", encoding="utf-8") as log:
                    proc = subprocess.run([RUNWB2, "-B", "-R", journal_path], stdout=log, stderr=subprocess.STDOUT, timeout=TIMEOUT_S)
                ml = os.path.join(job_dir, "mech_log.txt")
                mtxt = open(ml, encoding="utf-8", errors="replace").read() if os.path.exists(ml) else ""
                out = arch_model.read_outputs(job_dir)
                if "solve state Done" not in mtxt or not out:
                    raise RuntimeError("Arch model did not solve (exit %s). %s" % (proc.returncode, mtxt.strip()[-400:] or "No Mechanical log."))
                job["window"] = "arch model: " + "; ".join(l for l in mtxt.splitlines() if l.startswith("faces"))
                job["outputs"] = {k: v for k, v in out.items() if k not in ("sets", "air_volume_check")}
            else:
                with open(journal_path, "w", encoding="utf-8") as f:
                    f.write(build_journal(job_id, job["params"], results_csv, job["inputs"], window_log))
                with open(log_path, "w", encoding="utf-8") as log:
                    proc = subprocess.run(
                        [RUNWB2, "-B", "-R", journal_path],
                        stdout=log, stderr=subprocess.STDOUT, timeout=TIMEOUT_S,
                    )
                if not os.path.exists(results_csv):
                    raise RuntimeError(
                        f"ANSYS finished (exit code {proc.returncode}) but wrote no results. "
                        f"Is Workbench still open with this project? Log: {log_path}")
                # the window sun must have been set for this design, else the numbers belong to another case
                wl = open(window_log, encoding="utf-8", errors="replace").read() if os.path.exists(window_log) else ""
                if not wl.startswith("OK"):
                    raise RuntimeError("Window sun was not updated in Mechanical, results not used. " + (wl.strip()[:400] or "No window log written."))
                job["window"] = wl.strip()
                outputs, raw = parse_results(results_csv)
                # contract 1.1: air temperature extremes over day 2, written by the TS_day2 snippet
                # contract 1.4: volume-average air (comparable with the app's mixed air) replaces the
                # Workbench probe (hottest node), which is kept as T_AIR_PEAK
                av = arch_model.read_outputs(job_dir)
                if av and av["sets"] > 0:
                    outputs["T_AIR_PEAK_PROBE_MAX"], outputs["T_AIR_PROBE_MIN"] = outputs.get("T_AIR_MAX"), outputs.get("T_AIR_MIN")
                    outputs.update({k: v for k, v in av.items() if k not in ("sets", "air_volume_check")})
                    job["air_volume_check"] = av["air_volume_check"]
                else:
                    job.setdefault("warnings", []).append("Average air temperature not written (TS_day2 snippet); values are the hottest air point")
                missing = [n for n in OUTPUT_NAMES if n not in outputs]
                if missing:
                    job["warnings"] = [f"Output not found in results: {', '.join(missing)}"]
                job["outputs"], job["raw"] = outputs, raw
            job["state"] = "done"
        except subprocess.TimeoutExpired:
            job["state"], job["error"] = "error", f"ANSYS run exceeded {TIMEOUT_S // 60} min and was stopped"
        except Exception as exc:                       # report, never crash the bridge
            job["state"], job["error"] = "error", str(exc)
        finally:
            job["finished"] = time.time()


def public_view(job, full=False):
    now = time.time()
    view = {
        "job_id": job["job_id"], "state": job["state"], "model": job.get("model", "box"),
        "submitted": job["submitted"],
        "elapsed_s": round((job.get("finished") or now) - (job.get("started") or now), 1),
        "inputs": job["inputs"],
    }
    view["contract_version"] = CONTRACT_VERSION
    for key in ("error", "warnings", "mock", "window"):
        if key in job:
            view[key] = job[key]
    if full:
        view["derived"] = job["derived"]
        view["outputs"] = job.get("outputs", {})
        view["units"] = dict(OUTPUT_NAMES, **EXTRA_OUTPUTS)
    return view


# ----------------------------------------------------------------------------
# HTTP layer
# ----------------------------------------------------------------------------
class Handler(BaseHTTPRequestHandler):
    def _send(self, code, payload):
        body = json.dumps(payload).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self._cors()
        self.end_headers()
        self.wfile.write(body)

    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        # Lets a page served from another origin reach localhost (Chrome Private Network Access)
        self.send_header("Access-Control-Allow-Private-Network", "true")

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.end_headers()

    def do_GET(self):
        parts = [p for p in self.path.split("?")[0].split("/") if p]
        if parts == ["health"]:
            busy = any(j["state"] in ("queued", "running") for j in JOBS.values())
            return self._send(200, {
                "ok": True, "mock": MOCK, "busy": busy, "contract_version": CONTRACT_VERSION,
                "ansys_found": MOCK or os.path.exists(RUNWB2),
                "project_found": MOCK or os.path.exists(PROJECT),
                "defaults": DEFAULTS, "ranges": RANGES,
                "models": {"box": MOCK or os.path.exists(PROJECT), "arch": MOCK or os.path.exists(arch_model.MAPDL)},
            })
        if parts == ["jobs"]:
            with JOBS_LOCK:
                jobs = sorted(JOBS.values(), key=lambda j: j["submitted"], reverse=True)[:20]
            return self._send(200, [public_view(j) for j in jobs])
        if len(parts) == 2 and parts[0] in ("status", "result"):
            job = JOBS.get(parts[1])
            if not job:
                return self._send(404, {"error": "unknown job"})
            if parts[0] == "result" and job["state"] != "done":
                return self._send(409, {"error": f"job is {job['state']}", **public_view(job)})
            return self._send(200, public_view(job, full=parts[0] == "result"))
        self._send(404, {"error": "not found"})

    def do_POST(self):
        if self.path.split("?")[0].rstrip("/") != "/run":
            return self._send(404, {"error": "not found"})
        try:
            length = int(self.headers.get("Content-Length", 0))
            raw = json.loads(self.rfile.read(length) or b"{}")
        except (ValueError, json.JSONDecodeError):
            return self._send(400, {"error": "body must be JSON"})
        if not MOCK and not os.path.exists(RUNWB2):
            return self._send(503, {"error": f"RunWB2.exe not found at {RUNWB2}. Edit RUNWB2 in ansys_bridge.py"})
        if not MOCK and not os.path.exists(PROJECT):
            return self._send(503, {"error": f"Project not found at {PROJECT}. Edit PROJECT in ansys_bridge.py"})

        model = "arch" if str(raw.get("MODEL", "box")).lower() == "arch" else "box"
        if model == "arch":
            inputs, errors = arch_model.validate(raw)
            derived, params = {"model": "arch", "air_volume": arch_model.air_volume(inputs) if not errors else None}, {}
        else:
            inputs, errors = validate(raw)
        if errors:
            return self._send(422, {"error": "invalid inputs", "details": errors})
        if model == "box":
            derived, params = derive(inputs)
        job_id = time.strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:4]
        with JOBS_LOCK:
            JOBS[job_id] = {
                "job_id": job_id, "state": "queued", "submitted": time.time(),
                "inputs": inputs, "derived": derived, "params": params, "model": model,
            }
        threading.Thread(target=run_job, args=(job_id,), daemon=True).start()
        self._send(202, {"job_id": job_id, "state": "queued"})

    def log_message(self, fmt, *args):            # quieter console
        sys.stdout.write("[bridge] " + (fmt % args) + "\n")


def main():
    os.makedirs(WORK_DIR, exist_ok=True)
    print("=" * 64)
    print(" Fluxion ANSYS Bridge" + ("   [MOCK MODE: no ANSYS]" if MOCK else ""))
    print(f" Listening on http://{HOST}:{PORT}   (local only)")
    if not MOCK:
        print(f" RunWB2  : {RUNWB2}  {'OK' if os.path.exists(RUNWB2) else 'NOT FOUND'}")
        print(f" Project : {PROJECT}  {'OK' if os.path.exists(PROJECT) else 'NOT FOUND'}")
        print(" Keep Workbench CLOSED while the app runs ANSYS jobs.")
    print(" Press Ctrl+C to stop.")
    print("=" * 64)
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()


if __name__ == "__main__":
    main()
