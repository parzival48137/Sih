Fluxion - shelter thermal design for cold high-altitude regions

START THE APP (pick one)
A. Double-click  Fluxion.html  -> it opens in Edge or Chrome. Works on every Windows PC,
   offline, nothing to install. Use this if Windows blocks Fluxion.exe.
B. Double-click  Fluxion.exe   (desktop window). Windows "Smart App Control" blocks unsigned
   apps downloaded from the internet; if you see "Smart App Control blocked an app", use A.
   (Plain SmartScreen warning instead? Click "More info" > "Run anyway".)

Keep all files of this folder together.

CHECK IN ANSYS (optional)
- Needs ANSYS Workbench with a licence on this PC (found automatically) and Python 3
  (https://www.python.org/downloads/, tick "Add python.exe to PATH").
- Start the connection: double-click  ansys_bridge\start_bridge.bat  and allow the Windows
  prompt (the "Start ANSYS connection" button does the same when you use Fluxion.exe).
  Then press "Check again" on the Check in ANSYS page; it turns green.
- The box model ships in ansys_models\; the arch model is built by script on each run.
- Keep about 1 GB free on this drive. Close Workbench while the app runs ANSYS.
- No ANSYS: double-click  ansys_bridge\start_bridge_mock.bat  for practice mode.

TIP: if Windows blocks files after unzipping, right-click the downloaded zip > Properties >
tick "Unblock" > OK, then unzip again.
